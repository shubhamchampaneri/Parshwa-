const http = require("http");
const fs = require("fs");
const path = require("path");

const PUBLIC_DIR = __dirname;
const MIME_TYPES = {
  ".html": "text/html",
  ".css": "text/css",
  ".js": "text/javascript",
  ".json": "application/json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml"
};

function createServer(port) {
  const server = http.createServer((req, res) => {
    let reqUrl = req.url.split("?")[0];
    let filePath = path.join(PUBLIC_DIR, reqUrl === "/" ? "index.html" : reqUrl);
    const ext = path.extname(filePath);
    const contentType = MIME_TYPES[ext] || "text/html";

    fs.readFile(filePath, (err, content) => {
      if (err) {
        if (err.code === "ENOENT") {
          // Fallback to index.html
          fs.readFile(path.join(PUBLIC_DIR, "index.html"), (err2, fallback) => {
            if (err2) {
              res.writeHead(404, { "Content-Type": "text/plain" });
              res.end("404 Not Found");
            } else {
              res.writeHead(200, { "Content-Type": "text/html" });
              res.end(fallback, "utf-8");
            }
          });
        } else {
          res.writeHead(500);
          res.end(`Server Error: ${err.code}`);
        }
      } else {
        res.writeHead(200, { "Content-Type": contentType });
        res.end(content, "utf-8");
      }
    });
  });

  server.on("error", (e) => {
    if (e.code === "EADDRINUSE") {
      console.log(`Port ${port} is in use, trying port ${port + 1}...`);
      createServer(port + 1);
    } else {
      console.error(e);
    }
  });

  server.listen(port, "0.0.0.0", () => {
    console.log("================================================================");
    console.log("  PARSHWA PLATINUM SECURITY - NEW IMPLEMENTATION IS RUNNING!");
    console.log(`  👉 Local Validation URL: http://localhost:${port}`);
    console.log("================================================================");
  });
}

createServer(3000);
