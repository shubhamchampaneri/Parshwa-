import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/constants/app_constants.dart';
import '../core/security/pin_security_service.dart';
import '../features/auth/presentation/controllers/auth_controller.dart';
import 'app_router.dart';
import 'theme/app_theme.dart';

class ParshwaPlatinumApp extends ConsumerStatefulWidget {
  const ParshwaPlatinumApp({super.key});

  @override
  ConsumerState<ParshwaPlatinumApp> createState() => _ParshwaPlatinumAppState();
}

class _ParshwaPlatinumAppState extends ConsumerState<ParshwaPlatinumApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState lifecycleState) {
    if (lifecycleState == AppLifecycleState.paused) {
      // Record timestamp when app enters background
      ref.read(pinSecurityServiceProvider).recordLastActive();
    } else if (lifecycleState == AppLifecycleState.resumed) {
      // Check if background duration >= 5 minutes
      ref.read(pinSecurityServiceProvider).isSessionTimedOut().then((timedOut) {
        if (timedOut) {
          final authState = ref.read(authControllerProvider);
          if (authState.isAuthenticated && authState.hasPinConfigured) {
            ref.read(authControllerProvider.notifier).lockSession();
            final router = ref.read(appRouterProvider);
            router.go('/pin-unlock');
          }
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final router = ref.watch(appRouterProvider);

    return MaterialApp.router(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      routerConfig: router,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en', 'US'),
        Locale('gu', 'IN'), // Gujarati
        Locale('hi', 'IN'), // Hindi
      ],
    );
  }
}
