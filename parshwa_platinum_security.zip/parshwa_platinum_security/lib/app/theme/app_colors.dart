import 'package:flutter/material.dart';

class AppColors {
  // Primary Palette - Parshwa Platinum Architectural Terracotta & Warm Copper
  static const Color primary = Color(0xFFB96D3A);
  static const Color primaryLight = Color(0xFFC87E4B);
  static const Color primaryDark = Color(0xFF8A4820);

  // Secondary Accent - Balcony Bronze & Warm Sandstone Gold
  static const Color secondary = Color(0xFFD49257);
  static const Color secondaryLight = Color(0xFFE9C59B);
  static const Color secondaryDark = Color(0xFF6B432C);

  // Slate / Charcoal Accent (Building Windows & Balcony Linings)
  static const Color charcoal = Color(0xFF1C222B);
  static const Color slate = Color(0xFF2E3846);

  // Status & Operational Colors
  static const Color success = Color(0xFF10B981);
  static const Color successContainer = Color(0xFFD1FAE5);
  static const Color warning = Color(0xFFF59E0B);
  static const Color warningContainer = Color(0xFFFEF3C7);
  static const Color error = Color(0xFFEF4444);
  static const Color errorContainer = Color(0xFFFEE2E2);
  static const Color info = Color(0xFF0EA5E9);

  // Emergency SOS - High-visibility Crimson
  static const Color sosRed = Color(0xFFDC2626);
  static const Color sosRedDark = Color(0xFF991B1B);

  // Neutral Backgrounds & Surfaces (Warm Sandstone Light)
  static const Color backgroundLight = Color(0xFFFAF7F3);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color cardLight = Color(0xFFFFFFFF);
  static const Color borderLight = Color(0xFFE8DFC5);
  static const Color textPrimaryLight = Color(0xFF1C222B);
  static const Color textSecondaryLight = Color(0xFF6B7280);

  // Neutral Backgrounds & Surfaces (Deep Slate Dark)
  static const Color backgroundDark = Color(0xFF12161C);
  static const Color surfaceDark = Color(0xFF1C222B);
  static const Color cardDark = Color(0xFF242B35);
  static const Color borderDark = Color(0xFF333E4D);
  static const Color textPrimaryDark = Color(0xFFFAF7F3);
  static const Color textSecondaryDark = Color(0xFF9CA3AF);
}

