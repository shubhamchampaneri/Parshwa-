import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../features/auth/presentation/controllers/auth_controller.dart';
import '../features/auth/presentation/screens/login_screen.dart';
import '../features/auth/presentation/screens/pending_approval_screen.dart';
import '../features/auth/presentation/screens/pin_unlock_screen.dart';
import '../features/auth/presentation/screens/register_screen.dart';
import '../features/auth/presentation/screens/setup_pin_screen.dart';
import '../features/auth/presentation/screens/splash_screen.dart';

import '../features/resident/presentation/screens/complaints_screen.dart';
import '../features/resident/presentation/screens/delivery_preferences_screen.dart';
import '../features/resident/presentation/screens/pre_approve_visitor_screen.dart';
import '../features/resident/presentation/screens/resident_home_screen.dart';
import '../features/resident/presentation/screens/resident_profile_screen.dart';
import '../features/resident/presentation/screens/resident_sos_screen.dart';
import '../features/resident/presentation/screens/visitor_history_screen.dart';

import '../features/guard/presentation/screens/delivery_staff_screen.dart';
import '../features/guard/presentation/screens/guard_home_screen.dart';
import '../features/guard/presentation/screens/guard_shift_log_screen.dart';
import '../features/guard/presentation/screens/guard_sos_alert_screen.dart';
import '../features/guard/presentation/screens/inside_visitors_screen.dart';
import '../features/guard/presentation/screens/log_walkin_visitor_screen.dart';
import '../features/guard/presentation/screens/verify_preapproval_screen.dart';

import '../features/admin/presentation/screens/admin_complaints_screen.dart';
import '../features/admin/presentation/screens/admin_home_screen.dart';
import '../features/admin/presentation/screens/flats_directory_screen.dart';
import '../features/admin/presentation/screens/guard_invite_code_screen.dart';
import '../features/admin/presentation/screens/notices_manager_screen.dart';
import '../features/admin/presentation/screens/pending_approvals_screen.dart';
import '../features/admin/presentation/screens/society_audit_logs_screen.dart';

import '../features/notices/presentation/screens/notices_screen.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/',
    routes: [
      // Authentication Routes
      GoRoute(path: '/', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(path: '/register', builder: (context, state) => const RegisterScreen()),
      GoRoute(path: '/setup-pin', builder: (context, state) => const SetupPinScreen()),
      GoRoute(path: '/pin-unlock', builder: (context, state) => const PinUnlockScreen()),
      GoRoute(path: '/pending-approval', builder: (context, state) => const PendingApprovalScreen()),

      // Resident Routes
      GoRoute(path: '/resident/home', builder: (context, state) => const ResidentHomeScreen()),
      GoRoute(path: '/resident/pre-approve', builder: (context, state) => const PreApproveVisitorScreen()),
      GoRoute(path: '/resident/visitor-history', builder: (context, state) => const VisitorHistoryScreen()),
      GoRoute(path: '/resident/delivery-preferences', builder: (context, state) => const DeliveryPreferencesScreen()),
      GoRoute(path: '/resident/complaints', builder: (context, state) => const ComplaintsScreen()),
      GoRoute(path: '/resident/sos', builder: (context, state) => const ResidentSosScreen()),
      GoRoute(path: '/resident/profile', builder: (context, state) => const ResidentProfileScreen()),

      // Guard Routes
      GoRoute(path: '/guard/dashboard', builder: (context, state) => const GuardHomeScreen()),
      GoRoute(path: '/guard/log-visitor', builder: (context, state) => const LogWalkInVisitorScreen()),
      GoRoute(path: '/guard/verify-pass', builder: (context, state) => const VerifyPreapprovalScreen()),
      GoRoute(path: '/guard/inside-visitors', builder: (context, state) => const InsideVisitorsScreen()),
      GoRoute(path: '/guard/delivery-staff', builder: (context, state) => const DeliveryStaffScreen()),
      GoRoute(
        path: '/guard/sos-alert',
        builder: (context, state) {
          final alert = state.extra as Map<String, dynamic>? ?? {};
          return GuardSosAlertScreen(alert: alert);
        },
      ),
      GoRoute(path: '/guard/shift-log', builder: (context, state) => const GuardShiftLogScreen()),

      // Admin Routes
      GoRoute(path: '/admin/home', builder: (context, state) => const AdminHomeScreen()),
      GoRoute(path: '/admin/approvals', builder: (context, state) => const PendingApprovalsScreen()),
      GoRoute(path: '/admin/flats', builder: (context, state) => const FlatsDirectoryScreen()),
      GoRoute(path: '/admin/guard-code', builder: (context, state) => const GuardInviteCodeScreen()),
      GoRoute(path: '/admin/notices-manager', builder: (context, state) => const NoticesManagerScreen()),
      GoRoute(path: '/admin/complaints', builder: (context, state) => const AdminComplaintsScreen()),
      GoRoute(path: '/admin/audit-logs', builder: (context, state) => const SocietyAuditLogsScreen()),

      // Common Broadcast Notices
      GoRoute(path: '/notices', builder: (context, state) => const NoticesScreen()),
    ],
  );
});
