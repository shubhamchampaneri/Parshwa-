import 'package:csv/csv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;
import '../../../../core/constants/supabase_tables.dart';
import '../../../../core/errors/exceptions.dart';
import '../../../../core/network/supabase_client.dart';
import '../../../auth/data/models/user_profile_model.dart';
import '../../../auth/domain/entities/user_profile.dart';
import '../../../resident/data/models/complaint_model.dart';
import '../../../resident/domain/entities/complaint.dart';
import '../domain/repositories/admin_repository.dart';

final adminRepositoryProvider = Provider<AdminRepository>((ref) {
  final client = ref.watch(supabaseClientProvider);
  return AdminRepositoryImpl(client);
});

class AdminRepositoryImpl implements AdminRepository {
  final sb.SupabaseClient _client;

  AdminRepositoryImpl(this._client);

  @override
  Future<List<UserProfile>> getPendingUsers() async {
    try {
      final res = await _client
          .from(SupabaseTables.profiles)
          .select('*, flats(flat_number)')
          .eq('status', 'PENDING')
          .order('created_at', ascending: false);

      return (res as List).map((e) => UserProfileModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      throw ServerException('Failed to fetch pending users: $e');
    }
  }

  @override
  Future<void> approveUser(String userId) async {
    try {
      await _client
          .from(SupabaseTables.profiles)
          .update({'status': 'APPROVED', 'updated_at': DateTime.now().toIso8601String()})
          .eq('id', userId);
    } catch (e) {
      throw ServerException('Failed to approve user: $e');
    }
  }

  @override
  Future<void> rejectUser(String userId, String reason) async {
    try {
      await _client
          .from(SupabaseTables.profiles)
          .update({
            'status': 'REJECTED',
            'rejection_reason': reason,
            'updated_at': DateTime.now().toIso8601String(),
          })
          .eq('id', userId);
    } catch (e) {
      throw ServerException('Failed to reject user: $e');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> getFlatsOverview() async {
    try {
      final flatsRes = await _client
          .from(SupabaseTables.flats)
          .select('*, profiles(id, full_name, role, status)')
          .order('flat_number', ascending: true);

      return (flatsRes as List).map((f) => Map<String, dynamic>.from(f as Map)).toList();
    } catch (e) {
      throw ServerException('Failed to fetch flats: $e');
    }
  }

  @override
  Future<List<UserProfile>> getFlatResidents(String flatId) async {
    try {
      final res = await _client
          .from(SupabaseTables.profiles)
          .select('*, flats(flat_number)')
          .eq('flat_id', flatId)
          .eq('role', 'RESIDENT');

      return (res as List).map((e) => UserProfileModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      return [];
    }
  }

  @override
  Future<String> getActiveGuardInviteCode() async {
    try {
      final res = await _client
          .from(SupabaseTables.guardInviteCodes)
          .select('code')
          .eq('is_active', true)
          .maybeSingle();

      return res?['code'] as String? ?? 'PPGUARD2026';
    } catch (_) {
      return 'PPGUARD2026';
    }
  }

  @override
  Future<String> rotateGuardInviteCode(String newCode) async {
    try {
      final res = await _client.rpc(
        'rotate_guard_invite_code',
        params: {'p_new_code': newCode.trim().toUpperCase()},
      );
      return res as String;
    } catch (e) {
      throw ServerException('Failed to rotate code: $e');
    }
  }

  @override
  Future<void> publishNotice({
    required String title,
    required String content,
    required String priority,
    required String targetAudience,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw const AuthException('Not authenticated');

      await _client.from(SupabaseTables.notices).insert({
        'title': title.trim(),
        'content': content.trim(),
        'priority': priority,
        'target_audience': targetAudience,
        'created_by': user.id,
        'is_active': true,
      });
    } catch (e) {
      throw ServerException('Failed to publish notice: $e');
    }
  }

  @override
  Future<List<Complaint>> getAllComplaints({String? statusFilter}) async {
    try {
      var query = _client.from(SupabaseTables.complaints).select();
      if (statusFilter != null && statusFilter != 'ALL') {
        query = query.eq('status', statusFilter);
      }
      final res = await query.order('created_at', ascending: false);
      return (res as List).map((e) => ComplaintModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      throw ServerException('Failed to load complaints: $e');
    }
  }

  @override
  Future<void> updateComplaintStatus({
    required String complaintId,
    required String status,
    String? adminNotes,
  }) async {
    try {
      final updates = <String, dynamic>{
        'status': status,
        'updated_at': DateTime.now().toIso8601String(),
      };
      if (adminNotes != null) updates['admin_notes'] = adminNotes;

      await _client.from(SupabaseTables.complaints).update(updates).eq('id', complaintId);
    } catch (e) {
      throw ServerException('Failed to update complaint: $e');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> getSocietyAuditLogs({
    DateTime? startDate,
    DateTime? endDate,
    String? flatId,
  }) async {
    try {
      var query = _client
          .from(SupabaseTables.visitorLogs)
          .select('*, visitors(full_name, phone_number), flats(flat_number), profiles:guard_id(full_name)');

      if (startDate != null) {
        query = query.gte('created_at', startDate.toIso8601String());
      }
      if (endDate != null) {
        query = query.lte('created_at', endDate.toIso8601String());
      }
      if (flatId != null) {
        query = query.eq('flat_id', flatId);
      }

      final res = await query.order('created_at', ascending: false).limit(200);
      return (res as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) {
      throw ServerException('Failed to fetch audit logs: $e');
    }
  }

  @override
  Future<String> generateAuditLogsCSV({
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final logs = await getSocietyAuditLogs(startDate: startDate, endDate: endDate);

    final List<List<dynamic>> rows = [];
    // CSV Header row
    rows.add([
      'Log ID',
      'Date & Time',
      'Visitor Name',
      'Visitor Mobile',
      'Flat Number',
      'Purpose',
      'Vehicle Number',
      'Status',
      'Entry Time',
      'Exit Time',
      'Guard on Duty',
    ]);

    for (final l in logs) {
      String vName = '';
      String vPhone = '';
      if (l['visitors'] != null && l['visitors'] is Map) {
        vName = l['visitors']['full_name'] as String? ?? '';
        vPhone = l['visitors']['phone_number'] as String? ?? '';
      }

      String flatNum = '';
      if (l['flats'] != null && l['flats'] is Map) {
        flatNum = l['flats']['flat_number']?.toString() ?? '';
      }

      String guardName = '';
      if (l['profiles'] != null && l['profiles'] is Map) {
        guardName = l['profiles']['full_name'] as String? ?? '';
      }

      rows.add([
        l['id'],
        l['created_at'],
        vName,
        vPhone,
        flatNum,
        l['purpose'],
        l['vehicle_number'] ?? 'N/A',
        l['status'],
        l['entry_time'] ?? 'N/A',
        l['exit_time'] ?? 'N/A',
        guardName,
      ]);
    }

    return const ListToCsvConverter().convert(rows);
  }
}
