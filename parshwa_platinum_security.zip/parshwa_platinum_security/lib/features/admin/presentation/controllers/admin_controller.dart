import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../features/auth/domain/entities/user_profile.dart';
import '../../../features/resident/domain/entities/complaint.dart';
import '../domain/repositories/admin_repository.dart';
import '../../data/repositories/admin_repository_impl.dart';

class AdminState {
  final List<UserProfile> pendingUsers;
  final List<Map<String, dynamic>> flatsOverview;
  final String activeGuardCode;
  final List<Complaint> complaints;
  final bool isLoading;
  final String? errorMessage;
  final String? successMessage;

  const AdminState({
    this.pendingUsers = const [],
    this.flatsOverview = const [],
    this.activeGuardCode = 'PPGUARD2026',
    this.complaints = const [],
    this.isLoading = false,
    this.errorMessage,
    this.successMessage,
  });

  int get pendingResidentsCount =>
      pendingUsers.where((u) => u.isResident).length;
  int get pendingGuardsCount =>
      pendingUsers.where((u) => u.isGuard).length;

  AdminState copyWith({
    List<UserProfile>? pendingUsers,
    List<Map<String, dynamic>>? flatsOverview,
    String? activeGuardCode,
    List<Complaint>? complaints,
    bool? isLoading,
    String? errorMessage,
    String? successMessage,
    bool clearErrors = false,
  }) {
    return AdminState(
      pendingUsers: pendingUsers ?? this.pendingUsers,
      flatsOverview: flatsOverview ?? this.flatsOverview,
      activeGuardCode: activeGuardCode ?? this.activeGuardCode,
      complaints: complaints ?? this.complaints,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearErrors ? null : errorMessage,
      successMessage: clearErrors ? null : successMessage,
    );
  }
}

final adminControllerProvider =
    StateNotifierProvider<AdminController, AdminState>((ref) {
  final repo = ref.watch(adminRepositoryProvider);
  return AdminController(repo);
});

class AdminController extends StateNotifier<AdminState> {
  final AdminRepository _repo;

  AdminController(this._repo) : super(const AdminState(isLoading: true)) {
    loadDashboard();
  }

  Future<void> loadDashboard() async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final pending = await _repo.getPendingUsers();
      final flats = await _repo.getFlatsOverview();
      final code = await _repo.getActiveGuardInviteCode();

      state = state.copyWith(
        pendingUsers: pending,
        flatsOverview: flats,
        activeGuardCode: code,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }

  Future<void> approveUser(String userId) async {
    try {
      await _repo.approveUser(userId);
      state = state.copyWith(successMessage: 'User approved successfully');
      await loadDashboard();
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
    }
  }

  Future<void> rejectUser(String userId, String reason) async {
    try {
      await _repo.rejectUser(userId, reason);
      state = state.copyWith(successMessage: 'User registration rejected');
      await loadDashboard();
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
    }
  }

  Future<void> rotateCode(String newCode) async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final rotated = await _repo.rotateGuardInviteCode(newCode);
      state = state.copyWith(
        activeGuardCode: rotated,
        isLoading: false,
        successMessage: 'Guard invite code rotated to $rotated',
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }
}
