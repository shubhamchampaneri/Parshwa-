import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/empty_state_view.dart';
import '../../../../core/widgets/loading_shimmer.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../data/repositories/admin_repository_impl.dart';

class SocietyAuditLogsScreen extends ConsumerStatefulWidget {
  const SocietyAuditLogsScreen({super.key});

  @override
  ConsumerState<SocietyAuditLogsScreen> createState() => _SocietyAuditLogsScreenState();
}

class _SocietyAuditLogsScreenState extends ConsumerState<SocietyAuditLogsScreen> {
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 7));
  DateTime _endDate = DateTime.now();
  List<Map<String, dynamic>> _logs = [];
  bool _isLoading = true;
  bool _isExporting = false;

  @override
  void initState() {
    super.initState();
    _fetchLogs();
  }

  Future<void> _fetchLogs() async {
    setState(() => _isLoading = true);
    try {
      final repo = ref.read(adminRepositoryProvider);
      final list = await repo.getSocietyAuditLogs(
        startDate: _startDate,
        endDate: _endDate,
      );
      if (mounted) {
        setState(() {
          _logs = list;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _pickDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2025),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
    );
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
      _fetchLogs();
    }
  }

  Future<void> _exportCSV() async {
    setState(() => _isExporting = true);
    try {
      final repo = ref.read(adminRepositoryProvider);
      final csvString = await repo.generateAuditLogsCSV(
        startDate: _startDate,
        endDate: _endDate,
      );

      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/parshwa_platinum_logs_${DateTime.now().millisecondsSinceEpoch}.csv');
      await file.writeAsString(csvString);

      if (mounted) {
        setState(() => _isExporting = false);
        await Share.shareXFiles(
          [XFile(file.path)],
          text: 'Parshwa Platinum Security Gate Audit Logs (${DateFormatter.formatDate(_startDate)} to ${DateFormatter.formatDate(_endDate)})',
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isExporting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to export CSV: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Society Audit Logs'),
      ),
      body: Column(
        children: [
          // Filter Bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.date_range_outlined, size: 18),
                    label: Text(
                      '${DateFormatter.formatDate(_startDate)} - ${DateFormatter.formatDate(_endDate)}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    onPressed: _pickDateRange,
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    minimumSize: const Size(110, 48),
                  ),
                  icon: _isExporting
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                      : const Icon(Icons.file_download, size: 18),
                  label: const Text('Export CSV'),
                  onPressed: _isExporting ? null : _exportCSV,
                ),
              ],
            ),
          ),
          const Divider(),

          // Logs Feed
          Expanded(
            child: RefreshIndicator(
              onRefresh: _fetchLogs,
              child: _isLoading
                  ? ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: 5,
                      itemBuilder: (_, __) => const Padding(
                        padding: EdgeInsets.only(bottom: 12.0),
                        child: LoadingShimmer(width: double.infinity, height: 78),
                      ),
                    )
                  : _logs.isEmpty
                      ? const EmptyStateView(
                          icon: Icons.list_alt_rounded,
                          title: 'No Logs in Date Range',
                          message: 'No gate visitor records were found for this time period.',
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _logs.length,
                          itemBuilder: (context, index) {
                            final l = _logs[index];
                            final v = l['visitors'] as Map<String, dynamic>?;
                            final f = l['flats'] as Map<String, dynamic>?;
                            final p = l['profiles'] as Map<String, dynamic>?;

                            final vName = v?['full_name'] as String? ?? 'Visitor';
                            final flatNum = f?['flat_number']?.toString() ?? '---';
                            final guardName = p?['full_name'] as String? ?? 'Gate Guard';
                            final status = l['status'] as String? ?? 'PENDING';

                            return Card(
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: AppColors.primaryLight.withOpacity(0.12),
                                  child: const Icon(Icons.person, color: AppColors.primary),
                                ),
                                title: Text('$vName ➔ Flat $flatNum', style: const TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Text(
                                  'Purpose: ${l["purpose"]} • Guard: $guardName\n'
                                  'Logged: ${DateFormatter.formatDateTime(DateTime.tryParse(l["created_at"].toString()))}',
                                  style: const TextStyle(fontSize: 12),
                                ),
                                trailing: StatusBadge(status: status),
                                isThreeLine: true,
                              ),
                            );
                          },
                        ),
            ),
          ),
        ],
      ),
    );
  }
}
