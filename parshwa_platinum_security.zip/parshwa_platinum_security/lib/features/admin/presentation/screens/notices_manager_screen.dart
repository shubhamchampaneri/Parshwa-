import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/input_validators.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../data/repositories/admin_repository_impl.dart';

class NoticesManagerScreen extends ConsumerStatefulWidget {
  const NoticesManagerScreen({super.key});

  @override
  ConsumerState<NoticesManagerScreen> createState() => _NoticesManagerScreenState();
}

class _NoticesManagerScreenState extends ConsumerState<NoticesManagerScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();

  String _priority = 'NORMAL';
  String _targetAudience = 'ALL';
  bool _isPublishing = false;

  final List<String> _priorities = ['NORMAL', 'IMPORTANT', 'URGENT'];
  final List<String> _audiences = ['ALL', 'RESIDENTS', 'GUARDS'];

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  Future<void> _handlePublish() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isPublishing = true);
    try {
      final repo = ref.read(adminRepositoryProvider);
      await repo.publishNotice(
        title: _titleController.text.trim(),
        content: _contentController.text.trim(),
        priority: _priority,
        targetAudience: _targetAudience,
      );

      if (mounted) {
        setState(() => _isPublishing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Notice broadcast published successfully'),
            backgroundColor: AppColors.success,
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isPublishing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Publish Society Notice'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Broadcast Announcement',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Notice will be immediately viewable on Resident and Guard dashboards.',
                style: TextStyle(color: AppColors.textSecondaryLight),
              ),
              const SizedBox(height: 24),

              AppTextField(
                label: 'Notice Title',
                hint: 'e.g. Scheduled Lift Maintenance Tomorrow',
                controller: _titleController,
                validator: (v) => InputValidators.validateRequired(v, 'Notice title'),
              ),
              const SizedBox(height: 16),

              Text('Notice Priority', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: _priorities.map((p) {
                  final isSel = _priority == p;
                  return ChoiceChip(
                    label: Text(p),
                    selected: isSel,
                    onSelected: (sel) {
                      if (sel) setState(() => _priority = p);
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              Text('Target Audience', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: _audiences.map((a) {
                  final isSel = _targetAudience == a;
                  return ChoiceChip(
                    label: Text(a),
                    selected: isSel,
                    onSelected: (sel) {
                      if (sel) setState(() => _targetAudience = a);
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              AppTextField(
                label: 'Notice Message / Details',
                hint: 'Write the complete announcement text...',
                controller: _contentController,
                maxLines: 5,
                validator: (v) => InputValidators.validateRequired(v, 'Notice message'),
              ),
              const SizedBox(height: 32),

              AppButton(
                label: 'Broadcast Notice Now',
                isLoading: _isPublishing,
                icon: Icons.campaign_rounded,
                onPressed: _handlePublish,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
