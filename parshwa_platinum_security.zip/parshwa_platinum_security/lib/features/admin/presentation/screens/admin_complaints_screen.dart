import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/empty_state_view.dart';
import '../../../../core/widgets/loading_shimmer.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../../resident/domain/entities/complaint.dart';
import '../../data/repositories/admin_repository_impl.dart';

class AdminComplaintsScreen extends ConsumerStatefulWidget {
  const AdminComplaintsScreen({super.key});

  @override
  ConsumerState<AdminComplaintsScreen> createState() => _AdminComplaintsScreenState();
}

class _AdminComplaintsScreenState extends ConsumerState<AdminComplaintsScreen> {
  String _selectedStatus = 'ALL';
  List<Complaint> _complaints = [];
  bool _isLoading = true;

  final List<String> _filters = ['ALL', 'SUBMITTED', 'IN_PROGRESS', 'RESOLVED'];

  @override
  void initState() {
    super.initState();
    _fetchComplaints();
  }

  Future<void> _fetchComplaints() async {
    setState(() => _isLoading = true);
    try {
      final repo = ref.read(adminRepositoryProvider);
      final list = await repo.getAllComplaints(statusFilter: _selectedStatus);
      if (mounted) {
        setState(() {
          _complaints = list;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showResolutionDialog(Complaint c) {
    String newStatus = c.status;
    final notesController = TextEditingController(text: c.adminNotes ?? '');

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) => AlertDialog(
          title: Text('Resolve: ${c.title}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Update Ticket Status:', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: newStatus,
                items: const [
                  DropdownMenuItem(value: 'SUBMITTED', child: Text('Submitted')),
                  DropdownMenuItem(value: 'IN_PROGRESS', child: Text('In Progress')),
                  DropdownMenuItem(value: 'RESOLVED', child: Text('Resolved')),
                ],
                onChanged: (val) {
                  if (val != null) setModalState(() => newStatus = val);
                },
              ),
              const SizedBox(height: 16),
              TextField(
                controller: notesController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Admin Resolution Note',
                  hintText: 'e.g. Plumber visited and repaired valve on 4th floor.',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                final repo = ref.read(adminRepositoryProvider);
                await repo.updateComplaintStatus(
                  complaintId: c.id,
                  status: newStatus,
                  adminNotes: notesController.text.trim().isNotEmpty ? notesController.text.trim() : null,
                );
                Navigator.pop(ctx);
                _fetchComplaints();
              },
              child: const Text('Update Ticket'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Maintenance Complaints'),
      ),
      body: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Row(
              children: _filters.map((f) {
                final isSel = _selectedStatus == f;
                return Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: FilterChip(
                    label: Text(f),
                    selected: isSel,
                    onSelected: (_) {
                      setState(() => _selectedStatus = f);
                      _fetchComplaints();
                    },
                  ),
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _fetchComplaints,
              child: _isLoading
                  ? ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: 4,
                      itemBuilder: (_, __) => const Padding(
                        padding: EdgeInsets.only(bottom: 12.0),
                        child: LoadingShimmer(width: double.infinity, height: 90),
                      ),
                    )
                  : _complaints.isEmpty
                      ? const EmptyStateView(
                          icon: Icons.done_all_rounded,
                          title: 'No Complaints Found',
                          message: 'No complaints match the selected filter.',
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _complaints.length,
                          itemBuilder: (context, index) {
                            final c = _complaints[index];
                            return Card(
                              child: ListTile(
                                title: Text(c.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 2),
                                    Text('${c.category} • ${c.description}'),
                                    const SizedBox(height: 2),
                                    Text(
                                      DateFormatter.formatDateTime(c.createdAt),
                                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                                    ),
                                  ],
                                ),
                                trailing: StatusBadge(status: c.status),
                                isThreeLine: true,
                                onTap: () => _showResolutionDialog(c),
                              ),
                            );
                          },
                        ),
            ),
          ),
        ],
      ),
    );
  }
}
