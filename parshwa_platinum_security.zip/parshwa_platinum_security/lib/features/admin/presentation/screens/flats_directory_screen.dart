import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/constants/app_constants.dart';
import '../controllers/admin_controller.dart';

class FlatsDirectoryScreen extends ConsumerWidget {
  const FlatsDirectoryScreen({super.key});

  void _showFlatDetails(BuildContext context, Map<String, dynamic> flat) {
    final flatNumber = flat['flat_number']?.toString() ?? '';
    final preference = flat['delivery_preference']?.toString() ?? 'ASK_FIRST';
    final List profiles = flat['profiles'] is List ? flat['profiles'] as List : [];

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Flat $flatNumber Details',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${profiles.length} / ${AppConstants.maxResidentsPerFlat} Residents',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Gate Delivery Policy: ${preference == "LEAVE_AT_GATE" ? "Leave at Gate" : "Ask Me First"}',
              style: const TextStyle(color: AppColors.textSecondaryLight),
            ),
            const SizedBox(height: 16),
            const Divider(),
            const Text('Registered Residents:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            if (profiles.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(child: Text('No residents registered for this flat yet')),
              )
            else
              ...profiles.map((p) {
                final name = p['full_name'] as String? ?? 'Resident';
                final status = p['status'] as String? ?? 'PENDING';
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(name),
                  subtitle: Text('Status: $status'),
                );
              }),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Parshwa Platinum Directory'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: AppConstants.totalFloors,
        itemBuilder: (context, floorIndex) {
          // Display from Floor 7 down to Floor 1
          final floor = 7 - floorIndex;
          final floorFlats = state.flatsOverview.where((f) {
            final fNum = f['floor_number'] as int? ?? (int.tryParse(f['flat_number'].toString()[0]) ?? 1);
            return fNum == floor;
          }).toList();

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                child: Text(
                  'Floor $floor',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
              ),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 2.2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: floorFlats.length,
                itemBuilder: (ctx, i) {
                  final flat = floorFlats[i];
                  final flatNum = flat['flat_number']?.toString() ?? '';
                  final List profiles = flat['profiles'] is List ? flat['profiles'] as List : [];
                  final isFull = profiles.length >= AppConstants.maxResidentsPerFlat;

                  return InkWell(
                    onTap: () => _showFlatDetails(context, flat),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isFull ? AppColors.error : AppColors.borderLight,
                          width: isFull ? 1.5 : 1,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Flat $flatNum',
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                              Text(
                                profiles.isEmpty ? 'Vacant' : '${profiles.length} Members',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: profiles.isEmpty ? Colors.grey : AppColors.primaryLight,
                                ),
                              ),
                            ],
                          ),
                          Icon(
                            isFull ? Icons.groups_rounded : Icons.person_outline,
                            color: isFull ? AppColors.error : AppColors.primary,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),
            ],
          );
        },
      ),
    );
  }
}
