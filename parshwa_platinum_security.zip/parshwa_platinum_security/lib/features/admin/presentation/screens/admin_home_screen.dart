import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../controllers/admin_controller.dart';

class AdminHomeScreen extends ConsumerWidget {
  const AdminHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminControllerProvider);
    final user = ref.watch(authControllerProvider).userProfile;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Committee Administration'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sign Out',
            onPressed: () async {
              await ref.read(authControllerProvider.notifier).signOut();
              if (context.mounted) context.go('/login');
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => ref.read(adminControllerProvider.notifier).loadDashboard(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Committee Badge Card
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.admin_panel_settings, size: 32, color: Colors.white),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user?.fullName ?? 'Committee Member',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 2),
                          const Text(
                            'Parshwa Platinum Society Committee',
                            style: TextStyle(color: Colors.white70, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Pending Approvals Alert Banner
              if (state.pendingUsers.isNotEmpty) ...[
                InkWell(
                  onTap: () => context.push('/admin/approvals'),
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.warningContainer,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.warning.withOpacity(0.4)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.pending_actions_rounded, color: AppColors.warning, size: 24),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            '${state.pendingUsers.length} Registration Requests Awaiting Verification',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppColors.warning,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.warning),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],

              Text(
                'Management Controls',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 12),

              _buildAdminNavTile(
                context,
                title: 'User Approvals',
                subtitle: '${state.pendingResidentsCount} Residents, ${state.pendingGuardsCount} Guards pending',
                icon: Icons.how_to_reg_rounded,
                color: AppColors.primary,
                badgeCount: state.pendingUsers.length,
                onTap: () => context.push('/admin/approvals'),
              ),
              const SizedBox(height: 12),

              _buildAdminNavTile(
                context,
                title: 'Flats & Residents Directory',
                subtitle: 'Manage all 28 flats (Floors 1-7, 101-704)',
                icon: Icons.apartment_rounded,
                color: Colors.teal,
                onTap: () => context.push('/admin/flats'),
              ),
              const SizedBox(height: 12),

              _buildAdminNavTile(
                context,
                title: 'Guard Invite Code',
                subtitle: 'Active: [${state.activeGuardCode}] • Rotate code',
                icon: Icons.key_rounded,
                color: Colors.amber.shade800,
                onTap: () => context.push('/admin/guard-code'),
              ),
              const SizedBox(height: 12),

              _buildAdminNavTile(
                context,
                title: 'Publish Society Notice',
                subtitle: 'Broadcast alerts to residents & guards',
                icon: Icons.campaign_rounded,
                color: Colors.purple,
                onTap: () => context.push('/admin/notices-manager'),
              ),
              const SizedBox(height: 12),

              _buildAdminNavTile(
                context,
                title: 'Maintenance Complaints',
                subtitle: 'Review & resolve resident issues',
                icon: Icons.build_circle_rounded,
                color: Colors.deepOrange,
                onTap: () => context.push('/admin/complaints'),
              ),
              const SizedBox(height: 12),

              _buildAdminNavTile(
                context,
                title: 'Gate Logs & CSV Export',
                subtitle: 'Audit trail for visitors, deliveries, SOS',
                icon: Icons.file_download_outlined,
                color: Colors.indigo,
                onTap: () => context.push('/admin/audit-logs'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdminNavTile(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    int? badgeCount,
    required VoidCallback onTap,
  }) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 26),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (badgeCount != null && badgeCount > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  color: AppColors.warning,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$badgeCount',
                  style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ),
            const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}
