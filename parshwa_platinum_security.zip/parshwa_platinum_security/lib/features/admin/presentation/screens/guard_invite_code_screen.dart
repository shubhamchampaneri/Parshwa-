import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../controllers/admin_controller.dart';

class GuardInviteCodeScreen extends ConsumerStatefulWidget {
  const GuardInviteCodeScreen({super.key});

  @override
  ConsumerState<GuardInviteCodeScreen> createState() => _GuardInviteCodeScreenState();
}

class _GuardInviteCodeScreenState extends ConsumerState<GuardInviteCodeScreen> {
  void _showRotateDialog() {
    // Generate suggested 8-character alphanumeric code
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final random = Random.secure();
    final suggested = 'PPG${String.fromCharCodes(Iterable.generate(5, (_) => chars.codeUnitAt(random.nextInt(chars.length))))}';

    final codeController = TextEditingController(text: suggested);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rotate Guard Invite Code'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Rotating this code will immediately invalidate the current code for new registrations. Existing approved guards are unaffected.',
              style: TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: codeController,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(labelText: 'New Secret Invite Code'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
            onPressed: () {
              final newCode = codeController.text.trim();
              if (newCode.length >= 4) {
                ref.read(adminControllerProvider.notifier).rotateCode(newCode);
                Navigator.pop(ctx);
              }
            },
            child: const Text('Confirm & Rotate'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(adminControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Guard Secret Invite Code'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.key_rounded, size: 64, color: AppColors.primary),
            const SizedBox(height: 16),
            Text(
              'Registration Gatekeeper',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Only security personnel who enter this secret code during sign-up can register as guards.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondaryLight),
            ),
            const SizedBox(height: 36),

            // Active Code Card
            Container(
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.primary, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.08),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Text('ACTIVE GUARD INVITE CODE', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
                  const SizedBox(height: 12),
                  Text(
                    state.activeGuardCode,
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 4,
                      color: AppColors.primary,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryLight.withOpacity(0.15),
                      foregroundColor: AppColors.primary,
                      elevation: 0,
                    ),
                    icon: const Icon(Icons.copy_rounded, size: 18),
                    label: const Text('Copy to Clipboard'),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: state.activeGuardCode));
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Guard invite code copied to clipboard')),
                      );
                    },
                  ),
                ],
              ),
            ),

            const Spacer(),

            AppButton(
              label: 'Rotate Invite Code',
              icon: Icons.refresh_rounded,
              onPressed: _showRotateDialog,
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
