import '../../../features/auth/domain/entities/user_profile.dart';
import '../../../features/resident/domain/entities/complaint.dart';

abstract class AdminRepository {
  Future<List<UserProfile>> getPendingUsers();
  Future<void> approveUser(String userId);
  Future<void> rejectUser(String userId, String reason);

  Future<List<Map<String, dynamic>>> getFlatsOverview();
  Future<List<UserProfile>> getFlatResidents(String flatId);

  Future<String> getActiveGuardInviteCode();
  Future<String> rotateGuardInviteCode(String newCode);

  Future<void> publishNotice({
    required String title,
    required String content,
    required String priority,
    required String targetAudience,
  });

  Future<List<Complaint>> getAllComplaints({String? statusFilter});
  Future<void> updateComplaintStatus({
    required String complaintId,
    required String status,
    String? adminNotes,
  });

  Future<List<Map<String, dynamic>>> getSocietyAuditLogs({
    DateTime? startDate,
    DateTime? endDate,
    String? flatId,
  });

  Future<String> generateAuditLogsCSV({
    DateTime? startDate,
    DateTime? endDate,
  });
}
