import 'dart:io';
import '../../guard/domain/entities/visitor_log.dart';
import '../entities/pre_approval.dart';
import '../entities/complaint.dart';

abstract class ResidentRepository {
  Future<List<VisitorLog>> getTodayVisitors(String flatId);
  Stream<List<VisitorLog>> watchPendingApprovals(String flatId);

  Future<Map<String, dynamic>> respondToVisitorRequest({
    required String logId,
    required bool approve,
    String? rejectionReason,
  });

  Future<PreApproval> createPreApproval({
    required String flatId,
    required String visitorName,
    String? visitorPhone,
    required String purpose,
    String? vehicleNumber,
    required DateTime expectedArrival,
  });

  Future<List<PreApproval>> getPreApprovals(String flatId);
  Future<void> cancelPreApproval(String preApprovalId);

  Future<List<VisitorLog>> getVisitorHistory(
    String flatId, {
    String? searchQuery,
    String? statusFilter,
    int limit = 30,
  });

  Future<Map<String, dynamic>> getDeliveryPreference(String flatId);
  Future<void> updateDeliveryPreference({
    required String flatId,
    required String preference,
    String? instructions,
  });

  Future<void> triggerEmergencySOS({
    required String flatId,
    required String emergencyType,
  });

  Future<Complaint> fileComplaint({
    required String flatId,
    required String category,
    required String title,
    required String description,
    File? photoFile,
  });

  Future<List<Complaint>> getComplaints(String flatId);
  Future<List<Map<String, dynamic>>> getFlatMembers(String flatId);
}
