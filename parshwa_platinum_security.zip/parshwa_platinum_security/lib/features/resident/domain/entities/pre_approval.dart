class PreApproval {
  final String id;
  final String flatId;
  final String residentId;
  final String visitorName;
  final String? visitorPhone;
  final String purpose;
  final String? vehicleNumber;
  final DateTime expectedArrival;
  final DateTime expiresAt;
  final String otpCode;
  final String qrCodeData;
  final String status; // 'ACTIVE', 'USED', 'EXPIRED', 'CANCELLED'
  final DateTime? usedAt;
  final DateTime createdAt;

  const PreApproval({
    required this.id,
    required this.flatId,
    required this.residentId,
    required this.visitorName,
    this.visitorPhone,
    required this.purpose,
    this.vehicleNumber,
    required this.expectedArrival,
    required this.expiresAt,
    required this.otpCode,
    required this.qrCodeData,
    required this.status,
    this.usedAt,
    required this.createdAt,
  });

  bool get isActive => status == 'ACTIVE';
}
