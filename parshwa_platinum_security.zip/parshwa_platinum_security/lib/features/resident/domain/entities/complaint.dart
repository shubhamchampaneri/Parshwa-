class Complaint {
  final String id;
  final String flatId;
  final String residentId;
  final String category; // 'WATER', 'LIFT', 'PARKING', 'CLEANING', 'ELECTRICAL', 'SECURITY', 'OTHER'
  final String title;
  final String description;
  final String? photoUrl;
  final String status; // 'SUBMITTED', 'IN_PROGRESS', 'RESOLVED'
  final String? adminNotes;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Complaint({
    required this.id,
    required this.flatId,
    required this.residentId,
    required this.category,
    required this.title,
    required this.description,
    this.photoUrl,
    required this.status,
    this.adminNotes,
    required this.createdAt,
    required this.updatedAt,
  });

  bool get isResolved => status == 'RESOLVED';
}
