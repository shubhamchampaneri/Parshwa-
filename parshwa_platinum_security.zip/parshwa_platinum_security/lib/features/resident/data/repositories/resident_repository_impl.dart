import 'dart:io';
import 'dart:math';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;
import '../../../../core/constants/supabase_tables.dart';
import '../../../../core/errors/exceptions.dart';
import '../../../../core/network/supabase_client.dart';
import '../../../../core/utils/image_compressor.dart';
import '../../guard/domain/entities/visitor_log.dart';
import '../../guard/data/models/visitor_log_model.dart';
import '../domain/entities/complaint.dart';
import '../domain/entities/pre_approval.dart';
import '../domain/repositories/resident_repository.dart';
import '../models/complaint_model.dart';
import '../models/pre_approval_model.dart';

final residentRepositoryProvider = Provider<ResidentRepository>((ref) {
  final client = ref.watch(supabaseClientProvider);
  return ResidentRepositoryImpl(client);
});

class ResidentRepositoryImpl implements ResidentRepository {
  final sb.SupabaseClient _client;

  ResidentRepositoryImpl(this._client);

  @override
  Future<List<VisitorLog>> getTodayVisitors(String flatId) async {
    try {
      final now = DateTime.now();
      final startOfDay = DateTime(now.year, now.month, now.day).toIso8601String();

      final res = await _client
          .from(SupabaseTables.visitorLogs)
          .select('*, visitors(*), flats(flat_number), profiles:resident_id(full_name)')
          .eq('flat_id', flatId)
          .gte('created_at', startOfDay)
          .order('created_at', ascending: false);

      return (res as List).map((e) => VisitorLogModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      throw ServerException('Failed to load today visitors: $e');
    }
  }

  @override
  Stream<List<VisitorLog>> watchPendingApprovals(String flatId) {
    return _client
        .from(SupabaseTables.visitorLogs)
        .stream(primaryKey: ['id'])
        .eq('flat_id', flatId)
        .order('created_at', ascending: false)
        .asyncMap((list) async {
          final pending = list.where((item) => item['status'] == 'PENDING').toList();
          if (pending.isEmpty) return <VisitorLog>[];

          final res = await _client
              .from(SupabaseTables.visitorLogs)
              .select('*, visitors(*), flats(flat_number)')
              .eq('flat_id', flatId)
              .eq('status', 'PENDING');

          return (res as List).map((e) => VisitorLogModel.fromJson(e as Map<String, dynamic>)).toList();
        });
  }

  @override
  Future<Map<String, dynamic>> respondToVisitorRequest({
    required String logId,
    required bool approve,
    String? rejectionReason,
  }) async {
    try {
      final res = await _client.rpc(
        'respond_to_visitor_request',
        params: {
          'p_log_id': logId,
          'p_action': approve ? 'APPROVE' : 'REJECT',
          'p_rejection_reason': rejectionReason,
        },
      );
      return Map<String, dynamic>.from(res as Map);
    } catch (e) {
      throw ServerException('Failed to respond to visitor: $e');
    }
  }

  @override
  Future<PreApproval> createPreApproval({
    required String flatId,
    required String visitorName,
    String? visitorPhone,
    required String purpose,
    String? vehicleNumber,
    required DateTime expectedArrival,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw const AuthException('Not authenticated');

      // Generate 6-digit cryptographic OTP code
      final rng = Random.secure();
      final otp = (rng.nextInt(900000) + 100000).toString();
      final qrPayload = 'PP-PASS:$flatId:$otp:${DateTime.now().millisecondsSinceEpoch}';

      final expiresAt = DateTime(
        expectedArrival.year,
        expectedArrival.month,
        expectedArrival.day,
        23,
        59,
        59,
      );

      final res = await _client
          .from(SupabaseTables.preApprovals)
          .insert({
            'flat_id': flatId,
            'resident_id': user.id,
            'visitor_name': visitorName.trim(),
            'visitor_phone': visitorPhone?.trim(),
            'purpose': purpose,
            'vehicle_number': vehicleNumber?.trim().toUpperCase(),
            'expected_arrival': expectedArrival.toIso8601String(),
            'expires_at': expiresAt.toIso8601String(),
            'otp_code': otp,
            'qr_code_data': qrPayload,
            'status': 'ACTIVE',
          })
          .select()
          .single();

      return PreApprovalModel.fromJson(res);
    } catch (e) {
      throw ServerException('Failed to create pre-approval pass: $e');
    }
  }

  @override
  Future<List<PreApproval>> getPreApprovals(String flatId) async {
    try {
      final res = await _client
          .from(SupabaseTables.preApprovals)
          .select()
          .eq('flat_id', flatId)
          .order('created_at', ascending: false);

      return (res as List).map((e) => PreApprovalModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      throw ServerException('Failed to fetch pre-approvals: $e');
    }
  }

  @override
  Future<void> cancelPreApproval(String preApprovalId) async {
    try {
      await _client
          .from(SupabaseTables.preApprovals)
          .update({'status': 'CANCELLED'})
          .eq('id', preApprovalId);
    } catch (e) {
      throw ServerException('Failed to cancel pass: $e');
    }
  }

  @override
  Future<List<VisitorLog>> getVisitorHistory(
    String flatId, {
    String? searchQuery,
    String? statusFilter,
    int limit = 30,
  }) async {
    try {
      var query = _client
          .from(SupabaseTables.visitorLogs)
          .select('*, visitors(*), flats(flat_number)')
          .eq('flat_id', flatId);

      if (statusFilter != null && statusFilter != 'ALL') {
        query = query.eq('status', statusFilter);
      }

      final res = await query.order('created_at', ascending: false).limit(limit);
      var list = (res as List).map((e) => VisitorLogModel.fromJson(e as Map<String, dynamic>)).toList();

      if (searchQuery != null && searchQuery.trim().isNotEmpty) {
        final q = searchQuery.toLowerCase();
        list = list.where((v) =>
            v.visitorName.toLowerCase().contains(q) ||
            v.visitorPhone.contains(q) ||
            (v.vehicleNumber?.toLowerCase().contains(q) ?? false)).toList();
      }

      return list;
    } catch (e) {
      throw ServerException('Failed to fetch visitor history: $e');
    }
  }

  @override
  Future<Map<String, dynamic>> getDeliveryPreference(String flatId) async {
    try {
      final res = await _client
          .from(SupabaseTables.flats)
          .select('delivery_preference, delivery_instructions')
          .eq('id', flatId)
          .single();

      return Map<String, dynamic>.from(res);
    } catch (e) {
      return {'delivery_preference': 'ASK_FIRST', 'delivery_instructions': null};
    }
  }

  @override
  Future<void> updateDeliveryPreference({
    required String flatId,
    required String preference,
    String? instructions,
  }) async {
    try {
      await _client.from(SupabaseTables.flats).update({
        'delivery_preference': preference,
        'delivery_instructions': instructions,
      }).eq('id', flatId);
    } catch (e) {
      throw ServerException('Failed to update delivery preference: $e');
    }
  }

  @override
  Future<void> triggerEmergencySOS({
    required String flatId,
    required String emergencyType,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw const AuthException('Not authenticated');

      await _client.from(SupabaseTables.sosAlerts).insert({
        'flat_id': flatId,
        'resident_id': user.id,
        'emergency_type': emergencyType,
        'status': 'ACTIVE',
      });
    } catch (e) {
      throw ServerException('Failed to trigger SOS alert: $e');
    }
  }

  @override
  Future<Complaint> fileComplaint({
    required String flatId,
    required String category,
    required String title,
    required String description,
    File? photoFile,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw const AuthException('Not authenticated');

      String? photoUrl;
      if (photoFile != null) {
        final compressed = await ImageCompressor.compressImageFile(photoFile);
        final fileToUpload = compressed ?? photoFile;
        final fileName = 'complaint_${DateTime.now().millisecondsSinceEpoch}.jpg';

        await _client.storage
            .from(SupabaseTables.bucketComplaintPhotos)
            .upload(fileName, fileToUpload);

        photoUrl = _client.storage
            .from(SupabaseTables.bucketComplaintPhotos)
            .getPublicUrl(fileName);
      }

      final res = await _client
          .from(SupabaseTables.complaints)
          .insert({
            'flat_id': flatId,
            'resident_id': user.id,
            'category': category,
            'title': title.trim(),
            'description': description.trim(),
            'photo_url': photoUrl,
            'status': 'SUBMITTED',
          })
          .select()
          .single();

      return ComplaintModel.fromJson(res);
    } catch (e) {
      throw ServerException('Failed to file complaint: $e');
    }
  }

  @override
  Future<List<Complaint>> getComplaints(String flatId) async {
    try {
      final res = await _client
          .from(SupabaseTables.complaints)
          .select()
          .eq('flat_id', flatId)
          .order('created_at', ascending: false);

      return (res as List).map((e) => ComplaintModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      throw ServerException('Failed to fetch complaints: $e');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> getFlatMembers(String flatId) async {
    try {
      final res = await _client
          .from(SupabaseTables.profiles)
          .select('id, full_name, phone_number, email, occupancy_type, avatar_url')
          .eq('flat_id', flatId)
          .eq('status', 'APPROVED');

      return (res as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) {
      return [];
    }
  }
}
