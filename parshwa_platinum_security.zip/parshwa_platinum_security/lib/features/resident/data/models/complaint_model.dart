import '../../domain/entities/complaint.dart';

class ComplaintModel extends Complaint {
  const ComplaintModel({
    required super.id,
    required super.flatId,
    required super.residentId,
    required super.category,
    required super.title,
    required super.description,
    super.photoUrl,
    required super.status,
    super.adminNotes,
    required super.createdAt,
    required super.updatedAt,
  });

  factory ComplaintModel.fromJson(Map<String, dynamic> json) {
    return ComplaintModel(
      id: json['id'] as String,
      flatId: json['flat_id'] as String,
      residentId: json['resident_id'] as String,
      category: json['category'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      photoUrl: json['photo_url'] as String?,
      status: json['status'] as String? ?? 'SUBMITTED',
      adminNotes: json['admin_notes'] as String?,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'flat_id': flatId,
      'resident_id': residentId,
      'category': category,
      'title': title,
      'description': description,
      'photo_url': photoUrl,
      'status': status,
      'admin_notes': adminNotes,
    };
  }
}
