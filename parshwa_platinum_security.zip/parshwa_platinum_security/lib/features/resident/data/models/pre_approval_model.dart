import '../../domain/entities/pre_approval.dart';

class PreApprovalModel extends PreApproval {
  const PreApprovalModel({
    required super.id,
    required super.flatId,
    required super.residentId,
    required super.visitorName,
    super.visitorPhone,
    required super.purpose,
    super.vehicleNumber,
    required super.expectedArrival,
    required super.expiresAt,
    required super.otpCode,
    required super.qrCodeData,
    required super.status,
    super.usedAt,
    required super.createdAt,
  });

  factory PreApprovalModel.fromJson(Map<String, dynamic> json) {
    return PreApprovalModel(
      id: json['id'] as String,
      flatId: json['flat_id'] as String,
      residentId: json['resident_id'] as String,
      visitorName: json['visitor_name'] as String,
      visitorPhone: json['visitor_phone'] as String?,
      purpose: json['purpose'] as String? ?? 'GUEST',
      vehicleNumber: json['vehicle_number'] as String?,
      expectedArrival: DateTime.parse(json['expected_arrival'] as String),
      expiresAt: DateTime.parse(json['expires_at'] as String),
      otpCode: json['otp_code'] as String,
      qrCodeData: json['qr_code_data'] as String,
      status: json['status'] as String? ?? 'ACTIVE',
      usedAt: json['used_at'] != null ? DateTime.parse(json['used_at'] as String) : null,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'flat_id': flatId,
      'resident_id': residentId,
      'visitor_name': visitorName,
      'visitor_phone': visitorPhone,
      'purpose': purpose,
      'vehicle_number': vehicleNumber,
      'expected_arrival': expectedArrival.toIso8601String(),
      'expires_at': expiresAt.toIso8601String(),
      'otp_code': otpCode,
      'qr_code_data': qrCodeData,
      'status': status,
    };
  }
}
