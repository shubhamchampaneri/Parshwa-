import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../guard/domain/entities/visitor_log.dart';
import '../domain/entities/pre_approval.dart';
import '../domain/repositories/resident_repository.dart';
import '../data/repositories/resident_repository_impl.dart';

class ResidentDashboardState {
  final List<VisitorLog> todayVisitors;
  final List<PreApproval> activePreApprovals;
  final String deliveryPreference;
  final String? deliveryInstructions;
  final bool isLoading;
  final String? errorMessage;
  final String? successMessage;

  const ResidentDashboardState({
    this.todayVisitors = const [],
    this.activePreApprovals = const [],
    this.deliveryPreference = 'ASK_FIRST',
    this.deliveryInstructions,
    this.isLoading = false,
    this.errorMessage,
    this.successMessage,
  });

  ResidentDashboardState copyWith({
    List<VisitorLog>? todayVisitors,
    List<PreApproval>? activePreApprovals,
    String? deliveryPreference,
    String? deliveryInstructions,
    bool? isLoading,
    String? errorMessage,
    String? successMessage,
    bool clearErrors = false,
  }) {
    return ResidentDashboardState(
      todayVisitors: todayVisitors ?? this.todayVisitors,
      activePreApprovals: activePreApprovals ?? this.activePreApprovals,
      deliveryPreference: deliveryPreference ?? this.deliveryPreference,
      deliveryInstructions: deliveryInstructions ?? this.deliveryInstructions,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearErrors ? null : errorMessage,
      successMessage: clearErrors ? null : successMessage,
    );
  }
}

final residentDashboardControllerProvider =
    StateNotifierProvider.family<ResidentDashboardController, ResidentDashboardState, String>(
  (ref, flatId) {
    final residentRepo = ref.watch(residentRepositoryProvider);
    return ResidentDashboardController(residentRepo, flatId);
  },
);

class ResidentDashboardController extends StateNotifier<ResidentDashboardState> {
  final ResidentRepository _residentRepo;
  final String _flatId;

  ResidentDashboardController(this._residentRepo, this._flatId)
      : super(const ResidentDashboardState(isLoading: true)) {
    loadDashboardData();
  }

  Future<void> loadDashboardData() async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final visitors = await _residentRepo.getTodayVisitors(_flatId);
      final passes = await _residentRepo.getPreApprovals(_flatId);
      final delPref = await _residentRepo.getDeliveryPreference(_flatId);

      state = state.copyWith(
        todayVisitors: visitors,
        activePreApprovals: passes.where((p) => p.isActive).toList(),
        deliveryPreference: delPref['delivery_preference'] as String? ?? 'ASK_FIRST',
        deliveryInstructions: delPref['delivery_instructions'] as String?,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }

  Future<bool> respondToVisitor(String logId, bool approve, {String? reason}) async {
    try {
      final res = await _residentRepo.respondToVisitorRequest(
        logId: logId,
        approve: approve,
        rejectionReason: reason,
      );

      if (res['conflict'] == true) {
        state = state.copyWith(
          errorMessage: 'Request was already updated by another flat resident.',
        );
      } else {
        state = state.copyWith(
          successMessage: approve ? 'Visitor approved for entry' : 'Visitor entry denied',
        );
      }
      await loadDashboardData();
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
      return false;
    }
  }

  Future<void> updateDeliveryPreference(String preference, String? instructions) async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      await _residentRepo.updateDeliveryPreference(
        flatId: _flatId,
        preference: preference,
        instructions: instructions,
      );
      state = state.copyWith(
        deliveryPreference: preference,
        deliveryInstructions: instructions,
        isLoading: false,
        successMessage: 'Delivery preference updated successfully',
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }
}
