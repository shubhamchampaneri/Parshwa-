import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/empty_state_view.dart';
import '../../../../core/widgets/loading_shimmer.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../guard/domain/entities/visitor_log.dart';
import '../../data/repositories/resident_repository_impl.dart';

class VisitorHistoryScreen extends ConsumerStatefulWidget {
  const VisitorHistoryScreen({super.key});

  @override
  ConsumerState<VisitorHistoryScreen> createState() => _VisitorHistoryScreenState();
}

class _VisitorHistoryScreenState extends ConsumerState<VisitorHistoryScreen> {
  final _searchController = TextEditingController();
  String _selectedStatus = 'ALL';
  List<VisitorLog> _logs = [];
  bool _isLoading = true;

  final List<String> _statusFilters = ['ALL', 'INSIDE', 'APPROVED', 'REJECTED', 'EXITED'];

  @override
  void initState() {
    super.initState();
    _fetchHistory();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchHistory() async {
    setState(() => _isLoading = true);
    final user = ref.read(authControllerProvider).userProfile;
    if (user?.flatId == null) return;

    try {
      final repo = ref.read(residentRepositoryProvider);
      final list = await repo.getVisitorHistory(
        user!.flatId!,
        searchQuery: _searchController.text.trim(),
        statusFilter: _selectedStatus,
      );
      if (mounted) {
        setState(() {
          _logs = list;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Visitor History'),
      ),
      body: Column(
        children: [
          // Search & Filter Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: TextField(
              controller: _searchController,
              onChanged: (_) => _fetchHistory(),
              decoration: InputDecoration(
                hintText: 'Search by visitor name, phone, or vehicle...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _fetchHistory();
                        },
                      )
                    : null,
              ),
            ),
          ),

          // Status Filter Horizontal Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
            child: Row(
              children: _statusFilters.map((st) {
                final isSelected = _selectedStatus == st;
                return Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: FilterChip(
                    label: Text(st),
                    selected: isSelected,
                    onSelected: (val) {
                      setState(() => _selectedStatus = st);
                      _fetchHistory();
                    },
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),

          // Visitor List
          Expanded(
            child: RefreshIndicator(
              onRefresh: _fetchHistory,
              child: _isLoading
                  ? ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: 5,
                      itemBuilder: (_, __) => const Padding(
                        padding: EdgeInsets.only(bottom: 12.0),
                        child: LoadingShimmer(width: double.infinity, height: 80),
                      ),
                    )
                  : _logs.isEmpty
                      ? const EmptyStateView(
                          icon: Icons.history,
                          title: 'No Visitor History Found',
                          message: 'There are no visitor logs matching your current filter criteria.',
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _logs.length,
                          itemBuilder: (context, index) {
                            final v = _logs[index];
                            return Card(
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: AppColors.primaryLight.withOpacity(0.12),
                                  backgroundImage: v.visitorPhotoUrl != null
                                      ? NetworkImage(v.visitorPhotoUrl!)
                                      : null,
                                  child: v.visitorPhotoUrl == null
                                      ? const Icon(Icons.person, color: AppColors.primary)
                                      : null,
                                ),
                                title: Text(
                                  v.visitorName,
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 2),
                                    Text('${v.purpose} • ${DateFormatter.formatDateTime(v.createdAt)}'),
                                    if (v.exitTime != null)
                                      Text(
                                        'Exited: ${DateFormatter.formatTime(v.exitTime)}',
                                        style: const TextStyle(fontSize: 11, color: Colors.grey),
                                      ),
                                    if (v.vehicleNumber != null && v.vehicleNumber!.isNotEmpty)
                                      Text(
                                        'Vehicle: ${v.vehicleNumber}',
                                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
                                      ),
                                  ],
                                ),
                                trailing: StatusBadge(status: v.status),
                                isThreeLine: true,
                              ),
                            );
                          },
                        ),
            ),
          ),
        ],
      ),
    );
  }
}
