import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/empty_state_view.dart';
import '../../../../core/widgets/loading_shimmer.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../guard/domain/entities/visitor_log.dart';
import '../../data/repositories/resident_repository_impl.dart';
import '../controllers/resident_dashboard_controller.dart';
import '../widgets/visitor_approval_dialog.dart';

final pendingApprovalsStreamProvider = StreamProvider.family<List<VisitorLog>, String>((ref, flatId) {
  final residentRepo = ref.watch(residentRepositoryProvider);
  return residentRepo.watchPendingApprovals(flatId);
});

class ResidentHomeScreen extends ConsumerStatefulWidget {
  const ResidentHomeScreen({super.key});

  @override
  ConsumerState<ResidentHomeScreen> createState() => _ResidentHomeScreenState();
}

class _ResidentHomeScreenState extends ConsumerState<ResidentHomeScreen> {
  String? _shownApprovalLogId;

  void _listenForLiveApprovals(String flatId) {
    ref.listen<AsyncValue<List<VisitorLog>>>(
      pendingApprovalsStreamProvider(flatId),
      (previous, next) {
        next.whenData((pendingList) {
          if (pendingList.isNotEmpty) {
            final latest = pendingList.first;
            if (_shownApprovalLogId != latest.id) {
              _shownApprovalLogId = latest.id;
              _showApprovalModal(latest, flatId);
            }
          }
        });
      },
    );
  }

  void _showApprovalModal(VisitorLog visitor, String flatId) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      builder: (ctx) => VisitorApprovalDialog(
        visitor: visitor,
        onApprove: () async {
          Navigator.pop(ctx);
          await ref.read(residentDashboardControllerProvider(flatId).notifier).respondToVisitor(
                visitor.id,
                true,
              );
        },
        onDeny: (reason) async {
          Navigator.pop(ctx);
          await ref.read(residentDashboardControllerProvider(flatId).notifier).respondToVisitor(
                visitor.id,
                false,
                reason: reason,
              );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authControllerProvider);
    final user = authState.userProfile;
    final flatId = user?.flatId ?? '';
    final flatNumber = user?.flatNumber ?? '---';

    if (flatId.isNotEmpty) {
      _listenForLiveApprovals(flatId);
    }

    final dashboardState = ref.watch(residentDashboardControllerProvider(flatId));
    final controller = ref.read(residentDashboardControllerProvider(flatId).notifier);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Flat $flatNumber',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'Parshwa Platinum',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.emergency_share, color: AppColors.sosRed),
            tooltip: 'Emergency SOS',
            onPressed: () => context.push('/resident/sos'),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            tooltip: 'Profile',
            onPressed: () => context.push('/resident/profile'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: controller.loadDashboardData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Delivery Preference Alert Banner
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: dashboardState.deliveryPreference == 'LEAVE_AT_GATE'
                      ? AppColors.successContainer
                      : AppColors.primaryLight.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(
                      dashboardState.deliveryPreference == 'LEAVE_AT_GATE'
                          ? Icons.check_circle_outline
                          : Icons.notifications_active_outlined,
                      color: dashboardState.deliveryPreference == 'LEAVE_AT_GATE'
                          ? AppColors.success
                          : AppColors.primary,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Gate Delivery Preference',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          Text(
                            dashboardState.deliveryPreference == 'LEAVE_AT_GATE'
                                ? 'Guards can accept parcels at security gate'
                                : 'Guard must request approval before delivery entry',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    TextButton(
                      onPressed: () => context.push('/resident/delivery-preferences'),
                      child: const Text('Change'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Quick Actions Grid (2x2)
              Text(
                'Quick Actions',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildActionCard(
                      context,
                      icon: Icons.qr_code_2_rounded,
                      color: AppColors.primary,
                      title: 'Pre-Approve',
                      subtitle: 'Generate OTP / Pass',
                      onTap: () => context.push('/resident/pre-approve'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildActionCard(
                      context,
                      icon: Icons.history_rounded,
                      color: AppColors.info,
                      title: 'History',
                      subtitle: 'Past visitor logs',
                      onTap: () => context.push('/resident/visitor-history'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildActionCard(
                      context,
                      icon: Icons.build_circle_outlined,
                      color: AppColors.secondary,
                      title: 'Complaints',
                      subtitle: 'Water, Lift, etc.',
                      onTap: () => context.push('/resident/complaints'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildActionCard(
                      context,
                      icon: Icons.campaign_outlined,
                      color: Colors.deepPurple,
                      title: 'Notices',
                      subtitle: 'Society updates',
                      onTap: () => context.push('/notices'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Today's Visitors Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Today's Visitors",
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  if (dashboardState.todayVisitors.isNotEmpty)
                    Text(
                      '${dashboardState.todayVisitors.length} Total',
                      style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
                    ),
                ],
              ),
              const SizedBox(height: 12),

              if (dashboardState.isLoading)
                Column(
                  children: List.generate(
                    3,
                    (index) => const Padding(
                      padding: EdgeInsets.only(bottom: 12.0),
                      child: LoadingShimmer(width: double.infinity, height: 74),
                    ),
                  ),
                )
              else if (dashboardState.todayVisitors.isEmpty)
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: const EmptyStateView(
                    icon: Icons.no_accounts_outlined,
                    title: 'No Visitors Today',
                    message: 'When a visitor arrives at the gate, approval will appear here in real-time.',
                  ),
                )
              else
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: dashboardState.todayVisitors.length,
                  itemBuilder: (context, index) {
                    final v = dashboardState.todayVisitors[index];
                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppColors.primaryLight.withOpacity(0.15),
                          backgroundImage: v.visitorPhotoUrl != null
                              ? NetworkImage(v.visitorPhotoUrl!)
                              : null,
                          child: v.visitorPhotoUrl == null
                              ? const Icon(Icons.person, color: AppColors.primary)
                              : null,
                        ),
                        title: Text(v.visitorName, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text(
                          '${v.purpose} • ${DateFormatter.formatTime(v.createdAt)}',
                          style: const TextStyle(fontSize: 12),
                        ),
                        trailing: StatusBadge(status: v.status),
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionCard(
    BuildContext context, {
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.borderLight),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 12),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 2),
            Text(subtitle, style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
