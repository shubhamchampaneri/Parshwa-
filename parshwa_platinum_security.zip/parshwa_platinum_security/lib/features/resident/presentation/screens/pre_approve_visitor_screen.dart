import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/utils/input_validators.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../domain/entities/pre_approval.dart';
import '../../data/repositories/resident_repository_impl.dart';

class PreApproveVisitorScreen extends ConsumerStatefulWidget {
  const PreApproveVisitorScreen({super.key});

  @override
  ConsumerState<PreApproveVisitorScreen> createState() => _PreApproveVisitorScreenState();
}

class _PreApproveVisitorScreenState extends ConsumerState<PreApproveVisitorScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _vehicleController = TextEditingController();

  String _purpose = 'GUEST';
  DateTime _expectedArrival = DateTime.now();
  bool _isSubmitting = false;

  final List<String> _purposes = ['GUEST', 'DELIVERY', 'CAB', 'SERVICE', 'OTHER'];

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _vehicleController.dispose();
    super.dispose();
  }

  Future<void> _pickDateTime() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _expectedArrival,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (date == null || !mounted) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_expectedArrival),
    );
    if (time == null || !mounted) return;

    setState(() {
      _expectedArrival = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    });
  }

  Future<void> _handleGeneratePass() async {
    if (!_formKey.currentState!.validate()) return;

    final user = ref.read(authControllerProvider).userProfile;
    if (user?.flatId == null) return;

    setState(() => _isSubmitting = true);
    try {
      final residentRepo = ref.read(residentRepositoryProvider);
      final pass = await residentRepo.createPreApproval(
        flatId: user!.flatId!,
        visitorName: _nameController.text.trim(),
        visitorPhone: _phoneController.text.trim().isNotEmpty ? _phoneController.text.trim() : null,
        purpose: _purpose,
        vehicleNumber: _vehicleController.text.trim().isNotEmpty ? _vehicleController.text.trim() : null,
        expectedArrival: _expectedArrival,
      );

      if (mounted) {
        setState(() => _isSubmitting = false);
        _showPassDialog(pass, user.flatNumber ?? '');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSubmitting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error creating pass: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  void _showPassDialog(PreApproval pass, String flatNumber) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Center(
          child: Text('Visitor Pass Generated', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Pass for ${pass.visitorName}',
              style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
            ),
            const SizedBox(height: 16),

            // OTP Box
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.primaryLight.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary, width: 1.5),
              ),
              child: Text(
                pass.otpCode,
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 6,
                  color: AppColors.primary,
                ),
              ),
            ),
            const SizedBox(height: 16),

            // QR Code
            SizedBox(
              width: 160,
              height: 160,
              child: QrImageView(
                data: pass.qrCodeData,
                version: QrVersions.auto,
                size: 160.0,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Valid on ${DateFormatter.formatDate(pass.expectedArrival)} until midnight',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context); // Return to dashboard
            },
            child: const Text('Done'),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.success),
            icon: const Icon(Icons.share, color: Colors.white, size: 18),
            label: const Text('Share Pass', style: TextStyle(color: Colors.white)),
            onPressed: () {
              Share.share(
                'Parshwa Platinum Visitor Pass for Flat $flatNumber\n'
                'Visitor: ${pass.visitorName}\n'
                'Date: ${DateFormatter.formatDate(pass.expectedArrival)}\n'
                'Gate OTP: ${pass.otpCode}\n\n'
                'Show this OTP or QR pass at the security gate for instant entry.',
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pre-Approve Visitor'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Generate One-Time Gate Pass',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Guest can show the 6-digit OTP or QR code to the guard for instant entry without ringing your phone.',
                style: TextStyle(color: AppColors.textSecondaryLight),
              ),
              const SizedBox(height: 24),

              AppTextField(
                label: 'Visitor Full Name',
                hint: 'e.g. Rahul Sharma',
                controller: _nameController,
                prefixIcon: const Icon(Icons.person_outline),
                validator: InputValidators.validateName,
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 16),

              AppTextField(
                label: 'Mobile Number (Optional)',
                hint: '10-digit mobile number',
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                prefixIcon: const Icon(Icons.phone_outlined),
              ),
              const SizedBox(height: 16),

              Text(
                'Visit Purpose',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: _purposes.map((p) {
                  final isSelected = _purpose == p;
                  return ChoiceChip(
                    label: Text(p),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) setState(() => _purpose = p);
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              // Expected Date & Time Picker Card
              Text(
                'Expected Date & Time',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 8),
              InkWell(
                onTap: _pickDateTime,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.calendar_today_outlined, size: 20, color: AppColors.primary),
                          const SizedBox(width: 12),
                          Text(
                            DateFormatter.formatDateTime(_expectedArrival),
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      const Text('Change', style: TextStyle(color: AppColors.primaryLight)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              AppTextField(
                label: 'Vehicle Plate (Optional)',
                hint: 'e.g. GJ-01-AB-1234',
                controller: _vehicleController,
                prefixIcon: const Icon(Icons.directions_car_outlined),
                textCapitalization: TextCapitalization.characters,
              ),
              const SizedBox(height: 32),

              AppButton(
                label: 'Generate Pass & QR Code',
                isLoading: _isSubmitting,
                icon: Icons.qr_code,
                onPressed: _handleGeneratePass,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
