import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../controllers/resident_dashboard_controller.dart';

class DeliveryPreferencesScreen extends ConsumerStatefulWidget {
  const DeliveryPreferencesScreen({super.key});

  @override
  ConsumerState<DeliveryPreferencesScreen> createState() => _DeliveryPreferencesScreenState();
}

class _DeliveryPreferencesScreenState extends ConsumerState<DeliveryPreferencesScreen> {
  late String _preference;
  late TextEditingController _instructionsController;
  bool _initialized = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _instructionsController = TextEditingController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      final user = ref.read(authControllerProvider).userProfile;
      if (user?.flatId != null) {
        final state = ref.read(residentDashboardControllerProvider(user!.flatId!));
        _preference = state.deliveryPreference;
        _instructionsController.text = state.deliveryInstructions ?? '';
      } else {
        _preference = 'ASK_FIRST';
      }
      _initialized = true;
    }
  }

  @override
  void dispose() {
    _instructionsController.dispose();
    super.dispose();
  }

  Future<void> _handleSave() async {
    final user = ref.read(authControllerProvider).userProfile;
    if (user?.flatId == null) return;

    setState(() => _isSaving = true);
    await ref.read(residentDashboardControllerProvider(user!.flatId!).notifier).updateDeliveryPreference(
          _preference,
          _instructionsController.text.trim().isNotEmpty ? _instructionsController.text.trim() : null,
        );

    if (mounted) {
      setState(() => _isSaving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Delivery preferences saved successfully'),
          backgroundColor: AppColors.success,
        ),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gate Delivery Settings'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Parcel & Package Handling',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Select how security guards should handle Amazon, Flipkart, Swiggy, and courier deliveries at the gate.',
              style: TextStyle(color: AppColors.textSecondaryLight),
            ),
            const SizedBox(height: 24),

            // Radio Card 1: Leave at Gate
            _buildSelectionCard(
              title: 'Allow delivery to leave at gate',
              description: 'Guards will accept and store packages at the security desk until you collect them.',
              icon: Icons.inventory_2_outlined,
              value: 'LEAVE_AT_GATE',
            ),
            const SizedBox(height: 16),

            // Radio Card 2: Ask First
            _buildSelectionCard(
              title: 'Always ask me first',
              description: 'Guards must send an in-app approval request before allowing any delivery agent to enter or drop packages.',
              icon: Icons.notifications_active_outlined,
              value: 'ASK_FIRST',
            ),
            const SizedBox(height: 24),

            AppTextField(
              label: 'Special Delivery Instructions (Optional)',
              hint: 'e.g. Do not ring doorbell between 2 PM and 4 PM.',
              controller: _instructionsController,
              maxLines: 3,
            ),
            const SizedBox(height: 32),

            AppButton(
              label: 'Save Preferences',
              isLoading: _isSaving,
              onPressed: _handleSave,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectionCard({
    required String title,
    required String description,
    required IconData icon,
    required String value,
  }) {
    final isSelected = _preference == value;

    return InkWell(
      onTap: () => setState(() => _preference = value),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.borderLight,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Radio<String>(
              value: value,
              groupValue: _preference,
              onChanged: (val) {
                if (val != null) setState(() => _preference = val);
              },
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(icon, size: 20, color: isSelected ? AppColors.primary : Colors.grey),
                      const SizedBox(width: 8),
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: isSelected ? AppColors.primary : null,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    description,
                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
