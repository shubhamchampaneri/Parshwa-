import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../data/repositories/resident_repository_impl.dart';

class ResidentProfileScreen extends ConsumerStatefulWidget {
  const ResidentProfileScreen({super.key});

  @override
  ConsumerState<ResidentProfileScreen> createState() => _ResidentProfileScreenState();
}

class _ResidentProfileScreenState extends ConsumerState<ResidentProfileScreen> {
  List<Map<String, dynamic>> _flatMembers = [];
  bool _loadingMembers = true;
  String _selectedLanguage = 'en';

  @override
  void initState() {
    super.initState();
    _fetchMembers();
  }

  Future<void> _fetchMembers() async {
    final user = ref.read(authControllerProvider).userProfile;
    if (user?.flatId == null) return;

    try {
      final repo = ref.read(residentRepositoryProvider);
      final members = await repo.getFlatMembers(user!.flatId!);
      if (mounted) {
        setState(() {
          _flatMembers = members;
          _loadingMembers = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingMembers = false);
    }
  }

  void _showLanguageSelector() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Language / ભાષા પસંદ કરો / भाषा चुनें',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Text('🇬🇧', style: TextStyle(fontSize: 24)),
              title: const Text('English'),
              trailing: _selectedLanguage == 'en' ? const Icon(Icons.check, color: AppColors.primary) : null,
              onTap: () {
                setState(() => _selectedLanguage = 'en');
                Navigator.pop(ctx);
              },
            ),
            ListTile(
              leading: const Text('🇮🇳', style: TextStyle(fontSize: 24)),
              title: const Text('ગુજરાતી (Gujarati)'),
              trailing: _selectedLanguage == 'gu' ? const Icon(Icons.check, color: AppColors.primary) : null,
              onTap: () {
                setState(() => _selectedLanguage = 'gu');
                Navigator.pop(ctx);
              },
            ),
            ListTile(
              leading: const Text('🇮🇳', style: TextStyle(fontSize: 24)),
              title: const Text('हिंदी (Hindi)'),
              trailing: _selectedLanguage == 'hi' ? const Icon(Icons.check, color: AppColors.primary) : null,
              onTap: () {
                setState(() => _selectedLanguage = 'hi');
                Navigator.pop(ctx);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authControllerProvider).userProfile;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Resident Profile & Flat'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // User Profile Card
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 44,
                    backgroundColor: AppColors.primaryLight.withOpacity(0.15),
                    child: const Icon(Icons.person, size: 48, color: AppColors.primary),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    user?.fullName ?? '',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user?.email ?? '',
                    style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
                  ),
                  Text(
                    'Phone: ${user?.phoneNumber ?? ""}',
                    style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Flat Capacity Card (Max 4 residents)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Flat ${user?.flatNumber ?? ""} Members',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.primaryLight.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '${_flatMembers.length} of ${AppConstants.maxResidentsPerFlat} Used',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (_loadingMembers)
                      const LinearProgressIndicator()
                    else
                      Column(
                        children: _flatMembers.map((m) {
                          return ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: const CircleAvatar(
                              child: Icon(Icons.person_outline),
                            ),
                            title: Text(m['full_name'] as String? ?? 'Member'),
                            subtitle: Text('${m["occupancy_type"] ?? "Owner"} • ${m["phone_number"] ?? ""}'),
                          );
                        }).toList(),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Settings Section
            Text(
              'App & Security Settings',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 8),

            ListTile(
              leading: const Icon(Icons.language_rounded, color: AppColors.primary),
              title: const Text('Language / ભાષા / भाषा'),
              subtitle: Text(
                _selectedLanguage == 'gu'
                    ? 'ગુજરાતી (Gujarati)'
                    : _selectedLanguage == 'hi'
                        ? 'हिंदी (Hindi)'
                        : 'English',
              ),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: _showLanguageSelector,
            ),
            const Divider(),

            ListTile(
              leading: const Icon(Icons.pin_outlined, color: AppColors.primary),
              title: const Text('Change Security PIN'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () => context.push('/setup-pin'),
            ),
            const Divider(),

            const SizedBox(height: 32),
            AppButton(
              label: 'Sign Out',
              isOutlined: true,
              icon: Icons.logout,
              foregroundColor: AppColors.error,
              onPressed: () async {
                await ref.read(authControllerProvider.notifier).signOut();
                if (context.mounted) context.go('/login');
              },
            ),
          ],
        ),
      ),
    );
  }
}
