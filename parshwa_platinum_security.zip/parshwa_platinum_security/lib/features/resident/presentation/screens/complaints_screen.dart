import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/utils/input_validators.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/empty_state_view.dart';
import '../../../../core/widgets/loading_shimmer.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../domain/entities/complaint.dart';
import '../../data/repositories/resident_repository_impl.dart';

class ComplaintsScreen extends ConsumerStatefulWidget {
  const ComplaintsScreen({super.key});

  @override
  ConsumerState<ComplaintsScreen> createState() => _ComplaintsScreenState();
}

class _ComplaintsScreenState extends ConsumerState<ComplaintsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();

  String _category = 'WATER';
  File? _selectedPhoto;
  bool _isSubmitting = false;
  bool _isLoadingList = true;
  List<Complaint> _complaints = [];

  final List<String> _categories = [
    'WATER',
    'LIFT',
    'PARKING',
    'CLEANING',
    'ELECTRICAL',
    'SECURITY',
    'OTHER'
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadComplaints();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  Future<void> _loadComplaints() async {
    setState(() => _isLoadingList = true);
    final user = ref.read(authControllerProvider).userProfile;
    if (user?.flatId == null) return;

    try {
      final repo = ref.read(residentRepositoryProvider);
      final list = await repo.getComplaints(user!.flatId!);
      if (mounted) {
        setState(() {
          _complaints = list;
          _isLoadingList = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoadingList = false);
    }
  }

  Future<void> _pickPhoto(ImageSource source) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: source);
    if (picked != null) {
      setState(() => _selectedPhoto = File(picked.path));
    }
  }

  Future<void> _handleSubmitComplaint() async {
    if (!_formKey.currentState!.validate()) return;

    final user = ref.read(authControllerProvider).userProfile;
    if (user?.flatId == null) return;

    setState(() => _isSubmitting = true);
    try {
      final repo = ref.read(residentRepositoryProvider);
      await repo.fileComplaint(
        flatId: user!.flatId!,
        category: _category,
        title: _titleController.text.trim(),
        description: _descController.text.trim(),
        photoFile: _selectedPhoto,
      );

      if (mounted) {
        setState(() {
          _isSubmitting = false;
          _titleController.clear();
          _descController.clear();
          _selectedPhoto = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Complaint filed successfully with Management Committee'),
            backgroundColor: AppColors.success,
          ),
        );
        _tabController.animateTo(0);
        _loadComplaints();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSubmitting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to submit: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Maintenance & Complaints'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'My Complaints'),
            Tab(text: '+ File New'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab 1: Past Complaints
          RefreshIndicator(
            onRefresh: _loadComplaints,
            child: _isLoadingList
                ? ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: 4,
                    itemBuilder: (_, __) => const Padding(
                      padding: EdgeInsets.only(bottom: 12.0),
                      child: LoadingShimmer(width: double.infinity, height: 96),
                    ),
                  )
                : _complaints.isEmpty
                    ? const EmptyStateView(
                        icon: Icons.check_circle_outline,
                        title: 'No Active Complaints',
                        message: 'All society requests for your flat are resolved or none filed.',
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _complaints.length,
                        itemBuilder: (context, index) {
                          final c = _complaints[index];
                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: AppColors.primaryLight.withOpacity(0.12),
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Text(
                                          c.category,
                                          style: const TextStyle(
                                            color: AppColors.primary,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 11,
                                          ),
                                        ),
                                      ),
                                      StatusBadge(status: c.status),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    c.title,
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    c.description,
                                    style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
                                  ),
                                  if (c.adminNotes != null && c.adminNotes!.isNotEmpty) ...[
                                    const SizedBox(height: 10),
                                    Container(
                                      padding: const EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                        color: Colors.amber.shade50,
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(color: Colors.amber.shade200),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          const Icon(Icons.admin_panel_settings, size: 16, color: Colors.brown),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              'Committee Note: ${c.adminNotes}',
                                              style: const TextStyle(fontSize: 12, color: Colors.brown),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                  const SizedBox(height: 8),
                                  Text(
                                    DateFormatter.formatDateTime(c.createdAt),
                                    style: const TextStyle(fontSize: 11, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),

          // Tab 2: New Complaint Form
          SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Category',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: _categories.map((cat) {
                      final isSelected = _category == cat;
                      return ChoiceChip(
                        label: Text(cat),
                        selected: isSelected,
                        onSelected: (val) {
                          if (val) setState(() => _category = cat);
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),

                  AppTextField(
                    label: 'Subject / Title',
                    hint: 'e.g. Low water pressure on 4th floor',
                    controller: _titleController,
                    validator: (v) => InputValidators.validateRequired(v, 'Subject'),
                  ),
                  const SizedBox(height: 16),

                  AppTextField(
                    label: 'Description',
                    hint: 'Describe the issue in detail...',
                    controller: _descController,
                    maxLines: 4,
                    validator: (v) => InputValidators.validateRequired(v, 'Description'),
                  ),
                  const SizedBox(height: 16),

                  // Photo Attachment
                  Text(
                    'Photo Attachment (Optional)',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 8),
                  if (_selectedPhoto != null)
                    Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(
                            _selectedPhoto!,
                            height: 160,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Positioned(
                          top: 8,
                          right: 8,
                          child: CircleAvatar(
                            backgroundColor: Colors.black54,
                            child: IconButton(
                              icon: const Icon(Icons.close, color: Colors.white, size: 20),
                              onPressed: () => setState(() => _selectedPhoto = null),
                            ),
                          ),
                        ),
                      ],
                    )
                  else
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: const Icon(Icons.camera_alt_outlined),
                            label: const Text('Take Photo'),
                            onPressed: () => _pickPhoto(ImageSource.camera),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: const Icon(Icons.photo_library_outlined),
                            label: const Text('Gallery'),
                            onPressed: () => _pickPhoto(ImageSource.gallery),
                          ),
                        ),
                      ],
                    ),
                  const SizedBox(height: 32),

                  AppButton(
                    label: 'Submit Complaint',
                    isLoading: _isSubmitting,
                    onPressed: _handleSubmitComplaint,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
