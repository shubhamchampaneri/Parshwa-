import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../data/repositories/resident_repository_impl.dart';

class ResidentSosScreen extends ConsumerStatefulWidget {
  const ResidentSosScreen({super.key});

  @override
  ConsumerState<ResidentSosScreen> createState() => _ResidentSosScreenState();
}

class _ResidentSosScreenState extends ConsumerState<ResidentSosScreen> with SingleTickerProviderStateMixin {
  String _emergencyType = 'GENERAL';
  bool _isHolding = false;
  double _holdProgress = 0.0;
  Timer? _holdTimer;
  bool _sosActive = false;

  final List<Map<String, dynamic>> _types = [
    {'type': 'GENERAL', 'label': 'General Assistance', 'icon': Icons.warning_rounded},
    {'type': 'MEDICAL', 'label': 'Medical Emergency', 'icon': Icons.medical_services_rounded},
    {'type': 'FIRE', 'label': 'Fire Hazard', 'icon': Icons.local_fire_department_rounded},
    {'type': 'THREAT', 'label': 'Intruder / Threat', 'icon': Icons.security_rounded},
    {'type': 'LIFT', 'label': 'Lift Trapped', 'icon': Icons.elevator_rounded},
  ];

  void _startHolding() {
    setState(() {
      _isHolding = true;
      _holdProgress = 0.0;
    });

    _holdTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      setState(() {
        _holdProgress += 0.025; // Reaches 1.0 in ~2 seconds (40 ticks * 50ms)
        if (_holdProgress >= 1.0) {
          timer.cancel();
          _isHolding = false;
          _triggerSos();
        }
      });
    });
  }

  void _stopHolding() {
    _holdTimer?.cancel();
    if (!_sosActive) {
      setState(() {
        _isHolding = false;
        _holdProgress = 0.0;
      });
    }
  }

  Future<void> _triggerSos() async {
    HapticFeedback.heavyImpact();
    final user = ref.read(authControllerProvider).userProfile;
    if (user?.flatId == null) return;

    try {
      final repo = ref.read(residentRepositoryProvider);
      await repo.triggerEmergencySOS(
        flatId: user!.flatId!,
        emergencyType: _emergencyType,
      );

      setState(() => _sosActive = true);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to trigger SOS: $e'), backgroundColor: AppColors.error),
      );
    }
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authControllerProvider).userProfile;

    if (_sosActive) {
      return Scaffold(
        backgroundColor: AppColors.sosRedDark,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.warning_amber_rounded, size: 88, color: Colors.white),
                const SizedBox(height: 24),
                const Text(
                  'SOS BROADCAST ACTIVE',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'All on-duty security guards have been alerted with sirens for Flat ${user?.flatNumber ?? ""}.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16, color: Colors.white70),
                ),
                const SizedBox(height: 48),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: AppColors.sosRedDark,
                    minimumSize: const Size(double.infinity, 54),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Dismiss Alert Screen'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Emergency Security SOS'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              Text(
                'Hold Button for 2 Seconds',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Press and hold the button below to sound sirens at the guard gate and send an immediate dispatch alert.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textSecondaryLight),
              ),
              const SizedBox(height: 24),

              // Emergency Type selector
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: _types.map((t) {
                  final isSelected = _emergencyType == t['type'];
                  return ChoiceChip(
                    avatar: Icon(t['icon'] as IconData, size: 18),
                    label: Text(t['label'] as String),
                    selected: isSelected,
                    onSelected: (val) {
                      if (val) setState(() => _emergencyType = t['type'] as String);
                    },
                  );
                }).toList(),
              ),

              const Spacer(),

              // Circular Hold to Trigger Button with Animated Ring
              GestureDetector(
                onTapDown: (_) => _startHolding(),
                onTapUp: (_) => _stopHolding(),
                onTapCancel: _stopHolding,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 220,
                      height: 220,
                      child: CircularProgressIndicator(
                        value: _holdProgress,
                        strokeWidth: 10,
                        backgroundColor: AppColors.sosRed.withOpacity(0.2),
                        valueColor: const AlwaysStoppedAnimation<Color>(AppColors.sosRed),
                      ),
                    ),
                    Container(
                      width: 190,
                      height: 190,
                      decoration: BoxDecoration(
                        color: AppColors.sosRed,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.sosRed.withOpacity(_isHolding ? 0.6 : 0.3),
                            blurRadius: _isHolding ? 24 : 12,
                            spreadRadius: _isHolding ? 4 : 2,
                          ),
                        ],
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.touch_app_rounded, size: 54, color: Colors.white),
                          SizedBox(height: 6),
                          Text(
                            'HOLD SOS',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const Spacer(),
              const Text(
                'Parshwa Platinum Gate Security Response is active 24x7.',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
