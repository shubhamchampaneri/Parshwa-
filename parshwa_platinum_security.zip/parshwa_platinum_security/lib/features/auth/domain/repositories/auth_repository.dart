import '../entities/user_profile.dart';

abstract class AuthRepository {
  Future<UserProfile?> getCurrentProfile();
  Stream<UserProfile?> watchCurrentProfile();

  Future<UserProfile> signInWithEmailPassword({
    required String email,
    required String password,
  });

  Future<UserProfile> signInWithGoogle();

  Future<UserProfile> signUpResident({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String flatId,
    required String occupancyType,
  });

  Future<UserProfile> signUpGuard({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String inviteCode,
  });

  Future<void> sendPasswordResetEmail(String email);
  Future<void> signOut();
  Future<UserProfile> updateProfile({
    String? fullName,
    String? phoneNumber,
    String? avatarUrl,
  });

  Future<List<Map<String, dynamic>>> getFlatsList();
}
