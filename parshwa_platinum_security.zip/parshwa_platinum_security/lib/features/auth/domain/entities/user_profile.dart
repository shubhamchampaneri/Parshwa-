import '../../../../core/constants/app_constants.dart';

class UserProfile {
  final String id;
  final String email;
  final String fullName;
  final String phoneNumber;
  final UserRole role;
  final UserStatus status;
  final String? flatId;
  final String? flatNumber;
  final String? occupancyType;
  final String? avatarUrl;
  final String? rejectionReason;
  final DateTime createdAt;

  const UserProfile({
    required this.id,
    required this.email,
    required this.fullName,
    required this.phoneNumber,
    required this.role,
    required this.status,
    this.flatId,
    this.flatNumber,
    this.occupancyType,
    this.avatarUrl,
    this.rejectionReason,
    required this.createdAt,
  });

  bool get isApproved => status == UserStatus.approved;
  bool get isPending => status == UserStatus.pending;
  bool get isRejected => status == UserStatus.rejected;

  bool get isResident => role == UserRole.resident;
  bool get isGuard => role == UserRole.guard;
  bool get isAdmin => role == UserRole.admin;
}
