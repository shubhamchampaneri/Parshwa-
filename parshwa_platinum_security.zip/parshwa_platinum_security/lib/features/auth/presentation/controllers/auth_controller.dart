import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/security/biometric_service.dart';
import '../../../../core/security/pin_security_service.dart';
import '../../domain/entities/user_profile.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../data/repositories/auth_repository_impl.dart';

class AuthState {
  final UserProfile? userProfile;
  final bool isLoading;
  final bool isPinUnlocked;
  final bool hasPinConfigured;
  final String? errorMessage;
  final String? successMessage;

  const AuthState({
    this.userProfile,
    this.isLoading = false,
    this.isPinUnlocked = false,
    this.hasPinConfigured = false,
    this.errorMessage,
    this.successMessage,
  });

  bool get isAuthenticated => userProfile != null;
  bool get isApproved => userProfile?.isApproved ?? false;
  bool get isPending => userProfile?.isPending ?? false;
  bool get isRejected => userProfile?.isRejected ?? false;

  AuthState copyWith({
    UserProfile? userProfile,
    bool? isLoading,
    bool? isPinUnlocked,
    bool? hasPinConfigured,
    String? errorMessage,
    String? successMessage,
    bool clearUser = false,
    bool clearErrors = false,
  }) {
    return AuthState(
      userProfile: clearUser ? null : (userProfile ?? this.userProfile),
      isLoading: isLoading ?? this.isLoading,
      isPinUnlocked: isPinUnlocked ?? this.isPinUnlocked,
      hasPinConfigured: hasPinConfigured ?? this.hasPinConfigured,
      errorMessage: clearErrors ? null : errorMessage,
      successMessage: clearErrors ? null : successMessage,
    );
  }
}

final authControllerProvider = StateNotifierProvider<AuthController, AuthState>((ref) {
  final authRepo = ref.watch(authRepositoryProvider);
  final pinService = ref.watch(pinSecurityServiceProvider);
  final bioService = ref.watch(biometricServiceProvider);
  return AuthController(authRepo, pinService, bioService);
});

class AuthController extends StateNotifier<AuthState> {
  final AuthRepository _authRepo;
  final PinSecurityService _pinService;
  final BiometricService _bioService;

  AuthController(this._authRepo, this._pinService, this._bioService)
      : super(const AuthState(isLoading: true)) {
    checkInitialAuth();
  }

  Future<void> checkInitialAuth() async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final profile = await _authRepo.getCurrentProfile();
      final hasPin = await _pinService.hasPinSet();
      final isTimedOut = await _pinService.isSessionTimedOut();

      state = state.copyWith(
        userProfile: profile,
        hasPinConfigured: hasPin,
        isPinUnlocked: hasPin ? !isTimedOut : true, // If no pin set, unlocked until setup
        isLoading: false,
      );

      // Listen to profile updates (e.g. Admin approves pending resident)
      if (profile != null) {
        _listenToProfileChanges();
      }
    } catch (e) {
      state = state.copyWith(isLoading: false, clearUser: true);
    }
  }

  void _listenToProfileChanges() {
    _authRepo.watchCurrentProfile().listen((updatedProfile) {
      if (updatedProfile != null && mounted) {
        state = state.copyWith(userProfile: updatedProfile);
      }
    });
  }

  Future<bool> signInWithEmail(String email, String password) async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final profile = await _authRepo.signInWithEmailPassword(
        email: email,
        password: password,
      );
      final hasPin = await _pinService.hasPinSet();
      state = state.copyWith(
        userProfile: profile,
        hasPinConfigured: hasPin,
        isPinUnlocked: !hasPin, // Needs PIN setup if no PIN, else needs unlock
        isLoading: false,
      );
      _listenToProfileChanges();
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<bool> signInWithGoogle() async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final profile = await _authRepo.signInWithGoogle();
      final hasPin = await _pinService.hasPinSet();
      state = state.copyWith(
        userProfile: profile,
        hasPinConfigured: hasPin,
        isPinUnlocked: !hasPin,
        isLoading: false,
      );
      _listenToProfileChanges();
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<bool> signUpResident({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String flatId,
    required String occupancyType,
  }) async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final profile = await _authRepo.signUpResident(
        email: email,
        password: password,
        fullName: fullName,
        phoneNumber: phoneNumber,
        flatId: flatId,
        occupancyType: occupancyType,
      );
      final hasPin = await _pinService.hasPinSet();
      state = state.copyWith(
        userProfile: profile,
        hasPinConfigured: hasPin,
        isPinUnlocked: !hasPin,
        isLoading: false,
      );
      _listenToProfileChanges();
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<bool> signUpGuard({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String inviteCode,
  }) async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final profile = await _authRepo.signUpGuard(
        email: email,
        password: password,
        fullName: fullName,
        phoneNumber: phoneNumber,
        inviteCode: inviteCode,
      );
      final hasPin = await _pinService.hasPinSet();
      state = state.copyWith(
        userProfile: profile,
        hasPinConfigured: hasPin,
        isPinUnlocked: !hasPin,
        isLoading: false,
      );
      _listenToProfileChanges();
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<PinVerificationResult> unlockWithPin(String pin) async {
    final result = await _pinService.verifyPin(pin);
    if (result.isSuccess) {
      state = state.copyWith(isPinUnlocked: true, clearErrors: true);
    } else {
      state = state.copyWith(errorMessage: result.errorMessage);
    }
    return result;
  }

  Future<bool> unlockWithBiometrics() async {
    final authenticated = await _bioService.authenticateWithBiometrics();
    if (authenticated) {
      await _pinService.recordLastActive();
      state = state.copyWith(isPinUnlocked: true, clearErrors: true);
      return true;
    }
    return false;
  }

  Future<bool> setupPin(String pin, {bool enableBiometrics = false}) async {
    try {
      await _pinService.savePin(pin);
      if (enableBiometrics) {
        await _bioService.setBiometricsEnabled(true);
      }
      state = state.copyWith(
        hasPinConfigured: true,
        isPinUnlocked: true,
        clearErrors: true,
      );
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
      return false;
    }
  }

  Future<void> sendPasswordReset(String email) async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      await _authRepo.sendPasswordResetEmail(email);
      state = state.copyWith(
        isLoading: false,
        successMessage: 'Password reset instructions have been sent to your email.',
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }

  Future<void> signOut() async {
    await _authRepo.signOut();
    await _pinService.clearPin();
    state = const AuthState(isPinUnlocked: false, hasPinConfigured: false);
  }

  void lockSession() {
    if (state.hasPinConfigured) {
      state = state.copyWith(isPinUnlocked: false);
    }
  }
}
