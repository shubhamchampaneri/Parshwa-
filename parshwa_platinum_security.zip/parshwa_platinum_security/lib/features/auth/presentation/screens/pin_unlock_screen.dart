import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/widgets/numeric_keypad.dart';
import '../../../../core/widgets/status_badge.dart';
import '../controllers/auth_controller.dart';

class PinUnlockScreen extends ConsumerStatefulWidget {
  const PinUnlockScreen({super.key});

  @override
  ConsumerState<PinUnlockScreen> createState() => _PinUnlockScreenState();
}

class _PinUnlockScreenState extends ConsumerState<PinUnlockScreen> {
  String _enteredPin = '';
  String? _errorMessage;
  int _lockoutSeconds = 0;
  Timer? _lockoutTimer;

  @override
  void initState() {
    super.initState();
    // Attempt biometric unlock automatically if enabled
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _tryBiometricUnlock();
    });
  }

  @override
  void dispose() {
    _lockoutTimer?.cancel();
    super.dispose();
  }

  Future<void> _tryBiometricUnlock() async {
    final success = await ref.read(authControllerProvider.notifier).unlockWithBiometrics();
    if (success && mounted) {
      _proceedToDashboard();
    }
  }

  void _onDigitPressed(String digit) {
    if (_lockoutSeconds > 0) return;
    if (_enteredPin.length < 6) {
      setState(() {
        _enteredPin += digit;
        _errorMessage = null;
      });

      if (_enteredPin.length >= 4) {
        // Automatically check if 4 or 6 digits
        if (_enteredPin.length == 4 || _enteredPin.length == 6) {
          _verifyPin(_enteredPin);
        }
      }
    }
  }

  void _onDeletePressed() {
    if (_lockoutSeconds > 0) return;
    if (_enteredPin.isNotEmpty) {
      setState(() {
        _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
        _errorMessage = null;
      });
    }
  }

  Future<void> _verifyPin(String pin) async {
    final result = await ref.read(authControllerProvider.notifier).unlockWithPin(pin);
    if (!mounted) return;

    if (result.isSuccess) {
      _proceedToDashboard();
    } else {
      setState(() {
        _enteredPin = '';
        _errorMessage = result.errorMessage;
        if (result.isLockedOut) {
          _startLockoutTimer(result.lockoutSecondsRemaining);
        }
      });
    }
  }

  void _startLockoutTimer(int seconds) {
    _lockoutTimer?.cancel();
    setState(() => _lockoutSeconds = seconds);
    _lockoutTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_lockoutSeconds <= 1) {
        timer.cancel();
        setState(() {
          _lockoutSeconds = 0;
          _errorMessage = null;
        });
      } else {
        setState(() => _lockoutSeconds--);
      }
    });
  }

  void _proceedToDashboard() {
    final state = ref.read(authControllerProvider);
    if (state.isPending) {
      context.go('/pending-approval');
    } else if (state.userProfile?.isAdmin == true) {
      context.go('/admin/approvals');
    } else if (state.userProfile?.isGuard == true) {
      context.go('/guard/dashboard');
    } else {
      context.go('/resident/home');
    }
  }

  void _handleForgotPin() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Forgot Security PIN?'),
        content: const Text(
          'To reset your PIN, you will need to log out and sign in again with your email or Google account.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await ref.read(authControllerProvider.notifier).signOut();
              if (mounted) context.go('/login');
            },
            child: const Text('Log Out & Reset'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authControllerProvider);
    final user = authState.userProfile;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 36),
            CircleAvatar(
              radius: 36,
              backgroundColor: AppColors.primaryLight.withOpacity(0.2),
              child: const Icon(Icons.person, size: 40, color: AppColors.primary),
            ),
            const SizedBox(height: 12),
            Text(
              user?.fullName ?? 'Parshwa Platinum User',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 6),
            if (user != null)
              StatusBadge(status: user.role.name.toUpperCase()),
            const SizedBox(height: 24),
            Text(
              _lockoutSeconds > 0
                  ? 'Keypad Locked for 5 Minutes'
                  : 'Enter Security PIN',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: _lockoutSeconds > 0 ? AppColors.error : null,
              ),
            ),
            const SizedBox(height: 16),

            // PIN Dots Indicator
            if (_lockoutSeconds == 0)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(6, (index) {
                  final isFilled = index < _enteredPin.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isFilled ? AppColors.primary : Colors.grey.shade300,
                    ),
                  );
                }),
              )
            else
              Text(
                'Try again in 0${_lockoutSeconds ~/ 60}:${(_lockoutSeconds % 60).toString().padLeft(2, '0')}',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.error,
                ),
              ),

            const SizedBox(height: 16),
            if (_errorMessage != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  _errorMessage!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.error, fontWeight: FontWeight.w500),
                ),
              ),

            const Spacer(),

            TextButton(
              onPressed: _handleForgotPin,
              child: const Text('Forgot PIN?'),
            ),
            const SizedBox(height: 8),

            NumericKeypad(
              onDigitPressed: _onDigitPressed,
              onDeletePressed: _onDeletePressed,
              showBiometric: true,
              onBiometricPressed: _tryBiometricUnlock,
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
