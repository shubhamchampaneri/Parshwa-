import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/security/biometric_service.dart';
import '../../../../core/utils/input_validators.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/numeric_keypad.dart';
import '../controllers/auth_controller.dart';

class SetupPinScreen extends ConsumerStatefulWidget {
  const SetupPinScreen({super.key});

  @override
  ConsumerState<SetupPinScreen> createState() => _SetupPinScreenState();
}

class _SetupPinScreenState extends ConsumerState<SetupPinScreen> {
  String _pin = '';
  String _confirmPin = '';
  bool _isConfirming = false;
  bool _enableBiometrics = true;
  bool _hasBiometricsHardware = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _checkBiometrics();
  }

  Future<void> _checkBiometrics() async {
    final bioService = ref.read(biometricServiceProvider);
    final available = await bioService.isBiometricHardwareAvailable();
    if (mounted) {
      setState(() => _hasBiometricsHardware = available);
    }
  }

  void _onDigitPressed(String digit) {
    setState(() {
      _errorMessage = null;
      if (!_isConfirming) {
        if (_pin.length < 6) _pin += digit;
      } else {
        if (_confirmPin.length < 6) _confirmPin += digit;
      }
    });
  }

  void _onDeletePressed() {
    setState(() {
      _errorMessage = null;
      if (!_isConfirming) {
        if (_pin.isNotEmpty) _pin = _pin.substring(0, _pin.length - 1);
      } else {
        if (_confirmPin.isNotEmpty) {
          _confirmPin = _confirmPin.substring(0, _confirmPin.length - 1);
        }
      }
    });
  }

  Future<void> _handleNextOrSubmit() async {
    if (!_isConfirming) {
      final validation = InputValidators.validatePin(_pin);
      if (validation != null) {
        setState(() => _errorMessage = validation);
        return;
      }
      setState(() {
        _isConfirming = true;
        _errorMessage = null;
      });
    } else {
      if (_pin != _confirmPin) {
        setState(() {
          _errorMessage = 'PINs do not match. Please try again.';
          _confirmPin = '';
          _isConfirming = false;
        });
        return;
      }

      final success = await ref.read(authControllerProvider.notifier).setupPin(
            _pin,
            enableBiometrics: _enableBiometrics && _hasBiometricsHardware,
          );

      if (success && mounted) {
        final state = ref.read(authControllerProvider);
        if (state.isPending) {
          context.go('/pending-approval');
        } else if (state.userProfile?.isAdmin == true) {
          context.go('/admin/approvals');
        } else if (state.userProfile?.isGuard == true) {
          context.go('/guard/dashboard');
        } else {
          context.go('/resident/home');
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentCode = _isConfirming ? _confirmPin : _pin;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Setup Security PIN'),
        leading: _isConfirming
            ? IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => setState(() => _isConfirming = false),
              )
            : null,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 20),
            Text(
              _isConfirming ? 'Confirm Security PIN' : 'Create 4-6 Digit PIN',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              _isConfirming
                  ? 'Re-enter your PIN to verify'
                  : 'This PIN will be asked on app open to protect your flat controls',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textSecondaryLight),
            ),
            const SizedBox(height: 32),

            // PIN Dots Indicator
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(6, (index) {
                final isFilled = index < currentCode.length;
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isFilled ? AppColors.primary : Colors.grey.shade300,
                  ),
                );
              }),
            ),
            const SizedBox(height: 16),

            if (_errorMessage != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  _errorMessage!,
                  style: const TextStyle(color: AppColors.error, fontWeight: FontWeight.w600),
                ),
              ),

            if (_isConfirming && _hasBiometricsHardware) ...[
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: SwitchListTile(
                  title: const Text('Enable Biometric Unlock'),
                  subtitle: const Text('Use Fingerprint or Face ID for fast login'),
                  value: _enableBiometrics,
                  onChanged: (val) => setState(() => _enableBiometrics = val),
                ),
              ),
            ],

            const Spacer(),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: AppButton(
                label: _isConfirming ? 'Save PIN & Finish' : 'Continue',
                onPressed: currentCode.length >= 4 ? _handleNextOrSubmit : null,
              ),
            ),

            NumericKeypad(
              onDigitPressed: _onDigitPressed,
              onDeletePressed: _onDeletePressed,
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
