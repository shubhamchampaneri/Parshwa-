import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/utils/input_validators.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../data/repositories/auth_repository_impl.dart';
import '../controllers/auth_controller.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _inviteCodeController = TextEditingController();

  UserRole _selectedRole = UserRole.resident;
  String? _selectedFlatId;
  String _occupancyType = 'OWNER';
  List<Map<String, dynamic>> _flatsList = [];
  bool _loadingFlats = true;

  @override
  void initState() {
    super.initState();
    _fetchFlats();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _inviteCodeController.dispose();
    super.dispose();
  }

  Future<void> _fetchFlats() async {
    try {
      final authRepo = ref.read(authRepositoryProvider);
      final flats = await authRepo.getFlatsList();
      if (mounted) {
        setState(() {
          _flatsList = flats;
          if (_flatsList.isNotEmpty) {
            _selectedFlatId = _flatsList.first['id'] as String;
          }
          _loadingFlats = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingFlats = false);
    }
  }

  Future<void> _handleRegister() async {
    if (!_formKey.currentState!.validate()) return;

    bool success = false;
    final authNotifier = ref.read(authControllerProvider.notifier);

    if (_selectedRole == UserRole.resident) {
      if (_selectedFlatId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select your flat number')),
        );
        return;
      }
      success = await authNotifier.signUpResident(
        email: _emailController.text,
        password: _passwordController.text,
        fullName: _nameController.text,
        phoneNumber: _phoneController.text,
        flatId: _selectedFlatId!,
        occupancyType: _occupancyType,
      );
    } else {
      success = await authNotifier.signUpGuard(
        email: _emailController.text,
        password: _passwordController.text,
        fullName: _nameController.text,
        phoneNumber: _phoneController.text,
        inviteCode: _inviteCodeController.text,
      );
    }

    if (success && mounted) {
      final state = ref.read(authControllerProvider);
      if (!state.hasPinConfigured) {
        context.go('/setup-pin');
      } else {
        context.go('/pending-approval');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Account'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Join Parshwa Platinum',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Select your role to set up your community credentials.',
                  style: TextStyle(color: AppColors.textSecondaryLight),
                ),
                const SizedBox(height: 20),

                // Role Selector Segmented Control
                SegmentedButton<UserRole>(
                  segments: const [
                    ButtonSegment(
                      value: UserRole.resident,
                      label: Text('Resident'),
                      icon: Icon(Icons.apartment),
                    ),
                    ButtonSegment(
                      value: UserRole.guard,
                      label: Text('Security Guard'),
                      icon: Icon(Icons.shield),
                    ),
                  ],
                  selected: {_selectedRole},
                  onSelectionChanged: (newSelection) {
                    setState(() {
                      _selectedRole = newSelection.first;
                    });
                  },
                ),
                const SizedBox(height: 24),

                if (authState.errorMessage != null) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.errorContainer,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline, color: AppColors.error),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            authState.errorMessage!,
                            style: const TextStyle(color: AppColors.error),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                AppTextField(
                  label: 'Full Name',
                  hint: 'Anand Patel',
                  controller: _nameController,
                  prefixIcon: const Icon(Icons.person_outline),
                  validator: InputValidators.validateName,
                  textCapitalization: TextCapitalization.words,
                ),
                const SizedBox(height: 16),

                AppTextField(
                  label: 'Mobile Number',
                  hint: '9876543210',
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  prefixIcon: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                    child: Text(
                      '+91',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                  validator: InputValidators.validatePhone,
                ),
                const SizedBox(height: 16),

                AppTextField(
                  label: 'Email Address',
                  hint: 'anand@parshwaplatinum.com',
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  prefixIcon: const Icon(Icons.email_outlined),
                  validator: InputValidators.validateEmail,
                ),
                const SizedBox(height: 16),

                AppTextField(
                  label: 'Password',
                  hint: 'Min 8 chars, 1 number, 1 uppercase',
                  controller: _passwordController,
                  isPassword: true,
                  prefixIcon: const Icon(Icons.lock_outline),
                  validator: InputValidators.validatePassword,
                ),
                const SizedBox(height: 20),

                // Dynamic Role Sections
                if (_selectedRole == UserRole.resident) ...[
                  Text(
                    'Flat Number (101 - 704)',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 6),
                  _loadingFlats
                      ? const LinearProgressIndicator()
                      : DropdownButtonFormField<String>(
                          value: _selectedFlatId,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.home_work_outlined),
                          ),
                          items: _flatsList.map((f) {
                            final flatNum = f['flat_number']?.toString() ?? '';
                            final floor = f['floor_number']?.toString() ?? '';
                            return DropdownMenuItem<String>(
                              value: f['id'] as String,
                              child: Text('Flat $flatNum (Floor $floor)'),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setState(() => _selectedFlatId = val);
                          },
                        ),
                  const SizedBox(height: 16),

                  Text(
                    'Occupancy Type',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<String>(
                    value: _occupancyType,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.badge_outlined),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'OWNER', child: Text('Owner')),
                      DropdownMenuItem(value: 'TENANT', child: Text('Tenant')),
                      DropdownMenuItem(value: 'FAMILY', child: Text('Family Member')),
                    ],
                    onChanged: (val) {
                      if (val != null) setState(() => _occupancyType = val);
                    },
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Note: Max 4 residents per flat. Registration requires Society Committee approval.',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                  ),
                ] else ...[
                  AppTextField(
                    label: 'Secret Guard Invite Code',
                    hint: 'e.g. PPGUARD2026',
                    controller: _inviteCodeController,
                    prefixIcon: const Icon(Icons.key_outlined),
                    validator: InputValidators.validateInviteCode,
                    textCapitalization: TextCapitalization.characters,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Secret code provided by Parshwa Platinum Management Committee.',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                  ),
                ],

                const SizedBox(height: 28),
                AppButton(
                  label: 'Submit Registration',
                  isLoading: authState.isLoading,
                  onPressed: _handleRegister,
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
