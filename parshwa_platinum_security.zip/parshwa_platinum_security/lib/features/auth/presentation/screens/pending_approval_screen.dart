import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/status_badge.dart';
import '../controllers/auth_controller.dart';

class PendingApprovalScreen extends ConsumerWidget {
  const PendingApprovalScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authControllerProvider);
    final user = authState.userProfile;

    // React automatically if user is approved in real-time by admin
    if (user != null && user.isApproved) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (user.isAdmin) {
          context.go('/admin/approvals');
        } else if (user.isGuard) {
          context.go('/guard/dashboard');
        } else {
          context.go('/resident/home');
        }
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Account Status'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sign Out',
            onPressed: () async {
              await ref.read(authControllerProvider.notifier).signOut();
              if (context.mounted) context.go('/login');
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  color: AppColors.warningContainer,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.hourglass_empty_rounded,
                  size: 48,
                  color: AppColors.warning,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Approval Pending',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 12),
              Text(
                'Your registration as a ${user?.role.name.toUpperCase()} has been submitted to the Parshwa Platinum Management Committee for verification.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.textSecondaryLight,
                  fontSize: 15,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 28),

              // Summary Info Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Applicant Name', style: TextStyle(color: Colors.grey)),
                          Text(user?.fullName ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Role Requested', style: TextStyle(color: Colors.grey)),
                          Text(user?.role.name.toUpperCase() ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      if (user?.flatNumber != null) ...[
                        const Divider(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Flat Number', style: TextStyle(color: Colors.grey)),
                            Text('Flat ${user!.flatNumber}', style: const TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ],
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Current Status', style: TextStyle(color: Colors.grey)),
                          StatusBadge(status: user?.status.name ?? 'PENDING'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const Spacer(),

              AppButton(
                label: 'Check Status Now',
                isLoading: authState.isLoading,
                icon: Icons.refresh,
                onPressed: () {
                  ref.read(authControllerProvider.notifier).checkInitialAuth();
                },
              ),
              const SizedBox(height: 12),
              AppButton(
                label: 'Sign Out',
                isOutlined: true,
                onPressed: () async {
                  await ref.read(authControllerProvider.notifier).signOut();
                  if (context.mounted) context.go('/login');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
