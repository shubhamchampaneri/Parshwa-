import '../../../../core/constants/app_constants.dart';
import '../../domain/entities/user_profile.dart';

class UserProfileModel extends UserProfile {
  const UserProfileModel({
    required super.id,
    required super.email,
    required super.fullName,
    required super.phoneNumber,
    required super.role,
    required super.status,
    super.flatId,
    super.flatNumber,
    super.occupancyType,
    super.avatarUrl,
    super.rejectionReason,
    required super.createdAt,
  });

  factory UserProfileModel.fromJson(Map<String, dynamic> json) {
    String? flatNum;
    if (json['flats'] != null && json['flats'] is Map) {
      flatNum = json['flats']['flat_number'] as String?;
    } else if (json['flat_number'] != null) {
      flatNum = json['flat_number'] as String?;
    }

    return UserProfileModel(
      id: json['id'] as String,
      email: json['email'] as String? ?? '',
      fullName: json['full_name'] as String? ?? '',
      phoneNumber: json['phone_number'] as String? ?? '',
      role: UserRole.fromString(json['role'] as String?),
      status: UserStatus.fromString(json['status'] as String?),
      flatId: json['flat_id'] as String?,
      flatNumber: flatNum,
      occupancyType: json['occupancy_type'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      rejectionReason: json['rejection_reason'] as String?,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'full_name': fullName,
      'phone_number': phoneNumber,
      'role': role.dbValue,
      'status': status.dbValue,
      'flat_id': flatId,
      'occupancy_type': occupancyType,
      'avatar_url': avatarUrl,
      'rejection_reason': rejectionReason,
    };
  }

  UserProfileModel copyWith({
    String? id,
    String? email,
    String? fullName,
    String? phoneNumber,
    UserRole? role,
    UserStatus? status,
    String? flatId,
    String? flatNumber,
    String? occupancyType,
    String? avatarUrl,
    String? rejectionReason,
    DateTime? createdAt,
  }) {
    return UserProfileModel(
      id: id ?? this.id,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      role: role ?? this.role,
      status: status ?? this.status,
      flatId: flatId ?? this.flatId,
      flatNumber: flatNumber ?? this.flatNumber,
      occupancyType: occupancyType ?? this.occupancyType,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      rejectionReason: rejectionReason ?? this.rejectionReason,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
