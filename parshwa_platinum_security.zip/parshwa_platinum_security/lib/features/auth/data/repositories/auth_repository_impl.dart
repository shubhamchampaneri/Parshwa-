import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;
import '../../../../core/constants/supabase_tables.dart';
import '../../../../core/errors/exceptions.dart';
import '../../../../core/network/supabase_client.dart';
import '../../domain/entities/user_profile.dart';
import '../../domain/repositories/auth_repository.dart';
import '../models/user_profile_model.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  final client = ref.watch(supabaseClientProvider);
  return AuthRepositoryImpl(client);
});

class AuthRepositoryImpl implements AuthRepository {
  final sb.SupabaseClient _client;

  AuthRepositoryImpl(this._client);

  @override
  Future<UserProfile?> getCurrentProfile() async {
    final user = _client.auth.currentUser;
    if (user == null) return null;

    try {
      final res = await _client
          .from(SupabaseTables.profiles)
          .select('*, flats(flat_number)')
          .eq('id', user.id)
          .maybeSingle();

      if (res == null) return null;
      return UserProfileModel.fromJson(res);
    } catch (e) {
      throw ServerException('Failed to load profile: $e');
    }
  }

  @override
  Stream<UserProfile?> watchCurrentProfile() {
    final user = _client.auth.currentUser;
    if (user == null) return Stream.value(null);

    return _client
        .from(SupabaseTables.profiles)
        .stream(primaryKey: ['id'])
        .eq('id', user.id)
        .asyncMap((list) async {
          if (list.isEmpty) return null;
          // Fetch joined flat info
          return await getCurrentProfile();
        });
  }

  @override
  Future<UserProfile> signInWithEmailPassword({
    required String email,
    required String password,
  }) async {
    try {
      final response = await _client.auth.signInWithPassword(
        email: email.trim(),
        password: password,
      );

      final user = response.user;
      if (user == null) {
        throw const AuthException('Authentication failed. No user returned.');
      }

      final profile = await getCurrentProfile();
      if (profile == null) {
        throw const AuthException('User profile could not be found.');
      }

      return profile;
    } on sb.AuthException catch (e) {
      throw AuthException(e.message, code: e.statusCode);
    } catch (e) {
      throw AuthException('Sign in failed: ${e.toString()}');
    }
  }

  @override
  Future<UserProfile> signInWithGoogle() async {
    try {
      // Initiates Google OAuth via Supabase
      await _client.auth.signInWithOAuth(
        sb.OAuthProvider.google,
        redirectTo: 'parshwaplatinum://login-callback',
      );

      final user = _client.auth.currentUser;
      if (user == null) {
        throw const AuthException('Google sign-in was cancelled or failed.');
      }

      final profile = await getCurrentProfile();
      if (profile == null) {
        throw const AuthException('Profile not initialized.');
      }

      return profile;
    } on sb.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw AuthException('Google sign in error: $e');
    }
  }

  @override
  Future<UserProfile> signUpResident({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String flatId,
    required String occupancyType,
  }) async {
    try {
      final response = await _client.auth.signUp(
        email: email.trim(),
        password: password,
        data: {
          'full_name': fullName.trim(),
          'phone_number': phoneNumber.trim(),
          'role': 'RESIDENT',
          'flat_id': flatId,
          'occupancy_type': occupancyType,
        },
      );

      final user = response.user;
      if (user == null) {
        throw const AuthException('Sign up failed: User was not created.');
      }

      // Small delay for DB trigger completion if needed
      await Future.delayed(const Duration(milliseconds: 500));

      final profile = await getCurrentProfile();
      if (profile == null) {
        // Fallback profile representation
        return UserProfileModel(
          id: user.id,
          email: email,
          fullName: fullName,
          phoneNumber: phoneNumber,
          role: UserRole.resident,
          status: UserStatus.pending,
          flatId: flatId,
          occupancyType: occupancyType,
          createdAt: DateTime.now(),
        );
      }
      return profile;
    } on sb.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw AuthException(e.toString());
    }
  }

  @override
  Future<UserProfile> signUpGuard({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String inviteCode,
  }) async {
    try {
      final response = await _client.auth.signUp(
        email: email.trim(),
        password: password,
        data: {
          'full_name': fullName.trim(),
          'phone_number': phoneNumber.trim(),
          'role': 'GUARD',
          'invite_code': inviteCode.trim().toUpperCase(),
        },
      );

      final user = response.user;
      if (user == null) {
        throw const AuthException('Guard registration failed.');
      }

      await Future.delayed(const Duration(milliseconds: 500));

      final profile = await getCurrentProfile();
      if (profile == null) {
        return UserProfileModel(
          id: user.id,
          email: email,
          fullName: fullName,
          phoneNumber: phoneNumber,
          role: UserRole.guard,
          status: UserStatus.pending,
          createdAt: DateTime.now(),
        );
      }
      return profile;
    } on sb.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw AuthException(e.toString());
    }
  }

  @override
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _client.auth.resetPasswordForEmail(email.trim());
    } on sb.AuthException catch (e) {
      throw AuthException(e.message);
    }
  }

  @override
  Future<void> signOut() async {
    try {
      await _client.auth.signOut();
    } catch (_) {}
  }

  @override
  Future<UserProfile> updateProfile({
    String? fullName,
    String? phoneNumber,
    String? avatarUrl,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) throw const AuthException('Not authenticated');

    final updates = <String, dynamic>{
      'updated_at': DateTime.now().toIso8601String(),
    };
    if (fullName != null) updates['full_name'] = fullName;
    if (phoneNumber != null) updates['phone_number'] = phoneNumber;
    if (avatarUrl != null) updates['avatar_url'] = avatarUrl;

    try {
      final res = await _client
          .from(SupabaseTables.profiles)
          .update(updates)
          .eq('id', user.id)
          .select('*, flats(flat_number)')
          .single();

      return UserProfileModel.fromJson(res);
    } catch (e) {
      throw ServerException('Failed to update profile: $e');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> getFlatsList() async {
    try {
      final List<dynamic> res = await _client
          .from(SupabaseTables.flats)
          .select('id, flat_number, floor_number, unit_number')
          .order('flat_number', ascending: true);

      return res.map((item) => Map<String, dynamic>.from(item as Map)).toList();
    } catch (e) {
      // Fallback local list of 28 flats if network offline
      final List<Map<String, dynamic>> fallback = [];
      for (int floor = 1; floor <= 7; floor++) {
        for (int unit = 1; unit <= 4; unit++) {
          final flatNum = '${floor}0$unit';
          fallback.add({
            'id': 'flat-$flatNum',
            'flat_number': flatNum,
            'floor_number': floor,
            'unit_number': unit,
          });
        }
      }
      return fallback;
    }
  }
}
