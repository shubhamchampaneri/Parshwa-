class Notice {
  final String id;
  final String title;
  final String content;
  final String priority; // NORMAL, IMPORTANT, URGENT
  final String targetAudience; // ALL, RESIDENTS, GUARDS
  final String createdBy;
  final String? attachmentUrl;
  final bool isActive;
  final DateTime createdAt;

  const Notice({
    required this.id,
    required this.title,
    required this.content,
    required this.priority,
    required this.targetAudience,
    required this.createdBy,
    this.attachmentUrl,
    required this.isActive,
    required this.createdAt,
  });

  bool get isUrgent => priority == 'URGENT';
}
