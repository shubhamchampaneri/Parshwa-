import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/constants/supabase_tables.dart';
import '../../../../core/network/supabase_client.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/empty_state_view.dart';
import '../../../../core/widgets/loading_shimmer.dart';
import '../../domain/entities/notice.dart';
import '../../data/models/notice_model.dart';

final noticesStreamProvider = StreamProvider<List<Notice>>((ref) {
  final client = ref.watch(supabaseClientProvider);
  return client
      .from(SupabaseTables.notices)
      .stream(primaryKey: ['id'])
      .eq('is_active', true)
      .order('created_at', ascending: false)
      .map((list) => list.map((e) => NoticeModel.fromJson(e)).toList());
});

class NoticesScreen extends ConsumerWidget {
  const NoticesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final noticesAsync = ref.watch(noticesStreamProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Society Notice Board'),
      ),
      body: noticesAsync.when(
        loading: () => ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: 4,
          itemBuilder: (_, __) => const Padding(
            padding: EdgeInsets.only(bottom: 12.0),
            child: LoadingShimmer(width: double.infinity, height: 110),
          ),
        ),
        error: (err, _) => Center(child: Text('Error loading notices: $err')),
        data: (notices) {
          if (notices.isEmpty) {
            return const EmptyStateView(
              icon: Icons.campaign_outlined,
              title: 'No Active Notices',
              message: 'There are no active announcements posted by the management committee.',
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: notices.length,
            itemBuilder: (context, index) {
              final n = notices[index];
              final isUrgent = n.isUrgent;
              final isImportant = n.priority == 'IMPORTANT';

              Color badgeColor = AppColors.primary;
              if (isUrgent) badgeColor = AppColors.error;
              if (isImportant) badgeColor = AppColors.warning;

              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: badgeColor.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              n.priority,
                              style: TextStyle(
                                color: badgeColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                              ),
                            ),
                          ),
                          Text(
                            DateFormatter.formatDate(n.createdAt),
                            style: const TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        n.title,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        n.content,
                        style: const TextStyle(
                          color: AppColors.textSecondaryLight,
                          fontSize: 14,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
