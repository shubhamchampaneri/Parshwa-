import '../../domain/entities/notice.dart';

class NoticeModel extends Notice {
  const NoticeModel({
    required super.id,
    required super.title,
    required super.content,
    required super.priority,
    required super.targetAudience,
    required super.createdBy,
    super.attachmentUrl,
    required super.isActive,
    required super.createdAt,
  });

  factory NoticeModel.fromJson(Map<String, dynamic> json) {
    return NoticeModel(
      id: json['id'] as String,
      title: json['title'] as String,
      content: json['content'] as String,
      priority: json['priority'] as String? ?? 'NORMAL',
      targetAudience: json['target_audience'] as String? ?? 'ALL',
      createdBy: json['created_by'] as String? ?? '',
      attachmentUrl: json['attachment_url'] as String?,
      isActive: json['is_active'] as bool? ?? true,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }
}
