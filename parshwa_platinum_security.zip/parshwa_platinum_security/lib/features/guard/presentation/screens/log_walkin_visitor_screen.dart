import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/input_validators.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../data/repositories/guard_repository_impl.dart';

class LogWalkInVisitorScreen extends ConsumerStatefulWidget {
  const LogWalkInVisitorScreen({super.key});

  @override
  ConsumerState<LogWalkInVisitorScreen> createState() => _LogWalkInVisitorScreenState();
}

class _LogWalkInVisitorScreenState extends ConsumerState<LogWalkInVisitorScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _nameController = TextEditingController();
  final _vehicleController = TextEditingController();

  File? _visitorPhoto;
  String _purpose = 'GUEST';
  int _selectedFloor = 1;
  String? _selectedFlatId;
  String _selectedFlatNumber = '101';
  bool _isSubmitting = false;

  List<Map<String, dynamic>> _allFlats = [];
  bool _loadingFlats = true;

  final List<String> _purposes = ['GUEST', 'DELIVERY', 'CAB', 'TECHNICIAN', 'OTHER'];

  @override
  void initState() {
    super.initState();
    _fetchFlats();
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _nameController.dispose();
    _vehicleController.dispose();
    super.dispose();
  }

  Future<void> _fetchFlats() async {
    final repo = ref.read(guardRepositoryProvider);
    final flats = await repo.getFlatsDirectory();
    if (mounted) {
      setState(() {
        _allFlats = flats;
        if (_allFlats.isNotEmpty) {
          _selectedFlatId = _allFlats.first['id'] as String;
          _selectedFlatNumber = _allFlats.first['flat_number']?.toString() ?? '101';
        }
        _loadingFlats = false;
      });
    }
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(
      source: ImageSource.camera,
      preferredCameraDevice: CameraDevice.rear,
    );
    if (file != null) {
      setState(() => _visitorPhoto = File(file.path));
    }
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedFlatId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select destination flat number')),
      );
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      final repo = ref.read(guardRepositoryProvider);
      await repo.logWalkInVisitor(
        visitorName: _nameController.text.trim(),
        visitorPhone: _phoneController.text.trim(),
        flatId: _selectedFlatId!,
        purpose: _purpose,
        vehicleNumber: _vehicleController.text.trim().isNotEmpty ? _vehicleController.text.trim() : null,
        photoFile: _visitorPhoto,
      );

      if (mounted) {
        setState(() => _isSubmitting = false);
        _showSuccessDialog();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSubmitting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to log visitor: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: AppColors.success, size: 28),
            SizedBox(width: 10),
            Text('Approval Request Sent'),
          ],
        ),
        content: Text(
          'An entry notification was broadcast to residents of Flat $_selectedFlatNumber.\n'
          'The visitor can enter once approved on their phone.',
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context); // Back to gate dashboard
            },
            child: const Text('Back to Dashboard'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Filter flats for selected floor
    final floorFlats = _allFlats
        .where((f) => (f['floor_number'] as int? ?? 1) == _selectedFloor)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Log Walk-in Visitor'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Photo Capture Box (Rapid Tap)
              Center(
                child: GestureDetector(
                  onTap: _takePhoto,
                  child: Container(
                    width: 130,
                    height: 130,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.primary, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.06),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: _visitorPhoto != null
                        ? ClipOval(
                            child: Image.file(
                              _visitorPhoto!,
                              width: 130,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          )
                        : const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.camera_alt_rounded, size: 40, color: AppColors.primary),
                              SizedBox(height: 4),
                              Text(
                                'Snap Photo',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.primary,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              AppTextField(
                label: 'Visitor Mobile Number',
                hint: '10-digit phone number',
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                prefixIcon: const Icon(Icons.phone),
                validator: InputValidators.validatePhone,
              ),
              const SizedBox(height: 16),

              AppTextField(
                label: 'Visitor Full Name',
                hint: 'Full name',
                controller: _nameController,
                prefixIcon: const Icon(Icons.person),
                validator: InputValidators.validateName,
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 20),

              // Visual 7-Floor Destination Grid (Fast 1-tap flat selection)
              Text(
                'Destination Flat (Selected: Flat $_selectedFlatNumber)',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              const SizedBox(height: 8),

              // Floor Selector Tabs
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(7, (i) {
                    final floor = i + 1;
                    final isSel = _selectedFloor == floor;
                    return Padding(
                      padding: const EdgeInsets.only(right: 6.0),
                      child: ChoiceChip(
                        label: Text('Floor $floor'),
                        selected: isSel,
                        onSelected: (_) => setState(() => _selectedFloor = floor),
                      ),
                    );
                  }),
                ),
              ),
              const SizedBox(height: 10),

              // 4 Flat Chips for Current Floor
              _loadingFlats
                  ? const LinearProgressIndicator()
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: floorFlats.map((flat) {
                        final flatNum = flat['flat_number']?.toString() ?? '';
                        final flatId = flat['id'] as String;
                        final isChosen = _selectedFlatId == flatId;

                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4.0),
                            child: InkWell(
                              onTap: () {
                                setState(() {
                                  _selectedFlatId = flatId;
                                  _selectedFlatNumber = flatNum;
                                });
                              },
                              borderRadius: BorderRadius.circular(12),
                              child: Container(
                                height: 50,
                                decoration: BoxDecoration(
                                  color: isChosen ? AppColors.primary : Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isChosen ? AppColors.primary : AppColors.borderLight,
                                    width: isChosen ? 2 : 1,
                                  ),
                                ),
                                child: Center(
                                  child: Text(
                                    flatNum,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: isChosen ? Colors.white : AppColors.textPrimaryLight,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
              const SizedBox(height: 20),

              Text(
                'Purpose of Visit',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: _purposes.map((p) {
                  final isSel = _purpose == p;
                  return ChoiceChip(
                    label: Text(p),
                    selected: isSel,
                    onSelected: (sel) {
                      if (sel) setState(() => _purpose = p);
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              AppTextField(
                label: 'Vehicle Plate (Optional)',
                hint: 'e.g. GJ-01-XX-1234',
                controller: _vehicleController,
                prefixIcon: const Icon(Icons.directions_car_outlined),
                textCapitalization: TextCapitalization.characters,
              ),
              const SizedBox(height: 32),

              AppButton(
                label: 'Request Approval for Flat $_selectedFlatNumber',
                isLoading: _isSubmitting,
                icon: Icons.send_rounded,
                onPressed: _handleSubmit,
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
