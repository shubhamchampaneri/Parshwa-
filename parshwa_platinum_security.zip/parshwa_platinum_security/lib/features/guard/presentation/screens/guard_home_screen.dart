import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../../data/repositories/guard_repository_impl.dart';
import '../controllers/guard_dashboard_controller.dart';
import '../controllers/offline_sync_controller.dart';

final activeSosStreamProvider = StreamProvider<List<Map<String, dynamic>>>((ref) {
  final repo = ref.watch(guardRepositoryProvider);
  return repo.watchActiveSosAlerts();
});

class GuardHomeScreen extends ConsumerStatefulWidget {
  const GuardHomeScreen({super.key});

  @override
  ConsumerState<GuardHomeScreen> createState() => _GuardHomeScreenState();
}

class _GuardHomeScreenState extends ConsumerState<GuardHomeScreen> {
  String? _handledSosId;

  void _listenForSosAlerts() {
    ref.listen<AsyncValue<List<Map<String, dynamic>>>>(activeSosStreamProvider, (prev, next) {
      next.whenData((alerts) {
        if (alerts.isNotEmpty) {
          final activeAlert = alerts.first;
          final alertId = activeAlert['id'] as String;
          if (_handledSosId != alertId) {
            _handledSosId = alertId;
            context.push('/guard/sos-alert', extra: activeAlert);
          }
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    _listenForSosAlerts();

    final dashboard = ref.watch(guardDashboardControllerProvider);
    final syncState = ref.watch(offlineSyncControllerProvider);
    final user = ref.watch(authControllerProvider).userProfile;

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.shield_rounded, color: AppColors.primary, size: 28),
            SizedBox(width: 8),
            Text(
              'Parshwa Platinum Gate',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.receipt_long_outlined),
            tooltip: 'Shift Report',
            onPressed: () => context.push('/guard/shift-log'),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sign Out',
            onPressed: () async {
              await ref.read(authControllerProvider.notifier).signOut();
              if (context.mounted) context.go('/login');
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await ref.read(guardDashboardControllerProvider.notifier).loadDashboard();
          await ref.read(offlineSyncControllerProvider.notifier).refreshPendingCount();
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Connectivity Status Bar
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: !syncState.isOnline
                      ? AppColors.warningContainer
                      : syncState.isSyncing
                          ? Colors.blue.shade100
                          : AppColors.successContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(
                      !syncState.isOnline
                          ? Icons.wifi_off_rounded
                          : syncState.isSyncing
                              ? Icons.sync_rounded
                              : Icons.wifi_rounded,
                      size: 20,
                      color: !syncState.isOnline
                          ? AppColors.warning
                          : syncState.isSyncing
                              ? Colors.blue.shade800
                              : AppColors.success,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        !syncState.isOnline
                            ? 'Offline Gate Mode (${syncState.pendingCount} entries queued)'
                            : syncState.isSyncing
                                ? 'Syncing queued entries to database...'
                                : 'Gate Terminal Connected (Online)',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: !syncState.isOnline
                              ? AppColors.warning
                              : syncState.isSyncing
                                  ? Colors.blue.shade900
                                  : AppColors.success,
                        ),
                      ),
                    ),
                    if (syncState.pendingCount > 0 && syncState.isOnline && !syncState.isSyncing)
                      TextButton(
                        onPressed: () {
                          ref.read(offlineSyncControllerProvider.notifier).syncPendingQueue();
                        },
                        child: const Text('Sync Now'),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Guard on Duty Info
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Guard on Duty: ${user?.fullName ?? "Security"}',
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                  const Text(
                    'Main Gate',
                    style: TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Gate Operations Metrics (2x2 Grid)
              Row(
                children: [
                  Expanded(
                    child: _buildMetricCard(
                      context,
                      title: 'Inside Campus',
                      value: dashboard.insideCount.toString(),
                      icon: Icons.meeting_room_rounded,
                      color: AppColors.success,
                      onTap: () => context.push('/guard/inside-visitors'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildMetricCard(
                      context,
                      title: 'Pending Approval',
                      value: dashboard.pendingCount.toString(),
                      icon: Icons.hourglass_top_rounded,
                      color: AppColors.warning,
                      onTap: () => context.push('/guard/inside-visitors'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildMetricCard(
                      context,
                      title: "Today's Entries",
                      value: dashboard.todayEntriesCount.toString(),
                      icon: Icons.login_rounded,
                      color: AppColors.primary,
                      onTap: () {},
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildMetricCard(
                      context,
                      title: "Today's Exits",
                      value: dashboard.todayExitsCount.toString(),
                      icon: Icons.logout_rounded,
                      color: Colors.blueGrey,
                      onTap: () {},
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Oversized Action Buttons (Guards use in a hurry)
              Text(
                'Gate Operations',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 12),

              _buildLargeActionButton(
                context,
                title: 'Log Walk-in Visitor',
                subtitle: 'Photo + Mobile + Select Flat (101-704)',
                icon: Icons.camera_alt_rounded,
                color: AppColors.primary,
                onTap: () => context.push('/guard/log-visitor'),
              ),
              const SizedBox(height: 12),

              _buildLargeActionButton(
                context,
                title: 'Verify Pre-Approved Pass',
                subtitle: '6-digit OTP Keypad or Scan QR Code',
                icon: Icons.qr_code_scanner_rounded,
                color: Colors.indigo,
                onTap: () => context.push('/guard/verify-pass'),
              ),
              const SizedBox(height: 12),

              _buildLargeActionButton(
                context,
                title: 'Record Visitor Check-Out',
                subtitle: '${dashboard.insideCount} visitors currently inside campus',
                icon: Icons.exit_to_app_rounded,
                color: Colors.teal,
                onTap: () => context.push('/guard/inside-visitors'),
              ),
              const SizedBox(height: 12),

              _buildLargeActionButton(
                context,
                title: 'Deliveries & Staff Entries',
                subtitle: 'Amazon, Swiggy, Maids, Drivers',
                icon: Icons.local_shipping_outlined,
                color: Colors.deepOrange,
                onTap: () => context.push('/guard/delivery-staff'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMetricCard(
    BuildContext context, {
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.borderLight),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
                Icon(icon, color: color, size: 26),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.textSecondaryLight,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLargeActionButton(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      height: 76, // Generous height for quick gate operation
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: AppColors.textPrimaryLight,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: AppColors.borderLight, width: 1.5),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 18),
        ),
        onPressed: onTap,
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 12),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
