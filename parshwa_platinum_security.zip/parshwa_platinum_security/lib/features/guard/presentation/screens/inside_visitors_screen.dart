import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/empty_state_view.dart';
import '../../../../core/widgets/loading_shimmer.dart';
import '../controllers/guard_dashboard_controller.dart';

class InsideVisitorsScreen extends ConsumerStatefulWidget {
  const InsideVisitorsScreen({super.key});

  @override
  ConsumerState<InsideVisitorsScreen> createState() => _InsideVisitorsScreenState();
}

class _InsideVisitorsScreenState extends ConsumerState<InsideVisitorsScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(guardDashboardControllerProvider);
    final controller = ref.read(guardDashboardControllerProvider.notifier);

    final searchQuery = _searchController.text.trim().toLowerCase();
    final filteredVisitors = state.insideVisitors.where((v) {
      if (searchQuery.isEmpty) return true;
      return v.visitorName.toLowerCase().contains(searchQuery) ||
          (v.flatNumber?.toLowerCase().contains(searchQuery) ?? false) ||
          (v.vehicleNumber?.toLowerCase().contains(searchQuery) ?? false) ||
          v.visitorPhone.contains(searchQuery);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Visitors Inside (${state.insideVisitors.length})'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: TextField(
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search by flat, visitor name, or vehicle...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                      )
                    : null,
              ),
            ),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: controller.loadDashboard,
              child: state.isLoading
                  ? ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: 4,
                      itemBuilder: (_, __) => const Padding(
                        padding: EdgeInsets.only(bottom: 12.0),
                        child: LoadingShimmer(width: double.infinity, height: 90),
                      ),
                    )
                  : filteredVisitors.isEmpty
                      ? const EmptyStateView(
                          icon: Icons.check_circle_outline,
                          title: 'No Visitors Currently Inside',
                          message: 'All visitors have exited the apartment premises.',
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: filteredVisitors.length,
                          itemBuilder: (context, index) {
                            final v = filteredVisitors[index];
                            return Card(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 26,
                                      backgroundColor: AppColors.primaryLight.withOpacity(0.12),
                                      backgroundImage: v.visitorPhotoUrl != null
                                          ? NetworkImage(v.visitorPhotoUrl!)
                                          : null,
                                      child: v.visitorPhotoUrl == null
                                          ? const Icon(Icons.person, color: AppColors.primary)
                                          : null,
                                    ),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            v.visitorName,
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            'Visiting Flat ${v.flatNumber ?? "---"} • ${v.purpose}',
                                            style: const TextStyle(
                                              fontSize: 13,
                                              color: AppColors.textSecondaryLight,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            'Entry: ${DateFormatter.formatTime(v.entryTime ?? v.createdAt)}',
                                            style: const TextStyle(fontSize: 12, color: Colors.grey),
                                          ),
                                          if (v.vehicleNumber != null && v.vehicleNumber!.isNotEmpty)
                                            Text(
                                              'Vehicle: ${v.vehicleNumber}',
                                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                                            ),
                                        ],
                                      ),
                                    ),
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: AppColors.primary,
                                        minimumSize: const Size(96, 44),
                                      ),
                                      onPressed: () async {
                                        await controller.checkOutVisitor(v.id);
                                      },
                                      child: const Text('Check Out'),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
            ),
          ),
        ],
      ),
    );
  }
}
