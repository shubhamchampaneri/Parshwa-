import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../data/repositories/guard_repository_impl.dart';

class GuardSosAlertScreen extends ConsumerStatefulWidget {
  final Map<String, dynamic> alert;

  const GuardSosAlertScreen({super.key, required this.alert});

  @override
  ConsumerState<GuardSosAlertScreen> createState() => _GuardSosAlertScreenState();
}

class _GuardSosAlertScreenState extends ConsumerState<GuardSosAlertScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  bool _isAcknowledging = false;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..repeat(reverse: true);
    HapticFeedback.vibrate();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Future<void> _handleAcknowledge() async {
    setState(() => _isAcknowledging = true);
    try {
      final repo = ref.read(guardRepositoryProvider);
      final id = widget.alert['id'] as String;
      await repo.acknowledgeSosAlert(id);
      if (mounted) {
        Navigator.pop(context);
      }
    } catch (_) {
      if (mounted) setState(() => _isAcknowledging = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    String flatNumber = '---';
    if (widget.alert['flats'] != null && widget.alert['flats'] is Map) {
      flatNumber = widget.alert['flats']['flat_number']?.toString() ?? '---';
    }

    String residentName = 'Resident';
    String residentPhone = '';
    if (widget.alert['profiles'] != null && widget.alert['profiles'] is Map) {
      residentName = widget.alert['profiles']['full_name'] as String? ?? 'Resident';
      residentPhone = widget.alert['profiles']['phone_number'] as String? ?? '';
    }

    final emergencyType = widget.alert['emergency_type'] as String? ?? 'GENERAL';

    return AnimatedBuilder(
      animation: _animController,
      builder: (context, child) {
        final bgColor = Color.lerp(
          AppColors.sosRedDark,
          const Color(0xFF7F1D1D),
          _animController.value,
        )!;

        return Scaffold(
          backgroundColor: bgColor,
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.warning_amber_rounded,
                      size: 68,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'EMERGENCY SOS ALERT',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Flat Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          'EMERGENCY FROM',
                          style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.grey),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'FLAT $flatNumber',
                          style: const TextStyle(
                            fontSize: 48,
                            fontWeight: FontWeight.w900,
                            color: AppColors.sosRed,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.errorContainer,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            emergencyType,
                            style: const TextStyle(
                              color: AppColors.error,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Divider(),
                        const SizedBox(height: 8),
                        Text(
                          residentName,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          residentPhone,
                          style: const TextStyle(fontSize: 14, color: AppColors.textSecondaryLight),
                        ),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // Acknowledge Action Button
                  SizedBox(
                    height: 64,
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      icon: _isAcknowledging
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Icon(Icons.check_circle_outline, size: 28),
                      label: Text(
                        _isAcknowledging ? 'Acknowledging...' : 'Acknowledge & Respond',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      onPressed: _isAcknowledging ? null : _handleAcknowledge,
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
