import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../domain/entities/delivery_log.dart';
import '../../data/repositories/guard_repository_impl.dart';

class DeliveryStaffScreen extends ConsumerStatefulWidget {
  const DeliveryStaffScreen({super.key});

  @override
  ConsumerState<DeliveryStaffScreen> createState() => _DeliveryStaffScreenState();
}

class _DeliveryStaffScreenState extends ConsumerState<DeliveryStaffScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Delivery state
  String _selectedCompany = 'AMAZON';
  String? _selectedFlatId;
  String _selectedFlatNum = '101';
  Map<String, dynamic>? _flatPref;
  int _packageCount = 1;
  final _deliveryNotesController = TextEditingController();
  bool _isSubmittingDelivery = false;

  // Staff state
  final _staffNameController = TextEditingController();
  final _staffPhoneController = TextEditingController();
  String _staffRole = 'MAID';
  List<StaffEntry> _insideStaff = [];
  bool _isLoadingStaff = true;
  bool _isSubmittingStaff = false;

  List<Map<String, dynamic>> _flats = [];

  final List<String> _companies = [
    'AMAZON',
    'FLIPKART',
    'ZOMATO',
    'SWIGGY',
    'BLINKIT',
    'ZEPTO',
    'COURIER',
    'OTHER'
  ];

  final List<String> _staffRoles = ['MAID', 'DRIVER', 'COOK', 'CLEANER', 'TECHNICIAN', 'OTHER'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadInitialData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _deliveryNotesController.dispose();
    _staffNameController.dispose();
    _staffPhoneController.dispose();
    super.dispose();
  }

  Future<void> _loadInitialData() async {
    final repo = ref.read(guardRepositoryProvider);
    final flatsList = await repo.getFlatsDirectory();
    final staffList = await repo.getInsideStaff();

    if (mounted) {
      setState(() {
        _flats = flatsList;
        if (_flats.isNotEmpty) {
          _selectedFlatId = _flats.first['id'] as String;
          _selectedFlatNum = _flats.first['flat_number']?.toString() ?? '101';
        }
        _insideStaff = staffList;
        _isLoadingStaff = false;
      });
      if (_selectedFlatId != null) {
        _checkFlatPreference(_selectedFlatId!);
      }
    }
  }

  Future<void> _checkFlatPreference(String flatId) async {
    final repo = ref.read(guardRepositoryProvider);
    final pref = await repo.getDeliveryPreferenceForFlat(flatId);
    if (mounted) {
      setState(() => _flatPref = pref);
    }
  }

  Future<void> _handleLogDelivery() async {
    if (_selectedFlatId == null) return;

    setState(() => _isSubmittingDelivery = true);
    try {
      final repo = ref.read(guardRepositoryProvider);
      await repo.logDeliveryEntry(
        flatId: _selectedFlatId!,
        companyName: _selectedCompany,
        packageCount: _packageCount,
        notes: _deliveryNotesController.text.trim().isNotEmpty
            ? _deliveryNotesController.text.trim()
            : null,
      );

      if (mounted) {
        setState(() {
          _isSubmittingDelivery = false;
          _deliveryNotesController.clear();
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Delivery logged for Flat $_selectedFlatNum'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSubmittingDelivery = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  Future<void> _handleLogStaff() async {
    if (_staffNameController.text.trim().isEmpty) return;

    setState(() => _isSubmittingStaff = true);
    try {
      final repo = ref.read(guardRepositoryProvider);
      await repo.logStaffEntry(
        name: _staffNameController.text.trim(),
        phoneNumber: _staffPhoneController.text.trim(),
        roleType: _staffRole,
        flatId: _selectedFlatId,
      );

      final updated = await repo.getInsideStaff();
      if (mounted) {
        setState(() {
          _insideStaff = updated;
          _isSubmittingStaff = false;
          _staffNameController.clear();
          _staffPhoneController.clear();
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Staff check-in logged'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSubmittingStaff = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  Future<void> _handleStaffExit(String staffId) async {
    try {
      final repo = ref.read(guardRepositoryProvider);
      await repo.markStaffExit(staffId);
      final updated = await repo.getInsideStaff();
      if (mounted) {
        setState(() => _insideStaff = updated);
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final allowsLeaveAtGate = _flatPref?['delivery_preference'] == 'LEAVE_AT_GATE';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Deliveries & Society Staff'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Log Delivery', icon: Icon(Icons.inventory_2_outlined)),
            Tab(text: 'Staff (Maids/Drivers)', icon: Icon(Icons.badge_outlined)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab 1: Delivery Logger
          SingleChildScrollView(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('Delivery Company', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: _companies.map((c) {
                    final isSel = _selectedCompany == c;
                    return ChoiceChip(
                      label: Text(c),
                      selected: isSel,
                      onSelected: (sel) {
                        if (sel) setState(() => _selectedCompany = c);
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),

                const Text('Destination Flat', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _selectedFlatId,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.home_work_outlined),
                  ),
                  items: _flats.map((f) {
                    final num = f['flat_number']?.toString() ?? '';
                    return DropdownMenuItem<String>(
                      value: f['id'] as String,
                      child: Text('Flat $num'),
                    );
                  }).toList(),
                  onChanged: (val) {
                    if (val != null) {
                      final item = _flats.firstWhere((f) => f['id'] == val);
                      setState(() {
                        _selectedFlatId = val;
                        _selectedFlatNum = item['flat_number']?.toString() ?? '';
                      });
                      _checkFlatPreference(val);
                    }
                  },
                ),
                const SizedBox(height: 16),

                // Live Flat Delivery Preference Alert Box
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: allowsLeaveAtGate ? AppColors.successContainer : AppColors.warningContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        allowsLeaveAtGate ? Icons.check_circle : Icons.warning_amber_rounded,
                        color: allowsLeaveAtGate ? AppColors.success : AppColors.warning,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          allowsLeaveAtGate
                            ? 'Flat $_selectedFlatNum allows leaving package at gate.'
                            : 'Flat $_selectedFlatNum requires resident approval before entry.',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: allowsLeaveAtGate ? AppColors.success : AppColors.warning,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    const Text('Package Count:', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(width: 16),
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline),
                      onPressed: () {
                        if (_packageCount > 1) setState(() => _packageCount--);
                      },
                    ),
                    Text('$_packageCount', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    IconButton(
                      icon: const Icon(Icons.add_circle_outline),
                      onPressed: () => setState(() => _packageCount++),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                AppTextField(
                  label: 'Notes / Courier Name',
                  hint: 'e.g. Delivery boy Ramesh',
                  controller: _deliveryNotesController,
                ),
                const SizedBox(height: 24),

                AppButton(
                  label: allowsLeaveAtGate ? 'Record Parcel at Gate' : 'Send Delivery Entry Request',
                  isLoading: _isSubmittingDelivery,
                  onPressed: _handleLogDelivery,
                ),
              ],
            ),
          ),

          // Tab 2: Staff Logger & Active Staff
          SingleChildScrollView(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('Quick Staff Entry', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 12),
                AppTextField(
                  label: 'Staff Name',
                  hint: 'e.g. Sunita Devi (Maid)',
                  controller: _staffNameController,
                  textCapitalization: TextCapitalization.words,
                ),
                const SizedBox(height: 12),
                AppTextField(
                  label: 'Mobile Number',
                  hint: '10-digit number',
                  controller: _staffPhoneController,
                  keyboardType: TextInputType.phone,
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  children: _staffRoles.map((r) {
                    final isSel = _staffRole == r;
                    return ChoiceChip(
                      label: Text(r),
                      selected: isSel,
                      onSelected: (sel) {
                        if (sel) setState(() => _staffRole = r);
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                AppButton(
                  label: 'Check In Staff',
                  isLoading: _isSubmittingStaff,
                  onPressed: _handleLogStaff,
                ),
                const SizedBox(height: 24),
                const Divider(),
                const SizedBox(height: 12),

                Text(
                  'Staff Currently Inside (${_insideStaff.length})',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 8),

                if (_isLoadingStaff)
                  const LinearProgressIndicator()
                else if (_insideStaff.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(child: Text('No daily staff currently inside campus')),
                  )
                else
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _insideStaff.length,
                    itemBuilder: (context, index) {
                      final s = _insideStaff[index];
                      return Card(
                        child: ListTile(
                          title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text('${s.roleType} • In since ${DateFormatter.formatTime(s.entryTime)}'),
                          trailing: ElevatedButton(
                            style: ElevatedButton.styleFrom(minimumSize: const Size(80, 36)),
                            onPressed: () => _handleStaffExit(s.id),
                            child: const Text('Exit'),
                          ),
                        ),
                      );
                    },
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
