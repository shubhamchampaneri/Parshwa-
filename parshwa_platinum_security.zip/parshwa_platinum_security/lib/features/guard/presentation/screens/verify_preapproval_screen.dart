import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/numeric_keypad.dart';
import '../../data/repositories/guard_repository_impl.dart';

class VerifyPreapprovalScreen extends ConsumerStatefulWidget {
  const VerifyPreapprovalScreen({super.key});

  @override
  ConsumerState<VerifyPreapprovalScreen> createState() => _VerifyPreapprovalScreenState();
}

class _VerifyPreapprovalScreenState extends ConsumerState<VerifyPreapprovalScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _otp = '';
  bool _isVerifying = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _onDigitPressed(String digit) {
    if (_otp.length < 6) {
      setState(() {
        _otp += digit;
        _errorMessage = null;
      });
      if (_otp.length == 6) {
        _verifyCode(_otp);
      }
    }
  }

  void _onDeletePressed() {
    if (_otp.isNotEmpty) {
      setState(() {
        _otp = _otp.substring(0, _otp.length - 1);
        _errorMessage = null;
      });
    }
  }

  Future<void> _verifyCode(String code) async {
    setState(() {
      _isVerifying = true;
      _errorMessage = null;
    });

    try {
      final repo = ref.read(guardRepositoryProvider);
      final res = await repo.verifyPreApprovalCode(code);

      if (!mounted) return;
      setState(() => _isVerifying = false);

      if (res['success'] == true) {
        _showVerifiedDialog(res['visitor_name'] as String? ?? 'Visitor');
      } else {
        setState(() {
          _otp = '';
          _errorMessage = res['message'] as String? ?? 'Invalid pass';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isVerifying = false;
          _otp = '';
          _errorMessage = e.toString();
        });
      }
    }
  }

  void _showVerifiedDialog(String visitorName) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: AppColors.success, size: 28),
            SizedBox(width: 8),
            Text('Pass Verified!'),
          ],
        ),
        content: Text(
          'Pre-approval pass for $visitorName verified successfully.\n'
          'Visitor is now checked in as INSIDE.',
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.success),
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context); // Return to guard dashboard
            },
            child: const Text('Confirm Entry', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Verify Pre-Approved Pass'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Enter 6-Digit OTP', icon: Icon(Icons.dialpad)),
            Tab(text: 'Scan QR Pass', icon: Icon(Icons.qr_code_scanner)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab 1: OTP Keypad
          Column(
            children: [
              const SizedBox(height: 24),
              const Text(
                'Enter 6-digit visitor pass code provided by resident:',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textSecondaryLight),
              ),
              const SizedBox(height: 20),

              // OTP Digits display
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(6, (i) {
                  final digit = i < _otp.length ? _otp[i] : '';
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    width: 44,
                    height: 54,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: digit.isNotEmpty ? AppColors.primary : AppColors.borderLight,
                        width: digit.isNotEmpty ? 2 : 1,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        digit,
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 16),

              if (_errorMessage != null)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(
                    _errorMessage!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppColors.error, fontWeight: FontWeight.bold),
                  ),
                ),

              if (_isVerifying)
                const Padding(
                  padding: EdgeInsets.all(12),
                  child: CircularProgressIndicator(),
                ),

              const Spacer(),

              NumericKeypad(
                onDigitPressed: _onDigitPressed,
                onDeletePressed: _onDeletePressed,
              ),
              const SizedBox(height: 20),
            ],
          ),

          // Tab 2: Camera QR Scanner
          MobileScanner(
            onDetect: (capture) {
              final barcodes = capture.barcodes;
              for (final barcode in barcodes) {
                final val = barcode.rawValue;
                if (val != null && !_isVerifying) {
                  _verifyCode(val);
                  break;
                }
              }
            },
          ),
        ],
      ),
    );
  }
}
