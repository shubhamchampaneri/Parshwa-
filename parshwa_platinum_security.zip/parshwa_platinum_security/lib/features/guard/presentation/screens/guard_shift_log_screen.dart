import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';
import '../controllers/guard_dashboard_controller.dart';

class GuardShiftLogScreen extends ConsumerStatefulWidget {
  const GuardShiftLogScreen({super.key});

  @override
  ConsumerState<GuardShiftLogScreen> createState() => _GuardShiftLogScreenState();
}

class _GuardShiftLogScreenState extends ConsumerState<GuardShiftLogScreen> {
  final _handoverNotesController = TextEditingController();

  @override
  void dispose() {
    _handoverNotesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dashboard = ref.watch(guardDashboardControllerProvider);
    final user = ref.watch(authControllerProvider).userProfile;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Guard Shift Log & Handover'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Guard on Duty', style: TextStyle(color: Colors.grey)),
                        Text(user?.fullName ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const Divider(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Gate Location', style: TextStyle(color: Colors.grey)),
                        const Text('Main Gate', style: TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const Divider(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Date', style: TextStyle(color: Colors.grey)),
                        Text(DateFormatter.formatDate(DateTime.now()), style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            Text(
              'Shift Metrics Summary',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: _buildMetricTile(
                    'Total Walk-ins',
                    dashboard.todayEntriesCount.toString(),
                    AppColors.primary,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildMetricTile(
                    'Total Exits',
                    dashboard.todayExitsCount.toString(),
                    Colors.teal,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildMetricTile(
                    'Currently Inside',
                    dashboard.insideCount.toString(),
                    AppColors.success,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildMetricTile(
                    'Pending Resident Calls',
                    dashboard.pendingCount.toString(),
                    AppColors.warning,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            AppTextField(
              label: 'Handover Notes for Relieving Guard',
              hint: 'e.g. Flat 302 Amazon package stored in locker 2. Water tanker arrived at 3 PM.',
              controller: _handoverNotesController,
              maxLines: 4,
            ),
            const SizedBox(height: 32),

            AppButton(
              label: 'Submit Shift Handover',
              icon: Icons.check,
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Shift report saved to society audit log.'),
                    backgroundColor: AppColors.success,
                  ),
                );
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricTile(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
          ),
        ],
      ),
    );
  }
}
