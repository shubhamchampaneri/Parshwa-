import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/entities/visitor_log.dart';
import '../domain/repositories/guard_repository.dart';
import '../../data/repositories/guard_repository_impl.dart';

class GuardDashboardState {
  final int insideCount;
  final int pendingCount;
  final int todayEntriesCount;
  final int todayExitsCount;
  final List<VisitorLog> insideVisitors;
  final bool isLoading;
  final String? errorMessage;
  final String? successMessage;

  const GuardDashboardState({
    this.insideCount = 0,
    this.pendingCount = 0,
    this.todayEntriesCount = 0,
    this.todayExitsCount = 0,
    this.insideVisitors = const [],
    this.isLoading = false,
    this.errorMessage,
    this.successMessage,
  });

  GuardDashboardState copyWith({
    int? insideCount,
    int? pendingCount,
    int? todayEntriesCount,
    int? todayExitsCount,
    List<VisitorLog>? insideVisitors,
    bool? isLoading,
    String? errorMessage,
    String? successMessage,
    bool clearErrors = false,
  }) {
    return GuardDashboardState(
      insideCount: insideCount ?? this.insideCount,
      pendingCount: pendingCount ?? this.pendingCount,
      todayEntriesCount: todayEntriesCount ?? this.todayEntriesCount,
      todayExitsCount: todayExitsCount ?? this.todayExitsCount,
      insideVisitors: insideVisitors ?? this.insideVisitors,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearErrors ? null : errorMessage,
      successMessage: clearErrors ? null : successMessage,
    );
  }
}

final guardDashboardControllerProvider =
    StateNotifierProvider<GuardDashboardController, GuardDashboardState>((ref) {
  final repo = ref.watch(guardRepositoryProvider);
  return GuardDashboardController(repo);
});

class GuardDashboardController extends StateNotifier<GuardDashboardState> {
  final GuardRepository _repo;

  GuardDashboardController(this._repo) : super(const GuardDashboardState(isLoading: true)) {
    loadDashboard();
  }

  Future<void> loadDashboard() async {
    state = state.copyWith(isLoading: true, clearErrors: true);
    try {
      final metrics = await _repo.getGateMetrics();
      final inside = await _repo.getInsideVisitors();

      state = state.copyWith(
        insideCount: metrics['inside'] ?? 0,
        pendingCount: metrics['pending'] ?? 0,
        todayEntriesCount: metrics['entriesToday'] ?? 0,
        todayExitsCount: metrics['exitsToday'] ?? 0,
        insideVisitors: inside,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }

  Future<bool> checkOutVisitor(String logId) async {
    try {
      await _repo.markVisitorExit(logId);
      state = state.copyWith(successMessage: 'Visitor check-out recorded');
      await loadDashboard();
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
      return false;
    }
  }
}
