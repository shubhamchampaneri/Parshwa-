import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/network_info.dart';
import '../../../../core/storage/offline_queue_database.dart';
import '../domain/repositories/guard_repository.dart';
import '../../data/repositories/guard_repository_impl.dart';

class OfflineSyncState {
  final bool isOnline;
  final bool isSyncing;
  final int pendingCount;
  final String? lastSyncMessage;

  const OfflineSyncState({
    this.isOnline = true,
    this.isSyncing = false,
    this.pendingCount = 0,
    this.lastSyncMessage,
  });

  OfflineSyncState copyWith({
    bool? isOnline,
    bool? isSyncing,
    int? pendingCount,
    String? lastSyncMessage,
  }) {
    return OfflineSyncState(
      isOnline: isOnline ?? this.isOnline,
      isSyncing: isSyncing ?? this.isSyncing,
      pendingCount: pendingCount ?? this.pendingCount,
      lastSyncMessage: lastSyncMessage ?? this.lastSyncMessage,
    );
  }
}

final offlineSyncControllerProvider =
    StateNotifierProvider<OfflineSyncController, OfflineSyncState>((ref) {
  final networkInfo = ref.watch(networkInfoProvider);
  final offlineDb = ref.watch(offlineQueueDatabaseProvider);
  final guardRepo = ref.watch(guardRepositoryProvider);
  return OfflineSyncController(networkInfo, offlineDb, guardRepo);
});

class OfflineSyncController extends StateNotifier<OfflineSyncState> {
  final NetworkInfo _networkInfo;
  final OfflineQueueDatabase _offlineDb;
  final GuardRepository _guardRepo;

  OfflineSyncController(this._networkInfo, this._offlineDb, this._guardRepo)
      : super(const OfflineSyncState()) {
    _init();
  }

  Future<void> _init() async {
    final connected = await _networkInfo.isConnected;
    final count = await _offlineDb.getPendingCount();

    state = state.copyWith(isOnline: connected, pendingCount: count);

    // Watch for network restoration
    _networkInfo.onConnectivityChanged.listen((isOnline) {
      state = state.copyWith(isOnline: isOnline);
      if (isOnline) {
        syncPendingQueue();
      }
    });
  }

  Future<void> refreshPendingCount() async {
    final count = await _offlineDb.getPendingCount();
    state = state.copyWith(pendingCount: count);
  }

  Future<void> syncPendingQueue() async {
    final isOnline = await _networkInfo.isConnected;
    if (!isOnline || state.isSyncing) return;

    final pending = await _offlineDb.getPendingItems();
    if (pending.isEmpty) {
      state = state.copyWith(pendingCount: 0);
      return;
    }

    state = state.copyWith(isSyncing: true);

    for (final item in pending) {
      try {
        if (item.actionType == 'WALKIN_ENTRY') {
          File? photo;
          if (item.localPhotoPath != null) {
            final f = File(item.localPhotoPath!);
            if (await f.exists()) photo = f;
          }

          await _guardRepo.logWalkInVisitor(
            visitorName: item.payload['visitor_name'] as String,
            visitorPhone: item.payload['visitor_phone'] as String,
            flatId: item.payload['flat_id'] as String,
            purpose: item.payload['purpose'] as String,
            vehicleNumber: item.payload['vehicle_number'] as String?,
            numberOfVisitors: (item.payload['number_of_visitors'] as int?) ?? 1,
            photoFile: photo,
          );
        } else if (item.actionType == 'CHECKOUT') {
          final logId = item.payload['log_id'] as String;
          await _guardRepo.markVisitorExit(logId);
        }

        // Successfully synced, remove from local queue
        if (item.id != null) {
          await _offlineDb.remove(item.id!);
        }
      } catch (e) {
        if (item.id != null) {
          await _offlineDb.incrementRetry(item.id!, item.retryCount);
        }
      }
    }

    final remaining = await _offlineDb.getPendingCount();
    state = state.copyWith(
      isSyncing: false,
      pendingCount: remaining,
      lastSyncMessage: remaining == 0 ? 'All gate logs synchronized' : '$remaining items pending sync',
    );
  }
}
