class DeliveryLog {
  final String id;
  final String flatId;
  final String? flatNumber;
  final String guardId;
  final String companyName; // AMAZON, FLIPKART, ZOMATO, SWIGGY, BLINKIT, COURIER, OTHER
  final int packageCount;
  final String status; // AT_GATE, COLLECTED, DELIVERED_TO_FLAT
  final String? notes;
  final DateTime createdAt;

  const DeliveryLog({
    required this.id,
    required this.flatId,
    this.flatNumber,
    required this.guardId,
    required this.companyName,
    this.packageCount = 1,
    required this.status,
    this.notes,
    required this.createdAt,
  });
}

class StaffEntry {
  final String id;
  final String name;
  final String phoneNumber;
  final String roleType; // MAID, DRIVER, COOK, CLEANER, TECHNICIAN, OTHER
  final String? flatId;
  final String? flatNumber;
  final String guardId;
  final DateTime entryTime;
  final DateTime? exitTime;

  const StaffEntry({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.roleType,
    this.flatId,
    this.flatNumber,
    required this.guardId,
    required this.entryTime,
    this.exitTime,
  });

  bool get isInside => exitTime == null;
}
