class VisitorLog {
  final String id;
  final String visitorId;
  final String visitorName;
  final String visitorPhone;
  final String? visitorPhotoUrl;
  final String flatId;
  final String? flatNumber;
  final String? guardId;
  final String? residentId;
  final String? residentName;
  final String purpose;
  final String? vehicleNumber;
  final int numberOfVisitors;
  final String status; // 'PENDING', 'APPROVED', 'REJECTED', 'INSIDE', 'EXITED'
  final DateTime? entryTime;
  final DateTime? exitTime;
  final String? rejectionReason;
  final DateTime createdAt;

  const VisitorLog({
    required this.id,
    required this.visitorId,
    required this.visitorName,
    required this.visitorPhone,
    this.visitorPhotoUrl,
    required this.flatId,
    this.flatNumber,
    this.guardId,
    this.residentId,
    this.residentName,
    required this.purpose,
    this.vehicleNumber,
    this.numberOfVisitors = 1,
    required this.status,
    this.entryTime,
    this.exitTime,
    this.rejectionReason,
    required this.createdAt,
  });

  bool get isPending => status == 'PENDING';
  bool get isInside => status == 'INSIDE';
  bool get isApproved => status == 'APPROVED';
  bool get isRejected => status == 'REJECTED';
  bool get isExited => status == 'EXITED';
}
