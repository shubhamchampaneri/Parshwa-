import 'dart:io';
import '../domain/entities/delivery_log.dart';
import '../domain/entities/visitor_log.dart';

abstract class GuardRepository {
  Future<Map<String, int>> getGateMetrics();

  Future<VisitorLog> logWalkInVisitor({
    required String visitorName,
    required String visitorPhone,
    required String flatId,
    required String purpose,
    String? vehicleNumber,
    int numberOfVisitors = 1,
    File? photoFile,
  });

  Future<Map<String, dynamic>> verifyPreApprovalCode(String code);

  Future<List<VisitorLog>> getInsideVisitors();
  Future<void> markVisitorExit(String logId);

  Future<DeliveryLog> logDeliveryEntry({
    required String flatId,
    required String companyName,
    int packageCount = 1,
    String? notes,
  });

  Future<Map<String, dynamic>> getDeliveryPreferenceForFlat(String flatId);

  Future<StaffEntry> logStaffEntry({
    required String name,
    required String phoneNumber,
    required String roleType,
    String? flatId,
  });

  Future<List<StaffEntry>> getInsideStaff();
  Future<void> markStaffExit(String staffId);

  Stream<List<Map<String, dynamic>>> watchActiveSosAlerts();
  Future<void> acknowledgeSosAlert(String alertId);

  Future<List<Map<String, dynamic>>> getFlatsDirectory();
}
