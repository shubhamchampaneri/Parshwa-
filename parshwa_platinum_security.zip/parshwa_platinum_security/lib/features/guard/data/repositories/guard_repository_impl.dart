import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;
import '../../../../core/constants/supabase_tables.dart';
import '../../../../core/errors/exceptions.dart';
import '../../../../core/network/network_info.dart';
import '../../../../core/network/supabase_client.dart';
import '../../../../core/storage/offline_queue_database.dart';
import '../../../../core/utils/image_compressor.dart';
import '../domain/entities/delivery_log.dart';
import '../domain/entities/visitor_log.dart';
import '../domain/repositories/guard_repository.dart';
import '../models/delivery_log_model.dart';
import '../models/staff_entry_model.dart';
import '../models/visitor_log_model.dart';

final guardRepositoryProvider = Provider<GuardRepository>((ref) {
  final client = ref.watch(supabaseClientProvider);
  final offlineDb = ref.watch(offlineQueueDatabaseProvider);
  final networkInfo = ref.watch(networkInfoProvider);
  return GuardRepositoryImpl(client, offlineDb, networkInfo);
});

class GuardRepositoryImpl implements GuardRepository {
  final sb.SupabaseClient _client;
  final OfflineQueueDatabase _offlineDb;
  final NetworkInfo _networkInfo;

  GuardRepositoryImpl(this._client, this._offlineDb, this._networkInfo);

  @override
  Future<Map<String, int>> getGateMetrics() async {
    try {
      final now = DateTime.now();
      final startOfDay = DateTime(now.year, now.month, now.day).toIso8601String();

      // Visitors inside
      final insideRes = await _client
          .from(SupabaseTables.visitorLogs)
          .select('id')
          .eq('status', 'INSIDE');

      // Pending resident approvals
      final pendingRes = await _client
          .from(SupabaseTables.visitorLogs)
          .select('id')
          .eq('status', 'PENDING');

      // Total entries today
      final entriesRes = await _client
          .from(SupabaseTables.visitorLogs)
          .select('id')
          .gte('created_at', startOfDay);

      // Exits today
      final exitsRes = await _client
          .from(SupabaseTables.visitorLogs)
          .select('id')
          .gte('exit_time', startOfDay);

      return {
        'inside': (insideRes as List).length,
        'pending': (pendingRes as List).length,
        'entriesToday': (entriesRes as List).length,
        'exitsToday': (exitsRes as List).length,
      };
    } catch (_) {
      return {'inside': 0, 'pending': 0, 'entriesToday': 0, 'exitsToday': 0};
    }
  }

  @override
  Future<VisitorLog> logWalkInVisitor({
    required String visitorName,
    required String visitorPhone,
    required String flatId,
    required String purpose,
    String? vehicleNumber,
    int numberOfVisitors = 1,
    File? photoFile,
  }) async {
    final isOnline = await _networkInfo.isConnected;

    if (!isOnline) {
      // Queue locally in SQLite when gate connection drops
      await _offlineDb.enqueue(
        OfflineQueueItem(
          actionType: 'WALKIN_ENTRY',
          payload: {
            'visitor_name': visitorName,
            'visitor_phone': visitorPhone,
            'flat_id': flatId,
            'purpose': purpose,
            'vehicle_number': vehicleNumber,
            'number_of_visitors': numberOfVisitors,
          },
          localPhotoPath: photoFile?.path,
          createdAt: DateTime.now(),
        ),
      );

      // Return local placeholder
      return VisitorLogModel(
        id: 'local-${DateTime.now().millisecondsSinceEpoch}',
        visitorId: 'local-visitor',
        visitorName: visitorName,
        visitorPhone: visitorPhone,
        flatId: flatId,
        purpose: purpose,
        vehicleNumber: vehicleNumber,
        status: 'PENDING',
        createdAt: DateTime.now(),
      );
    }

    try {
      final user = _client.auth.currentUser;
      if (user == null) throw const AuthException('Not authenticated');

      String? photoUrl;
      if (photoFile != null) {
        final compressed = await ImageCompressor.compressImageFile(photoFile);
        final fileToUpload = compressed ?? photoFile;
        final fileName = 'visitor_${DateTime.now().millisecondsSinceEpoch}.jpg';

        await _client.storage
            .from(SupabaseTables.bucketVisitorPhotos)
            .upload(fileName, fileToUpload);

        photoUrl = _client.storage
            .from(SupabaseTables.bucketVisitorPhotos)
            .getPublicUrl(fileName);
      }

      // Check if visitor already exists in directory by phone
      String visitorId;
      final existingVisitor = await _client
          .from(SupabaseTables.visitors)
          .select('id')
          .eq('phone_number', visitorPhone.trim())
          .maybeSingle();

      if (existingVisitor != null) {
        visitorId = existingVisitor['id'] as String;
        if (photoUrl != null) {
          await _client
              .from(SupabaseTables.visitors)
              .update({'photo_url': photoUrl})
              .eq('id', visitorId);
        }
      } else {
        final newV = await _client
            .from(SupabaseTables.visitors)
            .insert({
              'full_name': visitorName.trim(),
              'phone_number': visitorPhone.trim(),
              'photo_url': photoUrl,
              'vehicle_number': vehicleNumber?.trim().toUpperCase(),
            })
            .select('id')
            .single();
        visitorId = newV['id'] as String;
      }

      // Insert visitor log
      final res = await _client
          .from(SupabaseTables.visitorLogs)
          .insert({
            'visitor_id': visitorId,
            'flat_id': flatId,
            'guard_id': user.id,
            'purpose': purpose,
            'vehicle_number': vehicleNumber?.trim().toUpperCase(),
            'number_of_visitors': numberOfVisitors,
            'status': 'PENDING',
          })
          .select('*, visitors(*), flats(flat_number)')
          .single();

      return VisitorLogModel.fromJson(res);
    } catch (e) {
      throw ServerException('Failed to log walk-in visitor: $e');
    }
  }

  @override
  Future<Map<String, dynamic>> verifyPreApprovalCode(String code) async {
    try {
      final res = await _client.rpc(
        'verify_and_checkin_preapproval',
        params: {'p_code': code.trim()},
      );
      return Map<String, dynamic>.from(res as Map);
    } catch (e) {
      throw ServerException('Failed to verify pass: $e');
    }
  }

  @override
  Future<List<VisitorLog>> getInsideVisitors() async {
    try {
      final res = await _client
          .from(SupabaseTables.visitorLogs)
          .select('*, visitors(*), flats(flat_number)')
          .eq('status', 'INSIDE')
          .order('entry_time', ascending: false);

      return (res as List).map((e) => VisitorLogModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      throw ServerException('Failed to fetch inside visitors: $e');
    }
  }

  @override
  Future<void> markVisitorExit(String logId) async {
    final isOnline = await _networkInfo.isConnected;

    if (!isOnline) {
      await _offlineDb.enqueue(
        OfflineQueueItem(
          actionType: 'CHECKOUT',
          payload: {'log_id': logId, 'exit_time': DateTime.now().toIso8601String()},
          createdAt: DateTime.now(),
        ),
      );
      return;
    }

    try {
      await _client.from(SupabaseTables.visitorLogs).update({
        'status': 'EXITED',
        'exit_time': DateTime.now().toIso8601String(),
      }).eq('id', logId);
    } catch (e) {
      throw ServerException('Failed to record visitor exit: $e');
    }
  }

  @override
  Future<DeliveryLog> logDeliveryEntry({
    required String flatId,
    required String companyName,
    int packageCount = 1,
    String? notes,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw const AuthException('Not authenticated');

      final res = await _client
          .from(SupabaseTables.deliveryLogs)
          .insert({
            'flat_id': flatId,
            'guard_id': user.id,
            'company_name': companyName,
            'package_count': packageCount,
            'status': 'AT_GATE',
            'notes': notes,
          })
          .select('*, flats(flat_number)')
          .single();

      return DeliveryLogModel.fromJson(res);
    } catch (e) {
      throw ServerException('Failed to log delivery: $e');
    }
  }

  @override
  Future<Map<String, dynamic>> getDeliveryPreferenceForFlat(String flatId) async {
    try {
      final res = await _client
          .from(SupabaseTables.flats)
          .select('delivery_preference, delivery_instructions')
          .eq('id', flatId)
          .single();

      return Map<String, dynamic>.from(res);
    } catch (_) {
      return {'delivery_preference': 'ASK_FIRST', 'delivery_instructions': null};
    }
  }

  @override
  Future<StaffEntry> logStaffEntry({
    required String name,
    required String phoneNumber,
    required String roleType,
    String? flatId,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw const AuthException('Not authenticated');

      final res = await _client
          .from(SupabaseTables.staffEntries)
          .insert({
            'name': name.trim(),
            'phone_number': phoneNumber.trim(),
            'role_type': roleType,
            'flat_id': flatId,
            'guard_id': user.id,
            'entry_time': DateTime.now().toIso8601String(),
          })
          .select('*, flats(flat_number)')
          .single();

      return StaffEntryModel.fromJson(res);
    } catch (e) {
      throw ServerException('Failed to log staff entry: $e');
    }
  }

  @override
  Future<List<StaffEntry>> getInsideStaff() async {
    try {
      final res = await _client
          .from(SupabaseTables.staffEntries)
          .select('*, flats(flat_number)')
          .isFilter('exit_time', null)
          .order('entry_time', ascending: false);

      return (res as List).map((e) => StaffEntryModel.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      return [];
    }
  }

  @override
  Future<void> markStaffExit(String staffId) async {
    try {
      await _client
          .from(SupabaseTables.staffEntries)
          .update({'exit_time': DateTime.now().toIso8601String()})
          .eq('id', staffId);
    } catch (e) {
      throw ServerException('Failed to mark staff exit: $e');
    }
  }

  @override
  Stream<List<Map<String, dynamic>>> watchActiveSosAlerts() {
    return _client
        .from(SupabaseTables.sosAlerts)
        .stream(primaryKey: ['id'])
        .eq('status', 'ACTIVE')
        .order('created_at', ascending: false)
        .asyncMap((list) async {
          if (list.isEmpty) return <Map<String, dynamic>>[];

          final res = await _client
              .from(SupabaseTables.sosAlerts)
              .select('*, flats(flat_number), profiles:resident_id(full_name, phone_number)')
              .eq('status', 'ACTIVE');

          return (res as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
        });
  }

  @override
  Future<void> acknowledgeSosAlert(String alertId) async {
    try {
      final user = _client.auth.currentUser;
      await _client.from(SupabaseTables.sosAlerts).update({
        'status': 'ACKNOWLEDGED',
        'acknowledged_by': user?.id,
        'acknowledged_at': DateTime.now().toIso8601String(),
      }).eq('id', alertId);
    } catch (e) {
      throw ServerException('Failed to acknowledge SOS: $e');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> getFlatsDirectory() async {
    try {
      final res = await _client
          .from(SupabaseTables.flats)
          .select('id, flat_number, floor_number, unit_number, delivery_preference')
          .order('flat_number', ascending: true);

      return (res as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      // Local fallback
      final List<Map<String, dynamic>> list = [];
      for (int f = 1; f <= 7; f++) {
        for (int u = 1; u <= 4; u++) {
          list.add({'id': 'flat-${f}0$u', 'flat_number': '${f}0$u', 'floor_number': f, 'unit_number': u});
        }
      }
      return list;
    }
  }
}
