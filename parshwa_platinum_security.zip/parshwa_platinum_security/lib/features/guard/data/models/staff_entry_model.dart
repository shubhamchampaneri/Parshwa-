import '../../domain/entities/delivery_log.dart';

class StaffEntryModel extends StaffEntry {
  const StaffEntryModel({
    required super.id,
    required super.name,
    required super.phoneNumber,
    required super.roleType,
    super.flatId,
    super.flatNumber,
    required super.guardId,
    required super.entryTime,
    super.exitTime,
  });

  factory StaffEntryModel.fromJson(Map<String, dynamic> json) {
    String? flatNum;
    if (json['flats'] != null && json['flats'] is Map) {
      flatNum = json['flats']['flat_number'] as String?;
    } else {
      flatNum = json['flat_number'] as String?;
    }

    return StaffEntryModel(
      id: json['id'] as String,
      name: json['name'] as String,
      phoneNumber: json['phone_number'] as String,
      roleType: json['role_type'] as String,
      flatId: json['flat_id'] as String?,
      flatNumber: flatNum,
      guardId: json['guard_id'] as String,
      entryTime: DateTime.parse(json['entry_time'] as String),
      exitTime: json['exit_time'] != null ? DateTime.parse(json['exit_time'] as String) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'phone_number': phoneNumber,
      'role_type': roleType,
      'flat_id': flatId,
      'guard_id': guardId,
      'entry_time': entryTime.toIso8601String(),
      'exit_time': exitTime?.toIso8601String(),
    };
  }
}
