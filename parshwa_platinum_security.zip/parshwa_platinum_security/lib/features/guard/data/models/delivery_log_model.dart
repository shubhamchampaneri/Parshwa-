import '../../domain/entities/delivery_log.dart';

class DeliveryLogModel extends DeliveryLog {
  const DeliveryLogModel({
    required super.id,
    required super.flatId,
    super.flatNumber,
    required super.guardId,
    required super.companyName,
    super.packageCount = 1,
    required super.status,
    super.notes,
    required super.createdAt,
  });

  factory DeliveryLogModel.fromJson(Map<String, dynamic> json) {
    String? flatNum;
    if (json['flats'] != null && json['flats'] is Map) {
      flatNum = json['flats']['flat_number'] as String?;
    } else {
      flatNum = json['flat_number'] as String?;
    }

    return DeliveryLogModel(
      id: json['id'] as String,
      flatId: json['flat_id'] as String,
      flatNumber: flatNum,
      guardId: json['guard_id'] as String,
      companyName: json['company_name'] as String,
      packageCount: (json['package_count'] as int?) ?? 1,
      status: json['status'] as String? ?? 'AT_GATE',
      notes: json['notes'] as String?,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'flat_id': flatId,
      'guard_id': guardId,
      'company_name': companyName,
      'package_count': packageCount,
      'status': status,
      'notes': notes,
    };
  }
}
