import '../../domain/entities/visitor_log.dart';

class VisitorLogModel extends VisitorLog {
  const VisitorLogModel({
    required super.id,
    required super.visitorId,
    required super.visitorName,
    required super.visitorPhone,
    super.visitorPhotoUrl,
    required super.flatId,
    super.flatNumber,
    super.guardId,
    super.residentId,
    super.residentName,
    required super.purpose,
    super.vehicleNumber,
    super.numberOfVisitors = 1,
    required super.status,
    super.entryTime,
    super.exitTime,
    super.rejectionReason,
    required super.createdAt,
  });

  factory VisitorLogModel.fromJson(Map<String, dynamic> json) {
    String vName = 'Visitor';
    String vPhone = '';
    String? vPhoto;

    if (json['visitors'] != null && json['visitors'] is Map) {
      final v = json['visitors'] as Map<String, dynamic>;
      vName = v['full_name'] as String? ?? 'Visitor';
      vPhone = v['phone_number'] as String? ?? '';
      vPhoto = v['photo_url'] as String?;
    } else {
      vName = json['visitor_name'] as String? ?? 'Visitor';
      vPhone = json['visitor_phone'] as String? ?? '';
      vPhoto = json['photo_url'] as String?;
    }

    String? flatNum;
    if (json['flats'] != null && json['flats'] is Map) {
      flatNum = json['flats']['flat_number'] as String?;
    } else {
      flatNum = json['flat_number'] as String?;
    }

    String? resName;
    if (json['profiles'] != null && json['profiles'] is Map) {
      resName = json['profiles']['full_name'] as String?;
    }

    return VisitorLogModel(
      id: json['id'] as String,
      visitorId: json['visitor_id'] as String? ?? '',
      visitorName: vName,
      visitorPhone: vPhone,
      visitorPhotoUrl: vPhoto,
      flatId: json['flat_id'] as String,
      flatNumber: flatNum,
      guardId: json['guard_id'] as String?,
      residentId: json['resident_id'] as String?,
      residentName: resName,
      purpose: json['purpose'] as String? ?? 'GUEST',
      vehicleNumber: json['vehicle_number'] as String?,
      numberOfVisitors: (json['number_of_visitors'] as int?) ?? 1,
      status: json['status'] as String? ?? 'PENDING',
      entryTime: json['entry_time'] != null ? DateTime.parse(json['entry_time'] as String) : null,
      exitTime: json['exit_time'] != null ? DateTime.parse(json['exit_time'] as String) : null,
      rejectionReason: json['rejection_reason'] as String?,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'visitor_id': visitorId,
      'flat_id': flatId,
      'guard_id': guardId,
      'resident_id': residentId,
      'purpose': purpose,
      'vehicle_number': vehicleNumber,
      'number_of_visitors': numberOfVisitors,
      'status': status,
      'entry_time': entryTime?.toIso8601String(),
      'exit_time': exitTime?.toIso8601String(),
      'rejection_reason': rejectionReason,
    };
  }
}
