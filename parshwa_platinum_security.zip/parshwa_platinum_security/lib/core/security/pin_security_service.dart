import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';

final secureStorageProvider = Provider<FlutterSecureStorage>((ref) {
  return const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
  );
});

final pinSecurityServiceProvider = Provider<PinSecurityService>((ref) {
  final storage = ref.watch(secureStorageProvider);
  return PinSecurityService(storage);
});

class PinVerificationResult {
  final bool isSuccess;
  final bool isLockedOut;
  final int remainingAttempts;
  final int lockoutSecondsRemaining;
  final String? errorMessage;

  const PinVerificationResult({
    required this.isSuccess,
    this.isLockedOut = false,
    this.remainingAttempts = 0,
    this.lockoutSecondsRemaining = 0,
    this.errorMessage,
  });
}

class PinSecurityService {
  final FlutterSecureStorage _storage;

  PinSecurityService(this._storage);

  String _generateSalt() {
    final random = Random.secure();
    final values = List<int>.generate(32, (i) => random.nextInt(256));
    return base64Url.encode(values);
  }

  String _hashPin(String pin, String salt) {
    // Key stretching: 10,000 rounds of HMAC-SHA256
    List<int> currentHash = utf8.encode(pin);
    final saltBytes = utf8.encode(salt);
    for (int i = 0; i < 10000; i++) {
      final hmac = Hmac(sha256, saltBytes);
      currentHash = hmac.convert(currentHash).bytes;
    }
    return base64Encode(currentHash);
  }

  Future<bool> hasPinSet() async {
    final hash = await _storage.read(key: AppConstants.keyPinHash);
    return hash != null && hash.isNotEmpty;
  }

  Future<void> savePin(String pin) async {
    if (pin.length < AppConstants.pinMinLength || pin.length > AppConstants.pinMaxLength) {
      throw ArgumentError('PIN must be between ${AppConstants.pinMinLength} and ${AppConstants.pinMaxLength} digits.');
    }
    final salt = _generateSalt();
    final hash = _hashPin(pin, salt);

    await _storage.write(key: AppConstants.keyPinSalt, value: salt);
    await _storage.write(key: AppConstants.keyPinHash, value: hash);
    await _resetFailedAttempts();
  }

  Future<PinVerificationResult> verifyPin(String enteredPin) async {
    final lockoutUntilStr = await _storage.read(key: AppConstants.keyLockoutUntil);
    if (lockoutUntilStr != null) {
      final lockoutUntilEpoch = int.tryParse(lockoutUntilStr) ?? 0;
      final nowEpoch = DateTime.now().millisecondsSinceEpoch;
      if (nowEpoch < lockoutUntilEpoch) {
        final remainingSeconds = ((lockoutUntilEpoch - nowEpoch) / 1000).ceil();
        return PinVerificationResult(
          isSuccess: false,
          isLockedOut: true,
          lockoutSecondsRemaining: remainingSeconds,
          errorMessage: 'Too many incorrect attempts. Please wait $remainingSeconds seconds.',
        );
      } else {
        // Lockout expired, reset attempts
        await _resetFailedAttempts();
      }
    }

    final salt = await _storage.read(key: AppConstants.keyPinSalt);
    final storedHash = await _storage.read(key: AppConstants.keyPinHash);

    if (salt == null || storedHash == null) {
      return const PinVerificationResult(
        isSuccess: false,
        errorMessage: 'No PIN is currently configured on this device.',
      );
    }

    final computedHash = _hashPin(enteredPin, salt);
    if (computedHash == storedHash) {
      await _resetFailedAttempts();
      await recordLastActive();
      return const PinVerificationResult(isSuccess: true);
    } else {
      final attemptsStr = await _storage.read(key: AppConstants.keyPinAttempts);
      final currentAttempts = (int.tryParse(attemptsStr ?? '0') ?? 0) + 1;
      final remaining = AppConstants.maxPinAttempts - currentAttempts;

      if (currentAttempts >= AppConstants.maxPinAttempts) {
        final lockoutUntil = DateTime.now().add(AppConstants.lockoutDuration).millisecondsSinceEpoch;
        await _storage.write(key: AppConstants.keyLockoutUntil, value: lockoutUntil.toString());
        await _storage.write(key: AppConstants.keyPinAttempts, value: currentAttempts.toString());
        return PinVerificationResult(
          isSuccess: false,
          isLockedOut: true,
          lockoutSecondsRemaining: AppConstants.lockoutDuration.inSeconds,
          errorMessage: 'Too many incorrect attempts. Keypad locked for 5 minutes.',
        );
      } else {
        await _storage.write(key: AppConstants.keyPinAttempts, value: currentAttempts.toString());
        return PinVerificationResult(
          isSuccess: false,
          remainingAttempts: remaining,
          errorMessage: 'Incorrect PIN. $remaining ${remaining == 1 ? "attempt" : "attempts"} remaining.',
        );
      }
    }
  }

  Future<void> _resetFailedAttempts() async {
    await _storage.delete(key: AppConstants.keyPinAttempts);
    await _storage.delete(key: AppConstants.keyLockoutUntil);
  }

  Future<void> clearPin() async {
    await _storage.delete(key: AppConstants.keyPinSalt);
    await _storage.delete(key: AppConstants.keyPinHash);
    await _resetFailedAttempts();
  }

  Future<void> recordLastActive() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    await _storage.write(key: AppConstants.keyLastActiveTimestamp, value: now.toString());
  }

  Future<bool> isSessionTimedOut() async {
    final lastActiveStr = await _storage.read(key: AppConstants.keyLastActiveTimestamp);
    if (lastActiveStr == null) return true;
    final lastActive = int.tryParse(lastActiveStr) ?? 0;
    final elapsedMs = DateTime.now().millisecondsSinceEpoch - lastActive;
    return elapsedMs >= AppConstants.backgroundLockTimeout.inMilliseconds;
  }
}
