import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';
import 'pin_security_service.dart';

final localAuthenticationProvider = Provider<LocalAuthentication>((ref) {
  return LocalAuthentication();
});

final biometricServiceProvider = Provider<BiometricService>((ref) {
  final localAuth = ref.watch(localAuthenticationProvider);
  final storage = ref.watch(secureStorageProvider);
  return BiometricService(localAuth, storage);
});

class BiometricService {
  final LocalAuthentication _localAuth;
  final FlutterSecureStorage _storage;

  BiometricService(this._localAuth, this._storage);

  Future<bool> isBiometricHardwareAvailable() async {
    try {
      final canCheck = await _localAuth.canCheckBiometrics;
      final isDeviceSupported = await _localAuth.isDeviceSupported();
      return canCheck && isDeviceSupported;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> isBiometricsEnabled() async {
    final enabledStr = await _storage.read(key: AppConstants.keyBiometricsEnabled);
    return enabledStr == 'true';
  }

  Future<void> setBiometricsEnabled(bool enabled) async {
    await _storage.write(
      key: AppConstants.keyBiometricsEnabled,
      value: enabled ? 'true' : 'false',
    );
  }

  Future<bool> authenticateWithBiometrics({
    String reason = 'Authenticate to access Parshwa Platinum Security',
  }) async {
    try {
      final isAvailable = await isBiometricHardwareAvailable();
      if (!isAvailable) return false;

      final isEnabled = await isBiometricsEnabled();
      if (!isEnabled) return false;

      return await _localAuth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );
    } on PlatformException {
      return false;
    }
  }
}
