import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

final offlineQueueDatabaseProvider = Provider<OfflineQueueDatabase>((ref) {
  return OfflineQueueDatabase();
});

class OfflineQueueItem {
  final int? id;
  final String actionType; // 'WALKIN_ENTRY', 'CHECKOUT', 'DELIVERY_ENTRY'
  final Map<String, dynamic> payload;
  final String? localPhotoPath;
  final DateTime createdAt;
  final int retryCount;

  OfflineQueueItem({
    this.id,
    required this.actionType,
    required this.payload,
    this.localPhotoPath,
    required this.createdAt,
    this.retryCount = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'action_type': actionType,
      'payload_json': jsonEncode(payload),
      'local_photo_path': localPhotoPath,
      'created_at': createdAt.toIso8601String(),
      'retry_count': retryCount,
    };
  }

  factory OfflineQueueItem.fromMap(Map<String, dynamic> map) {
    return OfflineQueueItem(
      id: map['id'] as int?,
      actionType: map['action_type'] as String,
      payload: jsonDecode(map['payload_json'] as String) as Map<String, dynamic>,
      localPhotoPath: map['local_photo_path'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      retryCount: (map['retry_count'] as int?) ?? 0,
    );
  }
}

class OfflineQueueDatabase {
  static const String _tableName = 'offline_queue';
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'pp_security_offline.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE $_tableName (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action_type TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            local_photo_path TEXT,
            created_at TEXT NOT NULL,
            retry_count INTEGER DEFAULT 0
          )
        ''');
      },
    );
  }

  Future<int> enqueue(OfflineQueueItem item) async {
    final db = await database;
    return await db.insert(_tableName, item.toMap());
  }

  Future<List<OfflineQueueItem>> getPendingItems() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      _tableName,
      orderBy: 'created_at ASC',
    );
    return maps.map((m) => OfflineQueueItem.fromMap(m)).toList();
  }

  Future<int> getPendingCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM $_tableName');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<void> remove(int id) async {
    final db = await database;
    await db.delete(_tableName, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> incrementRetry(int id, int currentRetries) async {
    final db = await database;
    await db.update(
      _tableName,
      {'retry_count': currentRetries + 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> clearAll() async {
    final db = await database;
    await db.delete(_tableName);
  }
}
