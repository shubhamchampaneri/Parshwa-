class SupabaseTables {
  static const String flats = 'flats';
  static const String profiles = 'profiles';
  static const String visitors = 'visitors';
  static const String visitorLogs = 'visitor_logs';
  static const String preApprovals = 'pre_approvals';
  static const String notices = 'notices';
  static const String complaints = 'complaints';
  static const String sosAlerts = 'sos_alerts';
  static const String deliveryLogs = 'delivery_logs';
  static const String staffEntries = 'staff_entries';
  static const String deviceTokens = 'device_tokens';
  static const String guardInviteCodes = 'guard_invite_codes';

  // Storage Buckets
  static const String bucketVisitorPhotos = 'visitor_photos';
  static const String bucketComplaintPhotos = 'complaint_photos';
  static const String bucketAvatars = 'avatars';
}
