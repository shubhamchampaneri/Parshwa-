class AppConstants {
  static const String appName = 'Parshwa Platinum Security';
  static const String societyName = 'Parshwa Platinum';
  static const int totalFloors = 7;
  static const int flatsPerFloor = 4;
  static const int totalFlats = 28;
  static const int maxResidentsPerFlat = 4;

  // PIN & Security Constants
  static const int pinMinLength = 4;
  static const int pinMaxLength = 6;
  static const int maxPinAttempts = 5;
  static const Duration lockoutDuration = Duration(minutes: 5);
  static const Duration backgroundLockTimeout = Duration(minutes: 5);

  // Storage Keys
  static const String keyPinSalt = 'pp_pin_salt_key';
  static const String keyPinHash = 'pp_pin_hash_key';
  static const String keyPinAttempts = 'pp_pin_failed_attempts';
  static const String keyLockoutUntil = 'pp_lockout_until_epoch';
  static const String keyBiometricsEnabled = 'pp_biometrics_enabled';
  static const String keySelectedLanguage = 'pp_selected_language';
  static const String keyLastActiveTimestamp = 'pp_last_active_epoch';

  // Image constraints for Supabase Free Tier
  static const int maxImageWidth = 800;
  static const int maxImageHeight = 800;
  static const int imageQuality = 70; // Produces ~60-80KB images
}

enum UserRole {
  resident,
  guard,
  admin;

  String get dbValue {
    switch (this) {
      case UserRole.resident:
        return 'RESIDENT';
      case UserRole.guard:
        return 'GUARD';
      case UserRole.admin:
        return 'ADMIN';
    }
  }

  static UserRole fromString(String? value) {
    switch (value?.toUpperCase()) {
      case 'GUARD':
        return UserRole.guard;
      case 'ADMIN':
        return UserRole.admin;
      case 'RESIDENT':
      default:
        return UserRole.resident;
    }
  }
}

enum UserStatus {
  pending,
  approved,
  rejected;

  String get dbValue {
    switch (this) {
      case UserStatus.pending:
        return 'PENDING';
      case UserStatus.approved:
        return 'APPROVED';
      case UserStatus.rejected:
        return 'REJECTED';
    }
  }

  static UserStatus fromString(String? value) {
    switch (value?.toUpperCase()) {
      case 'APPROVED':
        return UserStatus.approved;
      case 'REJECTED':
        return UserStatus.rejected;
      case 'PENDING':
      default:
        return UserStatus.pending;
    }
  }
}
