import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../constants/app_constants.dart';

class ImageCompressor {
  static Future<File?> compressImageFile(File file) async {
    try {
      final tempDir = await getTemporaryDirectory();
      final targetPath = p.join(
        tempDir.path,
        'compressed_${DateTime.now().millisecondsSinceEpoch}.jpg',
      );

      final XFile? result = await FlutterImageCompress.compressAndGetFile(
        file.absolute.path,
        targetPath,
        minWidth: AppConstants.maxImageWidth,
        minHeight: AppConstants.maxImageHeight,
        quality: AppConstants.imageQuality,
        format: CompressFormat.jpeg,
      );

      if (result == null) return file;
      return File(result.path);
    } catch (_) {
      // Fallback to original file if compression fails on platform
      return file;
    }
  }

  static Future<Uint8List?> compressImageBytes(Uint8List bytes) async {
    try {
      return await FlutterImageCompress.compressWithList(
        bytes,
        minWidth: AppConstants.maxImageWidth,
        minHeight: AppConstants.maxImageHeight,
        quality: AppConstants.imageQuality,
        format: CompressFormat.jpeg,
      );
    } catch (_) {
      return bytes;
    }
  }
}
