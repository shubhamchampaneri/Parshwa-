import 'package:flutter/material.dart';
import '../../app/theme/app_colors.dart';

class StatusBadge extends StatelessWidget {
  final String status;

  const StatusBadge({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color fg;
    String label = status.replaceAll('_', ' ');

    switch (status.toUpperCase()) {
      case 'APPROVED':
      case 'INSIDE':
      case 'RESOLVED':
      case 'ACTIVE':
        bg = AppColors.successContainer;
        fg = AppColors.success;
        break;
      case 'PENDING':
      case 'SUBMITTED':
      case 'AT_GATE':
      case 'WAITING':
        bg = AppColors.warningContainer;
        fg = AppColors.warning;
        break;
      case 'REJECTED':
      case 'DENIED':
      case 'FALSE_ALARM':
        bg = AppColors.errorContainer;
        fg = AppColors.error;
        break;
      case 'EXITED':
      case 'USED':
      case 'EXPIRED':
      case 'CANCELLED':
      default:
        bg = Colors.grey.shade200;
        fg = Colors.grey.shade700;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: fg,
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}
