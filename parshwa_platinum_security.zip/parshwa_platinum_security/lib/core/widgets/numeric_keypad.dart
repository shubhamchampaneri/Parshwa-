import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NumericKeypad extends StatelessWidget {
  final void Function(String digit) onDigitPressed;
  final VoidCallback onDeletePressed;
  final VoidCallback? onBiometricPressed;
  final bool showBiometric;

  const NumericKeypad({
    super.key,
    required this.onDigitPressed,
    required this.onDeletePressed,
    this.onBiometricPressed,
    this.showBiometric = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildRow(context, ['1', '2', '3']),
        const SizedBox(height: 14),
        _buildRow(context, ['4', '5', '6']),
        const SizedBox(height: 14),
        _buildRow(context, ['7', '8', '9']),
        const SizedBox(height: 14),
        _buildBottomRow(context),
      ],
    );
  }

  Widget _buildRow(BuildContext context, List<String> digits) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: digits.map((d) => _buildKeyButton(context, d)).toList(),
    );
  }

  Widget _buildBottomRow(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // Left action (Biometrics or blank)
        SizedBox(
          width: 76,
          height: 76,
          child: showBiometric && onBiometricPressed != null
              ? IconButton(
                  icon: const Icon(Icons.fingerprint, size: 36),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    onBiometricPressed!();
                  },
                )
              : const SizedBox.shrink(),
        ),
        // Digit 0
        _buildKeyButton(context, '0'),
        // Right action (Backspace)
        SizedBox(
          width: 76,
          height: 76,
          child: IconButton(
            icon: const Icon(Icons.backspace_outlined, size: 28),
            onPressed: () {
              HapticFeedback.lightImpact();
              onDeletePressed();
            },
          ),
        ),
      ],
    );
  }

  Widget _buildKeyButton(BuildContext context, String digit) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: 76,
      height: 76,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isDark ? const Color(0xFF334155) : const Color(0xFFF1F5F9),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: () {
            HapticFeedback.selectionClick();
            onDigitPressed(digit);
          },
          child: Center(
            child: Text(
              digit,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white : const Color(0xFF0F172A),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
