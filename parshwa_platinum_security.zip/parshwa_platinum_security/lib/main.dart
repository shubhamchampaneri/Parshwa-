import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load environment variables (.env file)
  try {
    await dotenv.load(fileName: '.env');
  } catch (_) {
    // If .env is missing, fallback gracefully or use defaults
  }

  final supabaseUrl = dotenv.env['SUPABASE_URL'] ?? 'https://btltdikkqrgxyfwxtpav.supabase.co';
  final supabaseAnonKey = dotenv.env['SUPABASE_ANON_KEY'] ?? 'sb_publishable_gIurE-4JivNvRm5IzH5z4w_waxKBdb-';

  // Initialize Supabase Client
  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseAnonKey,
    authOptions: const FlutterAuthClientOptions(
      authFlowType: AuthFlowType.pkce,
    ),
  );

  runApp(
    const ProviderScope(
      child: ParshwaPlatinumApp(),
    ),
  );
}
