import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:parshwa_platinum_security/core/widgets/numeric_keypad.dart';

void main() {
  testWidgets('NumericKeypad responds to digit presses and backspace', (tester) async {
    String pressedDigit = '';
    bool deleted = false;
    bool biometricTapped = false;

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: NumericKeypad(
            showBiometric: true,
            onDigitPressed: (d) => pressedDigit = d,
            onDeletePressed: () => deleted = true,
            onBiometricPressed: () => biometricTapped = true,
          ),
        ),
      ),
    );

    // Tap digit '5'
    await tester.tap(find.text('5'));
    await tester.pump();
    expect(pressedDigit, '5');

    // Tap digit '8'
    await tester.tap(find.text('8'));
    await tester.pump();
    expect(pressedDigit, '8');

    // Tap backspace
    await tester.tap(find.byIcon(Icons.backspace_outlined));
    await tester.pump();
    expect(deleted, true);

    // Tap biometric
    await tester.tap(find.byIcon(Icons.fingerprint));
    await tester.pump();
    expect(biometricTapped, true);
  });
}
