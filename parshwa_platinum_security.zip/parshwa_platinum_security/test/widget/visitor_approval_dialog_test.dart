import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:parshwa_platinum_security/features/guard/domain/entities/visitor_log.dart';
import 'package:parshwa_platinum_security/features/resident/presentation/widgets/visitor_approval_dialog.dart';

void main() {
  testWidgets('VisitorApprovalDialog triggers onApprove and onDeny', (tester) async {
    bool approved = false;
    bool denied = false;

    final visitor = VisitorLog(
      id: 'log-123',
      visitorId: 'vis-123',
      visitorName: 'Ramesh Patel',
      visitorPhone: '9876543210',
      flatId: 'flat-402',
      flatNumber: '402',
      purpose: 'DELIVERY',
      vehicleNumber: 'GJ-01-AB-1234',
      status: 'PENDING',
      createdAt: DateTime.now(),
    );

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: VisitorApprovalDialog(
            visitor: visitor,
            onApprove: () => approved = true,
            onDeny: (_) => denied = true,
          ),
        ),
      ),
    );

    expect(find.text('Ramesh Patel'), findsOneWidget);
    expect(find.text('Flat 402 • Just Now'), findsOneWidget);
    expect(find.text('DELIVERY'), findsOneWidget);

    // Tap Approve
    await tester.tap(find.text('Approve'));
    await tester.pump();
    expect(approved, true);

    // Tap Deny Entry
    await tester.tap(find.text('Deny Entry'));
    await tester.pump();
    expect(denied, true);
  });
}
