import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:parshwa_platinum_security/features/guard/domain/entities/visitor_log.dart';
import 'package:parshwa_platinum_security/features/guard/domain/repositories/guard_repository.dart';
import 'package:parshwa_platinum_security/features/resident/domain/repositories/resident_repository.dart';

class MockGuardRepository extends Mock implements GuardRepository {}
class MockResidentRepository extends Mock implements ResidentRepository {}

void main() {
  late MockGuardRepository mockGuardRepo;
  late MockResidentRepository mockResidentRepo;

  setUp(() {
    mockGuardRepo = MockGuardRepository();
    mockResidentRepo = MockResidentRepository();
  });

  group('End-to-End Visitor Approval Flow Integration', () {
    test('Guard logs walk-in -> Resident receives pending -> Resident approves -> Status is APPROVED', () async {
      const flatId = 'flat-302-uuid';
      const logId = 'log-999-uuid';

      final pendingLog = VisitorLog(
        id: logId,
        visitorId: 'vis-111',
        visitorName: 'Mahesh Shah',
        visitorPhone: '9825012345',
        flatId: flatId,
        flatNumber: '302',
        purpose: 'GUEST',
        status: 'PENDING',
        createdAt: DateTime.now(),
      );

      // 1. Guard registers visitor
      when(() => mockGuardRepo.logWalkInVisitor(
            visitorName: 'Mahesh Shah',
            visitorPhone: '9825012345',
            flatId: flatId,
            purpose: 'GUEST',
          )).thenAnswer((_) async => pendingLog);

      final loggedVisitor = await mockGuardRepo.logWalkInVisitor(
        visitorName: 'Mahesh Shah',
        visitorPhone: '9825012345',
        flatId: flatId,
        purpose: 'GUEST',
      );

      expect(loggedVisitor.status, 'PENDING');
      expect(loggedVisitor.flatNumber, '302');

      // 2. Resident streams pending approvals
      when(() => mockResidentRepo.watchPendingApprovals(flatId))
          .thenAnswer((_) => Stream.value([loggedVisitor]));

      final pendingStream = mockResidentRepo.watchPendingApprovals(flatId);
      final receivedAlerts = await pendingStream.first;
      expect(receivedAlerts.length, 1);
      expect(receivedAlerts.first.visitorName, 'Mahesh Shah');

      // 3. Resident taps Approve
      when(() => mockResidentRepo.respondToVisitorRequest(
            logId: logId,
            approve: true,
          )).thenAnswer((_) async => {'success': true, 'status': 'APPROVED'});

      final responseResult = await mockResidentRepo.respondToVisitorRequest(
        logId: logId,
        approve: true,
      );

      expect(responseResult['success'], true);
      expect(responseResult['status'], 'APPROVED');

      // 4. Verify atomic execution
      verify(() => mockResidentRepo.respondToVisitorRequest(
            logId: logId,
            approve: true,
          )).called(1);
    });
  });
}
