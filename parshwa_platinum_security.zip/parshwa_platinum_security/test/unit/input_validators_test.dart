import 'package:flutter_test/flutter_test.dart';
import 'package:parshwa_platinum_security/core/utils/input_validators.dart';

void main() {
  group('InputValidators Tests', () {
    test('validateEmail validates RFC formats', () {
      expect(InputValidators.validateEmail('test@parshwaplatinum.com'), isNull);
      expect(InputValidators.validateEmail('invalid-email'), isNotNull);
      expect(InputValidators.validateEmail(''), isNotNull);
      expect(InputValidators.validateEmail(null), isNotNull);
    });

    test('validatePassword requires min 8 chars, 1 number, 1 uppercase', () {
      expect(InputValidators.validatePassword('Password123'), isNull);
      expect(InputValidators.validatePassword('short'), isNotNull);
      expect(InputValidators.validatePassword('alllowercase123'), isNotNull);
      expect(InputValidators.validatePassword('ALLUPPERCASE123'), isNull);
      expect(InputValidators.validatePassword('NoNumbersHere'), isNotNull);
    });

    test('validatePhone requires 10-digit mobile number', () {
      expect(InputValidators.validatePhone('9876543210'), isNull);
      expect(InputValidators.validatePhone('+91 9876543210'), isNull);
      expect(InputValidators.validatePhone('12345'), isNotNull);
      expect(InputValidators.validatePhone('abcdefghij'), isNotNull);
    });

    test('validatePin blocks weak and trivial PINs', () {
      expect(InputValidators.validatePin('5829'), isNull);
      expect(InputValidators.validatePin('1234'), isNotNull);
      expect(InputValidators.validatePin('0000'), isNotNull);
      expect(InputValidators.validatePin('1111'), isNotNull);
      expect(InputValidators.validatePin('12'), isNotNull);
    });

    test('validateInviteCode requires valid length', () {
      expect(InputValidators.validateInviteCode('PPGUARD2026'), isNull);
      expect(InputValidators.validateInviteCode('123'), isNotNull);
      expect(InputValidators.validateInviteCode(''), isNotNull);
    });
  });
}
