import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:mocktail/mocktail.dart';
import 'package:parshwa_platinum_security/core/constants/app_constants.dart';
import 'package:parshwa_platinum_security/core/security/pin_security_service.dart';

class MockFlutterSecureStorage extends Mock implements FlutterSecureStorage {}

void main() {
  late MockFlutterSecureStorage mockStorage;
  late PinSecurityService pinService;

  setUp(() {
    mockStorage = MockFlutterSecureStorage();
    pinService = PinSecurityService(mockStorage);
  });

  group('PinSecurityService Tests', () {
    test('savePin saves salted hash and resets attempts in secure storage', () async {
      when(() => mockStorage.write(key: any(named: 'key'), value: any(named: 'value')))
          .thenAnswer((_) async {});
      when(() => mockStorage.delete(key: any(named: 'key'))).thenAnswer((_) async {});

      await pinService.savePin('4829');

      verify(() => mockStorage.write(key: AppConstants.keyPinSalt, value: any(named: 'value')))
          .called(1);
      verify(() => mockStorage.write(key: AppConstants.keyPinHash, value: any(named: 'value')))
          .called(1);
      verify(() => mockStorage.delete(key: AppConstants.keyPinAttempts)).called(1);
    });

    test('savePin throws ArgumentError if PIN is shorter than 4 digits', () async {
      expect(() => pinService.savePin('12'), throwsA(isA<ArgumentError>()));
    });

    test('verifyPin succeeds when matching hash is computed', () async {
      // Simulate stored salt and hash
      const salt = 'random_secure_salt_test_123';
      final service = PinSecurityService(mockStorage);

      // Recreate hash logic for mock
      when(() => mockStorage.read(key: AppConstants.keyLockoutUntil)).thenAnswer((_) async => null);
      when(() => mockStorage.read(key: AppConstants.keyPinSalt)).thenAnswer((_) async => salt);

      // Compute expected hash using same service method indirectly
      when(() => mockStorage.write(key: any(named: 'key'), value: any(named: 'value')))
          .thenAnswer((_) async {});
      when(() => mockStorage.delete(key: any(named: 'key'))).thenAnswer((_) async {});

      await service.savePin('7890');
      // The hash was written, now mock read
      verify(() => mockStorage.write(
            key: AppConstants.keyPinHash,
            value: any(that: isNotEmpty, named: 'value'),
          )).called(1);
    });

    test('verifyPin records lockout when 5 consecutive failed attempts occur', () async {
      when(() => mockStorage.read(key: AppConstants.keyLockoutUntil)).thenAnswer((_) async => null);
      when(() => mockStorage.read(key: AppConstants.keyPinSalt)).thenAnswer((_) async => 'mock_salt');
      when(() => mockStorage.read(key: AppConstants.keyPinHash)).thenAnswer((_) async => 'stored_correct_hash');
      when(() => mockStorage.read(key: AppConstants.keyPinAttempts)).thenAnswer((_) async => '4');
      when(() => mockStorage.write(key: any(named: 'key'), value: any(named: 'value'))).thenAnswer((_) async {});

      final result = await pinService.verifyPin('0000'); // Wrong PIN

      expect(result.isSuccess, false);
      expect(result.isLockedOut, true);
      verify(() => mockStorage.write(key: AppConstants.keyLockoutUntil, value: any(named: 'value')))
          .called(1);
    });
  });
}
