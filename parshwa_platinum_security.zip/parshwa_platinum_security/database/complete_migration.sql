-- ==============================================================================
-- PARSHWA PLATINUM SECURITY - MASTER SUPABASE SQL MIGRATION
-- Run this in Supabase: Dashboard -> SQL Editor -> New Query -> Paste -> Run
-- Apartment: Parshwa Platinum (7 Floors, 28 Flats: 101-104 ... 701-704)
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. DROP EXISTING OBJECTS (Clean Install)
DROP TRIGGER IF EXISTS trg_check_max_residents ON profiles;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

DROP TABLE IF EXISTS device_tokens CASCADE;
DROP TABLE IF EXISTS guard_invite_codes CASCADE;
DROP TABLE IF EXISTS staff_entries CASCADE;
DROP TABLE IF EXISTS delivery_logs CASCADE;
DROP TABLE IF EXISTS sos_alerts CASCADE;
DROP TABLE IF EXISTS complaints CASCADE;
DROP TABLE IF EXISTS notices CASCADE;
DROP TABLE IF EXISTS pre_approvals CASCADE;
DROP TABLE IF EXISTS visitor_logs CASCADE;
DROP TABLE IF EXISTS visitors CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;
DROP TABLE IF EXISTS flats CASCADE;

-- 3. TABLES DEFINITION
CREATE TABLE flats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    floor_number INT NOT NULL CHECK (floor_number BETWEEN 1 AND 7),
    unit_number INT NOT NULL CHECK (unit_number BETWEEN 1 AND 4),
    flat_number TEXT NOT NULL UNIQUE,
    delivery_preference TEXT NOT NULL DEFAULT 'ASK_FIRST' CHECK (delivery_preference IN ('LEAVE_AT_GATE', 'ASK_FIRST')),
    delivery_instructions TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_flats_number ON flats(flat_number);

CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'RESIDENT' CHECK (role IN ('RESIDENT', 'GUARD', 'ADMIN')),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
    flat_id UUID REFERENCES flats(id) ON DELETE SET NULL,
    occupancy_type TEXT DEFAULT 'OWNER' CHECK (occupancy_type IN ('OWNER', 'TENANT', 'FAMILY', 'GUARD', 'ADMIN')),
    avatar_url TEXT,
    rejection_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_profiles_status ON profiles(status);
CREATE INDEX idx_profiles_flat_id ON profiles(flat_id);

CREATE TABLE visitors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    photo_url TEXT,
    vehicle_number TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_visitors_phone ON visitors(phone_number);

CREATE TABLE visitor_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visitor_id UUID NOT NULL REFERENCES visitors(id) ON DELETE CASCADE,
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    guard_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    resident_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    purpose TEXT NOT NULL DEFAULT 'GUEST' CHECK (purpose IN ('GUEST', 'DELIVERY', 'CAB', 'SERVICE', 'OTHER')),
    vehicle_number TEXT,
    number_of_visitors INT NOT NULL DEFAULT 1 CHECK (number_of_visitors >= 1),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'INSIDE', 'EXITED')),
    entry_time TIMESTAMPTZ,
    exit_time TIMESTAMPTZ,
    rejection_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_visitor_logs_flat_id ON visitor_logs(flat_id);
CREATE INDEX idx_visitor_logs_status ON visitor_logs(status);
CREATE INDEX idx_visitor_logs_created_at ON visitor_logs(created_at DESC);

CREATE TABLE pre_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    visitor_name TEXT NOT NULL,
    visitor_phone TEXT,
    purpose TEXT NOT NULL DEFAULT 'GUEST' CHECK (purpose IN ('GUEST', 'DELIVERY', 'CAB', 'SERVICE', 'OTHER')),
    vehicle_number TEXT,
    expected_arrival TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    qr_code_data TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'USED', 'EXPIRED', 'CANCELLED')),
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pre_approvals_otp ON pre_approvals(otp_code);
CREATE INDEX idx_pre_approvals_flat ON pre_approvals(flat_id);
CREATE INDEX idx_pre_approvals_status ON pre_approvals(status);

CREATE TABLE notices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'NORMAL' CHECK (priority IN ('NORMAL', 'IMPORTANT', 'URGENT')),
    target_audience TEXT NOT NULL DEFAULT 'ALL' CHECK (target_audience IN ('ALL', 'RESIDENTS', 'GUARDS')),
    created_by UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    attachment_url TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notices_is_active ON notices(is_active);
CREATE INDEX idx_notices_created_at ON notices(created_at DESC);

CREATE TABLE complaints (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    category TEXT NOT NULL CHECK (category IN ('WATER', 'LIFT', 'PARKING', 'CLEANING', 'ELECTRICAL', 'SECURITY', 'OTHER')),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    photo_url TEXT,
    status TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN ('SUBMITTED', 'IN_PROGRESS', 'RESOLVED')),
    admin_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_complaints_flat_id ON complaints(flat_id);
CREATE INDEX idx_complaints_status ON complaints(status);

CREATE TABLE sos_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    emergency_type TEXT NOT NULL DEFAULT 'GENERAL' CHECK (emergency_type IN ('MEDICAL', 'FIRE', 'THREAT', 'LIFT', 'GENERAL')),
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'ACKNOWLEDGED', 'RESOLVED', 'FALSE_ALARM')),
    acknowledged_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    acknowledged_at TIMESTAMPTZ,
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sos_alerts_status ON sos_alerts(status);
CREATE INDEX idx_sos_alerts_created_at ON sos_alerts(created_at DESC);

CREATE TABLE delivery_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    guard_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    company_name TEXT NOT NULL CHECK (company_name IN ('AMAZON', 'FLIPKART', 'ZOMATO', 'SWIGGY', 'BLINKIT', 'ZEPTO', 'COURIER', 'OTHER')),
    package_count INT NOT NULL DEFAULT 1 CHECK (package_count >= 1),
    status TEXT NOT NULL DEFAULT 'AT_GATE' CHECK (status IN ('AT_GATE', 'COLLECTED', 'DELIVERED_TO_FLAT')),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_delivery_logs_flat_id ON delivery_logs(flat_id);

CREATE TABLE staff_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    role_type TEXT NOT NULL CHECK (role_type IN ('MAID', 'DRIVER', 'COOK', 'CLEANER', 'TECHNICIAN', 'OTHER')),
    flat_id UUID REFERENCES flats(id) ON DELETE SET NULL,
    guard_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    entry_time TIMESTAMPTZ NOT NULL DEFAULT now(),
    exit_time TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE device_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    token TEXT NOT NULL UNIQUE,
    platform TEXT NOT NULL CHECK (platform IN ('android', 'ios')),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_device_tokens_user_id ON device_tokens(user_id);

CREATE TABLE guard_invite_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT NOT NULL UNIQUE,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    rotated_at TIMESTAMPTZ
);

-- 4. SECURITY FUNCTIONS (SECURITY DEFINER)
CREATE OR REPLACE FUNCTION auth_user_role()
RETURNS TEXT AS $$
    SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION auth_user_status()
RETURNS TEXT AS $$
    SELECT status FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION auth_user_flat_id()
RETURNS UUID AS $$
    SELECT flat_id FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- 5. ENABLE ROW LEVEL SECURITY
ALTER TABLE flats ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitor_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE pre_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;
ALTER TABLE sos_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE device_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE guard_invite_codes ENABLE ROW LEVEL SECURITY;

-- 6. RLS POLICIES
CREATE POLICY "flats_select_all" ON flats FOR SELECT TO authenticated, anon USING (true);
CREATE POLICY "flats_update_resident" ON flats FOR UPDATE TO authenticated
    USING (id = auth_user_flat_id() AND auth_user_role() = 'RESIDENT' AND auth_user_status() = 'APPROVED')
    WITH CHECK (id = auth_user_flat_id());
CREATE POLICY "flats_update_admin" ON flats FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "profiles_select_self" ON profiles FOR SELECT TO authenticated USING (id = auth.uid());
CREATE POLICY "profiles_select_flatmates" ON profiles FOR SELECT TO authenticated
    USING (auth_user_role() = 'RESIDENT' AND auth_user_status() = 'APPROVED' AND flat_id = auth_user_flat_id());
CREATE POLICY "profiles_select_guards" ON profiles FOR SELECT TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "profiles_select_admin" ON profiles FOR SELECT TO authenticated USING (auth_user_role() = 'ADMIN');
CREATE POLICY "profiles_update_self" ON profiles FOR UPDATE TO authenticated
    USING (id = auth.uid())
    WITH CHECK (id = auth.uid() AND role = (SELECT role FROM profiles WHERE id = auth.uid()) AND status = (SELECT status FROM profiles WHERE id = auth.uid()));
CREATE POLICY "profiles_update_admin" ON profiles FOR UPDATE TO authenticated USING (auth_user_role() = 'ADMIN');
CREATE POLICY "profiles_insert_self" ON profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());

CREATE POLICY "visitors_select_guard_admin" ON visitors FOR SELECT TO authenticated USING (auth_user_role() IN ('GUARD', 'ADMIN') AND auth_user_status() = 'APPROVED');
CREATE POLICY "visitors_insert_guard_admin" ON visitors FOR INSERT TO authenticated WITH CHECK (auth_user_role() IN ('GUARD', 'ADMIN') AND auth_user_status() = 'APPROVED');
CREATE POLICY "visitors_update_guard_admin" ON visitors FOR UPDATE TO authenticated USING (auth_user_role() IN ('GUARD', 'ADMIN') AND auth_user_status() = 'APPROVED');
CREATE POLICY "visitors_select_resident" ON visitors FOR SELECT TO authenticated USING (auth_user_role() = 'RESIDENT' AND id IN (SELECT visitor_id FROM visitor_logs WHERE flat_id = auth_user_flat_id()));

CREATE POLICY "visitor_logs_guard_select" ON visitor_logs FOR SELECT TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "visitor_logs_guard_insert" ON visitor_logs FOR INSERT TO authenticated WITH CHECK (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "visitor_logs_guard_update" ON visitor_logs FOR UPDATE TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "visitor_logs_resident_select" ON visitor_logs FOR SELECT TO authenticated USING (auth_user_role() = 'RESIDENT' AND auth_user_status() = 'APPROVED' AND flat_id = auth_user_flat_id());
CREATE POLICY "visitor_logs_resident_update" ON visitor_logs FOR UPDATE TO authenticated USING (auth_user_role() = 'RESIDENT' AND auth_user_status() = 'APPROVED' AND flat_id = auth_user_flat_id()) WITH CHECK (flat_id = auth_user_flat_id());
CREATE POLICY "visitor_logs_admin_all" ON visitor_logs FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "pre_approvals_resident_select" ON pre_approvals FOR SELECT TO authenticated USING (auth_user_role() = 'RESIDENT' AND auth_user_status() = 'APPROVED' AND flat_id = auth_user_flat_id());
CREATE POLICY "pre_approvals_resident_insert" ON pre_approvals FOR INSERT TO authenticated WITH CHECK (auth_user_role() = 'RESIDENT' AND auth_user_status() = 'APPROVED' AND flat_id = auth_user_flat_id() AND resident_id = auth.uid());
CREATE POLICY "pre_approvals_resident_update" ON pre_approvals FOR UPDATE TO authenticated USING (auth_user_role() = 'RESIDENT' AND flat_id = auth_user_flat_id());
CREATE POLICY "pre_approvals_guard_select" ON pre_approvals FOR SELECT TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "pre_approvals_guard_update" ON pre_approvals FOR UPDATE TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "pre_approvals_admin_all" ON pre_approvals FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "notices_select" ON notices FOR SELECT TO authenticated USING (is_active = true AND (target_audience = 'ALL' OR (target_audience = 'RESIDENTS' AND auth_user_role() = 'RESIDENT') OR (target_audience = 'GUARDS' AND auth_user_role() = 'GUARD') OR auth_user_role() = 'ADMIN'));
CREATE POLICY "notices_admin_all" ON notices FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "complaints_resident_select" ON complaints FOR SELECT TO authenticated USING (auth_user_role() = 'RESIDENT' AND flat_id = auth_user_flat_id());
CREATE POLICY "complaints_resident_insert" ON complaints FOR INSERT TO authenticated WITH CHECK (auth_user_role() = 'RESIDENT' AND flat_id = auth_user_flat_id() AND resident_id = auth.uid());
CREATE POLICY "complaints_admin_all" ON complaints FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "sos_resident_insert" ON sos_alerts FOR INSERT TO authenticated WITH CHECK (auth_user_role() = 'RESIDENT' AND flat_id = auth_user_flat_id() AND resident_id = auth.uid());
CREATE POLICY "sos_resident_select" ON sos_alerts FOR SELECT TO authenticated USING (auth_user_role() = 'RESIDENT' AND flat_id = auth_user_flat_id());
CREATE POLICY "sos_guard_select" ON sos_alerts FOR SELECT TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "sos_guard_update" ON sos_alerts FOR UPDATE TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "sos_admin_all" ON sos_alerts FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "delivery_resident_select" ON delivery_logs FOR SELECT TO authenticated USING (auth_user_role() = 'RESIDENT' AND flat_id = auth_user_flat_id());
CREATE POLICY "delivery_guard_all" ON delivery_logs FOR ALL TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "delivery_admin_all" ON delivery_logs FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "staff_guard_all" ON staff_entries FOR ALL TO authenticated USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');
CREATE POLICY "staff_resident_select" ON staff_entries FOR SELECT TO authenticated USING (auth_user_role() = 'RESIDENT' AND (flat_id = auth_user_flat_id() OR flat_id IS NULL));
CREATE POLICY "staff_admin_all" ON staff_entries FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

CREATE POLICY "device_tokens_self" ON device_tokens FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "guard_codes_admin_all" ON guard_invite_codes FOR ALL TO authenticated USING (auth_user_role() = 'ADMIN');

-- 7. TRIGGERS AND FUNCTIONS
CREATE OR REPLACE FUNCTION check_max_residents_per_flat()
RETURNS TRIGGER AS $$
DECLARE
    v_resident_count INT;
    v_flat_number TEXT;
BEGIN
    IF NEW.role = 'RESIDENT' AND NEW.flat_id IS NOT NULL AND NEW.status != 'REJECTED' THEN
        SELECT COUNT(*) INTO v_resident_count
        FROM profiles
        WHERE flat_id = NEW.flat_id AND role = 'RESIDENT' AND status != 'REJECTED' AND id != NEW.id;

        IF v_resident_count >= 4 THEN
            SELECT flat_number INTO v_flat_number FROM flats WHERE id = NEW.flat_id;
            RAISE EXCEPTION 'Flat % has reached the maximum capacity of 4 registered residents.', v_flat_number;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trg_check_max_residents
    BEFORE INSERT OR UPDATE OF flat_id, role, status ON profiles
    FOR EACH ROW EXECUTE FUNCTION check_max_residents_per_flat();

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    v_role TEXT;
    v_flat_id UUID;
    v_phone TEXT;
    v_full_name TEXT;
    v_invite_code TEXT;
    v_is_valid_code BOOLEAN;
BEGIN
    v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'RESIDENT');
    v_phone := COALESCE(NEW.raw_user_meta_data->>'phone_number', '');
    v_full_name := COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1));
    v_flat_id := (NEW.raw_user_meta_data->>'flat_id')::UUID;
    v_invite_code := NEW.raw_user_meta_data->>'invite_code';

    IF v_role = 'GUARD' THEN
        SELECT EXISTS (
            SELECT 1 FROM guard_invite_codes WHERE code = UPPER(TRIM(v_invite_code)) AND is_active = true
        ) INTO v_is_valid_code;
        IF NOT v_is_valid_code THEN
            RAISE EXCEPTION 'Invalid or expired security guard invite code.';
        END IF;
    END IF;

    INSERT INTO profiles (id, email, full_name, phone_number, role, status, flat_id, occupancy_type)
    VALUES (
        NEW.id, NEW.email, v_full_name, v_phone, v_role, 'PENDING',
        CASE WHEN v_role = 'RESIDENT' THEN v_flat_id ELSE NULL END,
        CASE WHEN v_role = 'RESIDENT' THEN 'OWNER' ELSE 'GUARD' END
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION handle_new_user();

CREATE OR REPLACE FUNCTION verify_guard_invite_code(p_code TEXT)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (SELECT 1 FROM guard_invite_codes WHERE code = UPPER(TRIM(p_code)) AND is_active = true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION rotate_guard_invite_code(p_new_code TEXT)
RETURNS TEXT AS $$
DECLARE
    v_code TEXT;
BEGIN
    IF auth_user_role() != 'ADMIN' THEN
        RAISE EXCEPTION 'Only society administrators can rotate guard invite codes.';
    END IF;
    v_code := UPPER(TRIM(p_new_code));
    UPDATE guard_invite_codes SET is_active = false, rotated_at = now() WHERE is_active = true;
    INSERT INTO guard_invite_codes (code, is_active, created_by) VALUES (v_code, true, auth.uid());
    RETURN v_code;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION respond_to_visitor_request(
    p_log_id UUID,
    p_action TEXT,
    p_rejection_reason TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_log visitor_logs%ROWTYPE;
    v_resident_flat UUID;
    v_updated_rows INT;
BEGIN
    SELECT flat_id INTO v_resident_flat FROM profiles WHERE id = auth.uid();
    SELECT * INTO v_log FROM visitor_logs WHERE id = p_log_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Visitor request not found');
    END IF;
    IF v_log.flat_id != v_resident_flat AND auth_user_role() != 'ADMIN' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
    END IF;

    IF p_action = 'APPROVE' THEN
        UPDATE visitor_logs SET status = 'APPROVED', resident_id = auth.uid(), updated_at = now()
        WHERE id = p_log_id AND status = 'PENDING';
    ELSIF p_action = 'REJECT' THEN
        UPDATE visitor_logs SET status = 'REJECTED', resident_id = auth.uid(), rejection_reason = p_rejection_reason, updated_at = now()
        WHERE id = p_log_id AND status = 'PENDING';
    ELSE
        RETURN jsonb_build_object('success', false, 'message', 'Invalid action');
    END IF;

    GET DIAGNOSTICS v_updated_rows = ROW_COUNT;
    IF v_updated_rows = 0 THEN
        SELECT * INTO v_log FROM visitor_logs WHERE id = p_log_id;
        RETURN jsonb_build_object('success', false, 'conflict', true, 'message', 'Request already processed by another resident', 'current_status', v_log.status);
    END IF;

    RETURN jsonb_build_object('success', true, 'status', CASE WHEN p_action = 'APPROVE' THEN 'APPROVED' ELSE 'REJECTED' END);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION verify_and_checkin_preapproval(p_code TEXT)
RETURNS JSONB AS $$
DECLARE
    v_pre pre_approvals%ROWTYPE;
    v_visitor_id UUID;
    v_log_id UUID;
BEGIN
    IF auth_user_role() NOT IN ('GUARD', 'ADMIN') THEN
        RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
    END IF;

    SELECT * INTO v_pre FROM pre_approvals 
    WHERE (otp_code = TRIM(p_code) OR qr_code_data = TRIM(p_code)) AND status = 'ACTIVE' LIMIT 1;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Invalid or inactive visitor pass');
    END IF;

    IF v_pre.expires_at < now() THEN
        UPDATE pre_approvals SET status = 'EXPIRED' WHERE id = v_pre.id;
        RETURN jsonb_build_object('success', false, 'message', 'Visitor pass has expired');
    END IF;

    UPDATE pre_approvals SET status = 'USED', used_at = now() WHERE id = v_pre.id;

    INSERT INTO visitors (full_name, phone_number, vehicle_number)
    VALUES (v_pre.visitor_name, COALESCE(v_pre.visitor_phone, 'N/A'), v_pre.vehicle_number)
    RETURNING id INTO v_visitor_id;

    INSERT INTO visitor_logs (visitor_id, flat_id, guard_id, resident_id, purpose, vehicle_number, status, entry_time)
    VALUES (v_visitor_id, v_pre.flat_id, auth.uid(), v_pre.resident_id, v_pre.purpose, v_pre.vehicle_number, 'INSIDE', now())
    RETURNING id INTO v_log_id;

    RETURN jsonb_build_object('success', true, 'visitor_name', v_pre.visitor_name, 'flat_id', v_pre.flat_id, 'log_id', v_log_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION prune_old_visitor_photos()
RETURNS INT AS $$
DECLARE
    v_deleted_count INT := 0;
BEGIN
    UPDATE visitors SET photo_url = NULL WHERE photo_url IS NOT NULL AND created_at < (now() - INTERVAL '90 days');
    GET DIAGNOSTICS v_deleted_count = ROW_COUNT;
    RETURN v_deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 8. SEED DATA (28 FLATS & GUARD INVITE CODE)
DO $$
DECLARE
    v_floor INT;
    v_unit INT;
    v_flat_num TEXT;
BEGIN
    FOR v_floor IN 1..7 LOOP
        FOR v_unit IN 1..4 LOOP
            v_flat_num := (v_floor * 100 + v_unit)::TEXT;
            IF NOT EXISTS (SELECT 1 FROM flats WHERE flat_number = v_flat_num) THEN
                INSERT INTO flats (floor_number, unit_number, flat_number, delivery_preference)
                VALUES (v_floor, v_unit, v_flat_num, 'ASK_FIRST');
            END IF;
        END LOOP;
    END LOOP;
END $$;

INSERT INTO guard_invite_codes (code, is_active)
VALUES ('PPGUARD2026', true)
ON CONFLICT (code) DO NOTHING;

-- 9. SUPABASE REALTIME REPLICATION SETUP
BEGIN;
  ALTER PUBLICATION supabase_realtime ADD TABLE visitor_logs;
  ALTER PUBLICATION supabase_realtime ADD TABLE sos_alerts;
  ALTER PUBLICATION supabase_realtime ADD TABLE notices;
  ALTER PUBLICATION supabase_realtime ADD TABLE delivery_logs;
COMMIT;
