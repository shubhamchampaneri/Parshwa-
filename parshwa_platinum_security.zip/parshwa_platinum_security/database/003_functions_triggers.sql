-- ==============================================================================
-- PARSHWA PLATINUM SECURITY - 003 FUNCTIONS, TRIGGERS & PROCEDURES
-- Business validations, concurrency guards, photo pruning, and Realtime publications
-- ==============================================================================

-- 1. TRIGGER: ENFORCE MAXIMUM 4 RESIDENTS PER FLAT
CREATE OR REPLACE FUNCTION check_max_residents_per_flat()
RETURNS TRIGGER AS $$
DECLARE
    v_resident_count INT;
    v_flat_number TEXT;
BEGIN
    -- Only check if user is a resident assigned to a flat
    IF NEW.role = 'RESIDENT' AND NEW.flat_id IS NOT NULL AND NEW.status != 'REJECTED' THEN
        SELECT COUNT(*)
        INTO v_resident_count
        FROM profiles
        WHERE flat_id = NEW.flat_id 
          AND role = 'RESIDENT' 
          AND status != 'REJECTED'
          AND id != NEW.id;

        IF v_resident_count >= 4 THEN
            SELECT flat_number INTO v_flat_number FROM flats WHERE id = NEW.flat_id;
            RAISE EXCEPTION 'Flat % has reached the maximum capacity of 4 registered residents.', v_flat_number;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_check_max_residents ON profiles;
CREATE TRIGGER trg_check_max_residents
    BEFORE INSERT OR UPDATE OF flat_id, role, status
    ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION check_max_residents_per_flat();

-- ==============================================================================
-- 2. TRIGGER: HANDLE NEW USER SIGNUP FROM AUTH.USERS
-- Automatically creates a pending profile when user registers via email or Google OAuth
-- ==============================================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    v_role TEXT;
    v_flat_id UUID;
    v_phone TEXT;
    v_full_name TEXT;
    v_invite_code TEXT;
    v_is_valid_code BOOLEAN;
BEGIN
    -- Extract metadata passed from client during signUp()
    v_role := COALESCE(NEW.raw_user_meta_data->>'role', 'RESIDENT');
    v_phone := COALESCE(NEW.raw_user_meta_data->>'phone_number', '');
    v_full_name := COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1));
    v_flat_id := (NEW.raw_user_meta_data->>'flat_id')::UUID;
    v_invite_code := NEW.raw_user_meta_data->>'invite_code';

    -- Guard role requires valid active invite code
    IF v_role = 'GUARD' THEN
        SELECT EXISTS (
            SELECT 1 FROM guard_invite_codes 
            WHERE code = UPPER(TRIM(v_invite_code)) AND is_active = true
        ) INTO v_is_valid_code;

        IF NOT v_is_valid_code THEN
            RAISE EXCEPTION 'Invalid or expired security guard invite code.';
        END IF;
    END IF;

    -- Create profile with PENDING status (requires admin committee approval)
    INSERT INTO profiles (
        id,
        email,
        full_name,
        phone_number,
        role,
        status,
        flat_id,
        occupancy_type
    ) VALUES (
        NEW.id,
        NEW.email,
        v_full_name,
        v_phone,
        v_role,
        'PENDING',
        CASE WHEN v_role = 'RESIDENT' THEN v_flat_id ELSE NULL END,
        CASE WHEN v_role = 'RESIDENT' THEN 'OWNER' ELSE 'GUARD' END
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION handle_new_user();

-- ==============================================================================
-- 3. RPC: VERIFY GUARD INVITE CODE (Called before signup if pre-checking)
-- ==============================================================================
CREATE OR REPLACE FUNCTION verify_guard_invite_code(p_code TEXT)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM guard_invite_codes
        WHERE code = UPPER(TRIM(p_code)) AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- 4. RPC: ROTATE GUARD INVITE CODE (Admin only)
-- ==============================================================================
CREATE OR REPLACE FUNCTION rotate_guard_invite_code(p_new_code TEXT)
RETURNS TEXT AS $$
DECLARE
    v_code TEXT;
BEGIN
    IF auth_user_role() != 'ADMIN' THEN
        RAISE EXCEPTION 'Only society administrators can rotate guard invite codes.';
    END IF;

    v_code := UPPER(TRIM(p_new_code));
    
    -- Deactivate current active codes
    UPDATE guard_invite_codes 
    SET is_active = false, rotated_at = now() 
    WHERE is_active = true;

    -- Insert new code
    INSERT INTO guard_invite_codes (code, is_active, created_by)
    VALUES (v_code, true, auth.uid());

    RETURN v_code;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- 5. RPC: CONCURRENCY-SAFE ATOMIC VISITOR APPROVAL
-- Solves race condition: Two residents of the same flat tapping Approve/Deny
-- ==============================================================================
CREATE OR REPLACE FUNCTION respond_to_visitor_request(
    p_log_id UUID,
    p_action TEXT, -- 'APPROVE' or 'REJECT'
    p_rejection_reason TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_log visitor_logs%ROWTYPE;
    v_resident_flat UUID;
    v_updated_rows INT;
BEGIN
    SELECT flat_id INTO v_resident_flat FROM profiles WHERE id = auth.uid();

    -- Ensure the user is an approved resident of this flat or an admin
    SELECT * INTO v_log FROM visitor_logs WHERE id = p_log_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Visitor request not found');
    END IF;

    IF v_log.flat_id != v_resident_flat AND auth_user_role() != 'ADMIN' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Unauthorized: You can only respond for your flat');
    END IF;

    -- Atomic update: only updates if still PENDING
    IF p_action = 'APPROVE' THEN
        UPDATE visitor_logs
        SET status = 'APPROVED',
            resident_id = auth.uid(),
            updated_at = now()
        WHERE id = p_log_id AND status = 'PENDING';
    ELSIF p_action = 'REJECT' THEN
        UPDATE visitor_logs
        SET status = 'REJECTED',
            resident_id = auth.uid(),
            rejection_reason = p_rejection_reason,
            updated_at = now()
        WHERE id = p_log_id AND status = 'PENDING';
    ELSE
        RETURN jsonb_build_object('success', false, 'message', 'Invalid action');
    END IF;

    GET DIAGNOSTICS v_updated_rows = ROW_COUNT;

    IF v_updated_rows = 0 THEN
        -- Another resident already acted on this request!
        SELECT * INTO v_log FROM visitor_logs WHERE id = p_log_id;
        RETURN jsonb_build_object(
            'success', false, 
            'conflict', true,
            'message', 'Request already processed by another resident',
            'current_status', v_log.status
        );
    END IF;

    RETURN jsonb_build_object('success', true, 'status', CASE WHEN p_action = 'APPROVE' THEN 'APPROVED' ELSE 'REJECTED' END);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- 6. RPC: FAST-TRACK PRE-APPROVAL VERIFICATION FOR GUARD
-- Validates 6-digit OTP or QR code string, ensures not expired, marks INSIDE
-- ==============================================================================
CREATE OR REPLACE FUNCTION verify_and_checkin_preapproval(
    p_code TEXT -- Can be OTP (6 digits) or QR payload
)
RETURNS JSONB AS $$
DECLARE
    v_pre pre_approvals%ROWTYPE;
    v_visitor_id UUID;
    v_log_id UUID;
BEGIN
    IF auth_user_role() NOT IN ('GUARD', 'ADMIN') THEN
        RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
    END IF;

    -- Lookup active pre-approval by OTP or QR code
    SELECT * INTO v_pre 
    FROM pre_approvals 
    WHERE (otp_code = TRIM(p_code) OR qr_code_data = TRIM(p_code))
      AND status = 'ACTIVE'
    LIMIT 1;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Invalid or inactive visitor pass');
    END IF;

    IF v_pre.expires_at < now() THEN
        UPDATE pre_approvals SET status = 'EXPIRED' WHERE id = v_pre.id;
        RETURN jsonb_build_object('success', false, 'message', 'Visitor pass has expired');
    END IF;

    -- Mark pass USED
    UPDATE pre_approvals 
    SET status = 'USED', used_at = now() 
    WHERE id = v_pre.id;

    -- Create or link visitor
    INSERT INTO visitors (full_name, phone_number, vehicle_number)
    VALUES (v_pre.visitor_name, COALESCE(v_pre.visitor_phone, 'N/A'), v_pre.vehicle_number)
    RETURNING id INTO v_visitor_id;

    -- Log gate entry immediately as INSIDE
    INSERT INTO visitor_logs (
        visitor_id,
        flat_id,
        guard_id,
        resident_id,
        purpose,
        vehicle_number,
        status,
        entry_time
    ) VALUES (
        v_visitor_id,
        v_pre.flat_id,
        auth.uid(),
        v_pre.resident_id,
        v_pre.purpose,
        v_pre.vehicle_number,
        'INSIDE',
        now()
    ) RETURNING id INTO v_log_id;

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Pre-approval verified. Visitor marked INSIDE.',
        'visitor_name', v_pre.visitor_name,
        'flat_id', v_pre.flat_id,
        'log_id', v_log_id
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- 7. FUNCTION: AUTO-DELETE VISITOR PHOTOS OLDER THAN 90 DAYS
-- Keeps storage usage strictly within the Supabase Free Tier
-- ==============================================================================
CREATE OR REPLACE FUNCTION prune_old_visitor_photos()
RETURNS INT AS $$
DECLARE
    v_deleted_count INT := 0;
BEGIN
    -- Nullify photo_url for entries older than 90 days
    UPDATE visitors
    SET photo_url = NULL
    WHERE photo_url IS NOT NULL 
      AND created_at < (now() - INTERVAL '90 days');
    
    GET DIAGNOSTICS v_deleted_count = ROW_COUNT;
    RETURN v_deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- 8. SUPABASE REALTIME CONFIGURATION
-- Enable real-time WebSocket broadcasting for live updates
-- ==============================================================================
BEGIN;
  -- Add relevant tables to the realtime publication
  ALTER PUBLICATION supabase_realtime ADD TABLE visitor_logs;
  ALTER PUBLICATION supabase_realtime ADD TABLE sos_alerts;
  ALTER PUBLICATION supabase_realtime ADD TABLE notices;
  ALTER PUBLICATION supabase_realtime ADD TABLE delivery_logs;
COMMIT;
