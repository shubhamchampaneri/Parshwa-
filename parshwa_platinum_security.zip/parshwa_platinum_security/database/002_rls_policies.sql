-- ==============================================================================
-- PARSHWA PLATINUM SECURITY - 002 ROW LEVEL SECURITY (RLS) POLICIES
-- Zero-Trust database access policies for Resident, Guard, and Admin
-- ==============================================================================

-- 1. Helper security functions (SECURITY DEFINER to avoid recursion)
CREATE OR REPLACE FUNCTION auth_user_role()
RETURNS TEXT AS $$
    SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION auth_user_status()
RETURNS TEXT AS $$
    SELECT status FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION auth_user_flat_id()
RETURNS UUID AS $$
    SELECT flat_id FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- 2. ENABLE RLS ON ALL TABLES
ALTER TABLE flats ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitor_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE pre_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;
ALTER TABLE sos_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE device_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE guard_invite_codes ENABLE ROW LEVEL SECURITY;

-- ==============================================================================
-- 3. POLICIES: FLATS
-- ==============================================================================
-- Allow anyone authenticated (or registering) to read flats list (needed for registration dropdown)
CREATE POLICY "flats_select_all" ON flats
    FOR SELECT TO authenticated, anon
    USING (true);

-- Residents can update only their own flat's delivery preference
CREATE POLICY "flats_update_resident" ON flats
    FOR UPDATE TO authenticated
    USING (id = auth_user_flat_id() AND auth_user_role() = 'RESIDENT' AND auth_user_status() = 'APPROVED')
    WITH CHECK (id = auth_user_flat_id());

-- Admins can update any flat
CREATE POLICY "flats_update_admin" ON flats
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- ==============================================================================
-- 4. POLICIES: PROFILES (Strict role escalation prevention)
-- ==============================================================================
-- Users can read their own profile
CREATE POLICY "profiles_select_self" ON profiles
    FOR SELECT TO authenticated
    USING (id = auth.uid());

-- Approved residents can view co-residents in the same flat
CREATE POLICY "profiles_select_flatmates" ON profiles
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT' 
        AND auth_user_status() = 'APPROVED'
        AND flat_id = auth_user_flat_id()
    );

-- Approved guards can view resident profiles to contact flat members
CREATE POLICY "profiles_select_guards" ON profiles
    FOR SELECT TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

-- Admins can view all profiles
CREATE POLICY "profiles_select_admin" ON profiles
    FOR SELECT TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- Users can update ONLY their own non-privileged fields (full_name, phone_number, avatar_url)
-- Prevent role or status modification from client!
CREATE POLICY "profiles_update_self" ON profiles
    FOR UPDATE TO authenticated
    USING (id = auth.uid())
    WITH CHECK (
        id = auth.uid()
        AND role = (SELECT role FROM profiles WHERE id = auth.uid())
        AND status = (SELECT status FROM profiles WHERE id = auth.uid())
    );

-- Admins can update any profile (e.g. approve/reject, change roles)
CREATE POLICY "profiles_update_admin" ON profiles
    FOR UPDATE TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- Allow insert during signup via trigger or self insert
CREATE POLICY "profiles_insert_self" ON profiles
    FOR INSERT TO authenticated
    WITH CHECK (id = auth.uid());

-- ==============================================================================
-- 5. POLICIES: VISITORS
-- ==============================================================================
CREATE POLICY "visitors_select_guard_admin" ON visitors
    FOR SELECT TO authenticated
    USING (auth_user_role() IN ('GUARD', 'ADMIN') AND auth_user_status() = 'APPROVED');

CREATE POLICY "visitors_insert_guard_admin" ON visitors
    FOR INSERT TO authenticated
    WITH CHECK (auth_user_role() IN ('GUARD', 'ADMIN') AND auth_user_status() = 'APPROVED');

CREATE POLICY "visitors_update_guard_admin" ON visitors
    FOR UPDATE TO authenticated
    USING (auth_user_role() IN ('GUARD', 'ADMIN') AND auth_user_status() = 'APPROVED');

CREATE POLICY "visitors_select_resident" ON visitors
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND id IN (
            SELECT visitor_id FROM visitor_logs WHERE flat_id = auth_user_flat_id()
        )
    );

-- ==============================================================================
-- 6. POLICIES: VISITOR LOGS
-- ==============================================================================
-- Guards can view, insert, and update walk-in entries
CREATE POLICY "visitor_logs_guard_select" ON visitor_logs
    FOR SELECT TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

CREATE POLICY "visitor_logs_guard_insert" ON visitor_logs
    FOR INSERT TO authenticated
    WITH CHECK (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

CREATE POLICY "visitor_logs_guard_update" ON visitor_logs
    FOR UPDATE TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

-- Residents can see only their flat's visitor requests & history
CREATE POLICY "visitor_logs_resident_select" ON visitor_logs
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT' 
        AND auth_user_status() = 'APPROVED'
        AND flat_id = auth_user_flat_id()
    );

-- Residents can update (Approve/Deny) their flat's pending visitor requests
CREATE POLICY "visitor_logs_resident_update" ON visitor_logs
    FOR UPDATE TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND auth_user_status() = 'APPROVED'
        AND flat_id = auth_user_flat_id()
    )
    WITH CHECK (
        flat_id = auth_user_flat_id()
    );

-- Admin has full access
CREATE POLICY "visitor_logs_admin_all" ON visitor_logs
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- ==============================================================================
-- 7. POLICIES: PRE-APPROVALS
-- ==============================================================================
-- Residents can view, insert, and cancel their own pre-approvals
CREATE POLICY "pre_approvals_resident_select" ON pre_approvals
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND auth_user_status() = 'APPROVED'
        AND flat_id = auth_user_flat_id()
    );

CREATE POLICY "pre_approvals_resident_insert" ON pre_approvals
    FOR INSERT TO authenticated
    WITH CHECK (
        auth_user_role() = 'RESIDENT'
        AND auth_user_status() = 'APPROVED'
        AND flat_id = auth_user_flat_id()
        AND resident_id = auth.uid()
    );

CREATE POLICY "pre_approvals_resident_update" ON pre_approvals
    FOR UPDATE TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND flat_id = auth_user_flat_id()
    );

-- Guards can read active pre-approvals to verify OTP/QR and mark them USED
CREATE POLICY "pre_approvals_guard_select" ON pre_approvals
    FOR SELECT TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

CREATE POLICY "pre_approvals_guard_update" ON pre_approvals
    FOR UPDATE TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

-- Admin full access
CREATE POLICY "pre_approvals_admin_all" ON pre_approvals
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- ==============================================================================
-- 8. POLICIES: NOTICES
-- ==============================================================================
-- Approved residents, guards, and admins can view active notices targeted to them
CREATE POLICY "notices_select" ON notices
    FOR SELECT TO authenticated
    USING (
        is_active = true
        AND (
            target_audience = 'ALL'
            OR (target_audience = 'RESIDENTS' AND auth_user_role() = 'RESIDENT')
            OR (target_audience = 'GUARDS' AND auth_user_role() = 'GUARD')
            OR auth_user_role() = 'ADMIN'
        )
    );

-- Only Admin can manage notices
CREATE POLICY "notices_admin_all" ON notices
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- ==============================================================================
-- 9. POLICIES: COMPLAINTS
-- ==============================================================================
CREATE POLICY "complaints_resident_select" ON complaints
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND flat_id = auth_user_flat_id()
    );

CREATE POLICY "complaints_resident_insert" ON complaints
    FOR INSERT TO authenticated
    WITH CHECK (
        auth_user_role() = 'RESIDENT'
        AND flat_id = auth_user_flat_id()
        AND resident_id = auth.uid()
    );

CREATE POLICY "complaints_admin_all" ON complaints
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- ==============================================================================
-- 10. POLICIES: SOS ALERTS
-- ==============================================================================
-- Residents can raise SOS and view their flat's alarms
CREATE POLICY "sos_resident_insert" ON sos_alerts
    FOR INSERT TO authenticated
    WITH CHECK (
        auth_user_role() = 'RESIDENT'
        AND flat_id = auth_user_flat_id()
        AND resident_id = auth.uid()
    );

CREATE POLICY "sos_resident_select" ON sos_alerts
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND flat_id = auth_user_flat_id()
    );

-- Guards can view and acknowledge all SOS alarms
CREATE POLICY "sos_guard_select" ON sos_alerts
    FOR SELECT TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

CREATE POLICY "sos_guard_update" ON sos_alerts
    FOR UPDATE TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

-- Admin full access
CREATE POLICY "sos_admin_all" ON sos_alerts
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- ==============================================================================
-- 11. POLICIES: DELIVERY & STAFF LOGS
-- ==============================================================================
CREATE POLICY "delivery_resident_select" ON delivery_logs
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND flat_id = auth_user_flat_id()
    );

CREATE POLICY "delivery_guard_all" ON delivery_logs
    FOR ALL TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

CREATE POLICY "delivery_admin_all" ON delivery_logs
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

CREATE POLICY "staff_guard_all" ON staff_entries
    FOR ALL TO authenticated
    USING (auth_user_role() = 'GUARD' AND auth_user_status() = 'APPROVED');

CREATE POLICY "staff_resident_select" ON staff_entries
    FOR SELECT TO authenticated
    USING (
        auth_user_role() = 'RESIDENT'
        AND (flat_id = auth_user_flat_id() OR flat_id IS NULL)
    );

CREATE POLICY "staff_admin_all" ON staff_entries
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');

-- ==============================================================================
-- 12. POLICIES: DEVICE TOKENS & GUARD CODES
-- ==============================================================================
CREATE POLICY "device_tokens_self" ON device_tokens
    FOR ALL TO authenticated
    USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());

CREATE POLICY "guard_codes_admin_all" ON guard_invite_codes
    FOR ALL TO authenticated
    USING (auth_user_role() = 'ADMIN');
