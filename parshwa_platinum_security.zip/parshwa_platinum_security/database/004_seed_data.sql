-- ==============================================================================
-- PARSHWA PLATINUM SECURITY - 004 SEED DATA
-- Apartment: Parshwa Platinum (7 Floors, 28 Flats: 101-104 ... 701-704)
-- Initial Flats, Active Guard Invite Code, and Welcome Notice
-- ==============================================================================

-- 1. POPULATE ALL 28 FLATS
DO $$
DECLARE
    v_floor INT;
    v_unit INT;
    v_flat_num TEXT;
BEGIN
    FOR v_floor IN 1..7 LOOP
        FOR v_unit IN 1..4 LOOP
            v_flat_num := (v_floor * 100 + v_unit)::TEXT;
            IF NOT EXISTS (SELECT 1 FROM flats WHERE flat_number = v_flat_num) THEN
                INSERT INTO flats (floor_number, unit_number, flat_number, delivery_preference)
                VALUES (v_floor, v_unit, v_flat_num, 'ASK_FIRST');
            END IF;
        END LOOP;
    END LOOP;
END $$;

-- 2. SEED INITIAL GUARD INVITE CODE
INSERT INTO guard_invite_codes (code, is_active)
VALUES ('PPGUARD2026', true)
ON CONFLICT (code) DO NOTHING;

-- 3. SEED INITIAL SOCIETY WELCOME NOTICE (Mock Admin profile if not exists, or insert notice)
-- Note: Notice will be active and viewable by all residents and guards
DO $$
DECLARE
    v_admin_id UUID;
BEGIN
    SELECT id INTO v_admin_id FROM profiles WHERE role = 'ADMIN' LIMIT 1;
    
    -- If no admin exists yet during initial seed, we insert notice with a system placeholder UUID or skip
    IF v_admin_id IS NOT NULL THEN
        IF NOT EXISTS (SELECT 1 FROM notices WHERE title LIKE '%Welcome to Parshwa Platinum%') THEN
            INSERT INTO notices (
                title, 
                content, 
                priority, 
                target_audience, 
                created_by, 
                is_active
            ) VALUES (
                'Welcome to Parshwa Platinum Security System',
                'Welcome all residents and security staff to the digital gate and apartment security system. Please ensure your flat members and vehicles are up to date.',
                'IMPORTANT',
                'ALL',
                v_admin_id,
                true
            );
        END IF;
    END IF;
END $$;
