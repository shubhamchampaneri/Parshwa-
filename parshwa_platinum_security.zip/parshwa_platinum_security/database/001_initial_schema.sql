-- ==============================================================================
-- PARSHWA PLATINUM SECURITY - 001 INITIAL SCHEMA
-- Apartment: Parshwa Platinum (7 Floors, 28 Flats: 101-104 ... 701-704)
-- Database: Supabase / PostgreSQL
-- ==============================================================================

-- 1. Enable required PostgreSQL extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Drop existing tables if clean reinstall is requested
DROP TABLE IF EXISTS device_tokens CASCADE;
DROP TABLE IF EXISTS guard_invite_codes CASCADE;
DROP TABLE IF EXISTS staff_entries CASCADE;
DROP TABLE IF EXISTS delivery_logs CASCADE;
DROP TABLE IF EXISTS sos_alerts CASCADE;
DROP TABLE IF EXISTS complaints CASCADE;
DROP TABLE IF EXISTS notices CASCADE;
DROP TABLE IF EXISTS pre_approvals CASCADE;
DROP TABLE IF EXISTS visitor_logs CASCADE;
DROP TABLE IF EXISTS visitors CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;
DROP TABLE IF EXISTS flats CASCADE;

-- 3. FLATS TABLE (28 units across 7 floors)
CREATE TABLE IF NOT EXISTS flats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    floor_number INT NOT NULL CHECK (floor_number BETWEEN 1 AND 7),
    unit_number INT NOT NULL CHECK (unit_number BETWEEN 1 AND 4),
    flat_number TEXT NOT NULL UNIQUE, -- '101', '102', ... '704'
    delivery_preference TEXT NOT NULL DEFAULT 'ASK_FIRST' CHECK (delivery_preference IN ('LEAVE_AT_GATE', 'ASK_FIRST')),
    delivery_instructions TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index on flat_number for fast lookup
CREATE INDEX IF NOT EXISTS idx_flats_number ON flats(flat_number);

-- 4. PROFILES TABLE (Linked directly to Supabase auth.users)
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'RESIDENT' CHECK (role IN ('RESIDENT', 'GUARD', 'ADMIN')),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
    flat_id UUID REFERENCES flats(id) ON DELETE SET NULL, -- Nullable for guards/admins
    occupancy_type TEXT DEFAULT 'OWNER' CHECK (occupancy_type IN ('OWNER', 'TENANT', 'FAMILY', 'GUARD', 'ADMIN')),
    avatar_url TEXT,
    rejection_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_status ON profiles(status);
CREATE INDEX IF NOT EXISTS idx_profiles_flat_id ON profiles(flat_id);

-- 5. VISITORS DIRECTORY TABLE
CREATE TABLE IF NOT EXISTS visitors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    photo_url TEXT,
    vehicle_number TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_visitors_phone ON visitors(phone_number);

-- 6. VISITOR LOGS TABLE (Gate walk-in entries & approvals)
CREATE TABLE IF NOT EXISTS visitor_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visitor_id UUID NOT NULL REFERENCES visitors(id) ON DELETE CASCADE,
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    guard_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    resident_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    purpose TEXT NOT NULL DEFAULT 'GUEST' CHECK (purpose IN ('GUEST', 'DELIVERY', 'CAB', 'SERVICE', 'OTHER')),
    vehicle_number TEXT,
    number_of_visitors INT NOT NULL DEFAULT 1 CHECK (number_of_visitors >= 1),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'INSIDE', 'EXITED')),
    entry_time TIMESTAMPTZ,
    exit_time TIMESTAMPTZ,
    rejection_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_visitor_logs_flat_id ON visitor_logs(flat_id);
CREATE INDEX IF NOT EXISTS idx_visitor_logs_status ON visitor_logs(status);
CREATE INDEX IF NOT EXISTS idx_visitor_logs_entry_time ON visitor_logs(entry_time);
CREATE INDEX IF NOT EXISTS idx_visitor_logs_created_at ON visitor_logs(created_at DESC);

-- 7. PRE-APPROVALS TABLE (Resident generated passes with OTP & QR)
CREATE TABLE IF NOT EXISTS pre_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    visitor_name TEXT NOT NULL,
    visitor_phone TEXT,
    purpose TEXT NOT NULL DEFAULT 'GUEST' CHECK (purpose IN ('GUEST', 'DELIVERY', 'CAB', 'SERVICE', 'OTHER')),
    vehicle_number TEXT,
    expected_arrival TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    qr_code_data TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'USED', 'EXPIRED', 'CANCELLED')),
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pre_approvals_otp ON pre_approvals(otp_code);
CREATE INDEX IF NOT EXISTS idx_pre_approvals_flat ON pre_approvals(flat_id);
CREATE INDEX IF NOT EXISTS idx_pre_approvals_status ON pre_approvals(status);

-- 8. NOTICES TABLE (Society announcements)
CREATE TABLE IF NOT EXISTS notices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'NORMAL' CHECK (priority IN ('NORMAL', 'IMPORTANT', 'URGENT')),
    target_audience TEXT NOT NULL DEFAULT 'ALL' CHECK (target_audience IN ('ALL', 'RESIDENTS', 'GUARDS')),
    created_by UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    attachment_url TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notices_is_active ON notices(is_active);
CREATE INDEX IF NOT EXISTS idx_notices_created_at ON notices(created_at DESC);

-- 9. COMPLAINTS TABLE (Service & maintenance requests)
CREATE TABLE IF NOT EXISTS complaints (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    category TEXT NOT NULL CHECK (category IN ('WATER', 'LIFT', 'PARKING', 'CLEANING', 'ELECTRICAL', 'SECURITY', 'OTHER')),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    photo_url TEXT,
    status TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN ('SUBMITTED', 'IN_PROGRESS', 'RESOLVED')),
    admin_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_complaints_flat_id ON complaints(flat_id);
CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);

-- 10. SOS ALERTS TABLE (Emergency alarms)
CREATE TABLE IF NOT EXISTS sos_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    emergency_type TEXT NOT NULL DEFAULT 'GENERAL' CHECK (emergency_type IN ('MEDICAL', 'FIRE', 'THREAT', 'LIFT', 'GENERAL')),
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'ACKNOWLEDGED', 'RESOLVED', 'FALSE_ALARM')),
    acknowledged_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    acknowledged_at TIMESTAMPTZ,
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sos_alerts_status ON sos_alerts(status);
CREATE INDEX IF NOT EXISTS idx_sos_alerts_created_at ON sos_alerts(created_at DESC);

-- 11. DELIVERY LOGS TABLE (Gate parcels & courier records)
CREATE TABLE IF NOT EXISTS delivery_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_id UUID NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
    guard_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    company_name TEXT NOT NULL CHECK (company_name IN ('AMAZON', 'FLIPKART', 'ZOMATO', 'SWIGGY', 'BLINKIT', 'ZEPTO', 'COURIER', 'OTHER')),
    package_count INT NOT NULL DEFAULT 1 CHECK (package_count >= 1),
    status TEXT NOT NULL DEFAULT 'AT_GATE' CHECK (status IN ('AT_GATE', 'COLLECTED', 'DELIVERED_TO_FLAT')),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_delivery_logs_flat_id ON delivery_logs(flat_id);
CREATE INDEX IF NOT EXISTS idx_delivery_logs_status ON delivery_logs(status);

-- 12. STAFF ENTRIES TABLE (Daily maids, drivers, cooks)
CREATE TABLE IF NOT EXISTS staff_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    role_type TEXT NOT NULL CHECK (role_type IN ('MAID', 'DRIVER', 'COOK', 'CLEANER', 'TECHNICIAN', 'OTHER')),
    flat_id UUID REFERENCES flats(id) ON DELETE SET NULL,
    guard_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    entry_time TIMESTAMPTZ NOT NULL DEFAULT now(),
    exit_time TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_staff_entries_entry_time ON staff_entries(entry_time);

-- 13. DEVICE TOKENS TABLE (FCM push notification registrations)
CREATE TABLE IF NOT EXISTS device_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    token TEXT NOT NULL UNIQUE,
    platform TEXT NOT NULL CHECK (platform IN ('android', 'ios')),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_device_tokens_user_id ON device_tokens(user_id);

-- 14. GUARD INVITE CODES TABLE (Secret rotation for security registration)
CREATE TABLE IF NOT EXISTS guard_invite_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT NOT NULL UNIQUE,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    rotated_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_guard_invite_codes_active ON guard_invite_codes(is_active);
